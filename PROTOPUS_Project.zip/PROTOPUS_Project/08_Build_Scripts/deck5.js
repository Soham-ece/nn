// PROTOPUS pitch deck, 16-slide edit. Same design language as the founder's deck.
const pptxgen = require("pptxgenjs");
const OUT = "/home/user/nn/protopulse_murder_board/PROTOPUS_Pitch_Deck_16.pptx";
const A = "/home/user/lo/src/";

const BG = "0E1216", PANEL = "121A21", RULE = "1F2A32", TEXT = "E8EEF2", BODY = "A3B3BE", MUTED = "6E7A83", DIM = "424A51";
const COPPER = "CF8F4E", BLUE = "54ACF0", YELLOW = "F2C230", GREEN = "60A05A", ONYEL = "1A1405", STEEL = "8FB3C9";
const CREAM = "F0E3D2", BROWN = "8A5F31", CBLUE = "1B64A8", CBLACK = "131210", MUSTARD = "C08A12", TAUPE = "9C8F7C";
const HEAD = "Space Grotesk", MONO = "Space Mono";

const pres = new pptxgen();
pres.layout = "LAYOUT_16x9";
pres.author = "PROTOPUS";
pres.title = "PROTOPUS pitch deck";

const T = (s, text, o) => s.addText(text, Object.assign({ fontFace: MONO, color: BODY, isTextBox: true, margin: 0, valign: "top" }, o));
const H = (s, text, o) => T(s, text, Object.assign({ fontFace: HEAD, bold: true, color: TEXT }, o));
const line = (s, x, y, w, h, color = RULE, width = 0.75, dash, arrow) => s.addShape(pres.shapes.LINE, { x, y, w, h, line: Object.assign({ color, width, dashType: dash }, arrow ? { endArrowType: "triangle" } : {}) });
const rect = (s, x, y, w, h, fill, lc, lw = 0.75) => s.addShape(pres.shapes.RECTANGLE, { x, y, w, h, fill: { color: fill }, line: lc ? { color: lc, width: lw } : { color: fill, width: 0 } });
const bar = (s, x, y, w, color, h = 0.04) => rect(s, x, y, w, h, color);
const dot = (s, x, y, filled, color = YELLOW, ring = DIM, d = 0.11) => s.addShape(pres.shapes.OVAL, { x, y, w: d, h: d, fill: { color: filled ? color : BG }, line: { color: filled ? color : ring, width: 0.75 } });
const pill = (s, text, x, y, w) => { rect(s, x, y, w, 0.26, YELLOW); T(s, text, { x, y, w, h: 0.26, fontSize: 8, bold: true, color: ONYEL, align: "center", valign: "middle", charSpacing: 1 }); };
const src = (s, t, y = 5.2) => T(s, t, { x: 0.45, y, w: 9.1, h: 0.2, fontSize: 6.5, color: MUTED });
let n = 0;
function slide(kicker, title, o = {}) {
  const s = pres.addSlide();
  s.background = { color: BG };
  T(s, (String(++n).padStart(2, "0") + " · " + kicker).toUpperCase(), { x: 0.45, y: 0.47, w: 9.1, h: 0.2, fontSize: 8.5, color: o.kc || COPPER, charSpacing: 2.5 });
  H(s, title, { x: 0.45, y: 0.72, w: 8.8, h: 0.85, fontSize: o.ts || 24 });
  return s;
}

// ============================================================ 1 COVER
{
  const s = pres.addSlide(); s.background = { color: BG };
  s.addImage({ path: A + "logo.png", x: 0.45, y: 0.52, w: 2.15, h: 0.374 });
  T(s, [{ text: "Focus on", options: { breakLine: true } }, { text: "innovation", options: { underline: { style: "wavy", color: BLUE } } }, { text: "." }],
    { x: 0.45, y: 1.72, w: 9.2, h: 1.45, fontFace: MONO, bold: true, fontSize: 42, color: TEXT, lineSpacingMultiple: 0.95 });
  T(s, "We take care of the rest.", { x: 0.45, y: 3.08, w: 9.4, h: 0.7, fontFace: MONO, bold: true, fontSize: 42, color: "9FB0BC" });
  T(s, [{ text: "proto", options: { color: YELLOW } }, { text: ", our AI engineer, plans every step.", options: { breakLine: true } }, { text: "baker", options: { color: COPPER } }, { text: " makes the board. " }, { text: "mixer", options: { color: BLUE } }, { text: " tests it." }],
    { x: 0.45, y: 4.1, w: 9, h: 0.5, fontSize: 11.5, lineSpacingMultiple: 1.2 });
  T(s, "protopus-kappa.vercel.app", { x: 0.45, y: 4.85, w: 5, h: 0.2, fontSize: 8.5, color: MUTED });
}

// ============================================================ 2 PROBLEM
{
  const s = slide("Problem", "A prototype is a loop,\nand every lap costs weeks");
  s.addShape(pres.shapes.OVAL, { x: 0.8, y: 2.18, w: 2.45, h: 2.45, fill: { color: BG }, line: { color: DIM, width: 0.9, dashType: "dash" } });
  const nb = (t, x, y, w, color = TEXT, fill = BG, tc = TEXT) => { rect(s, x, y, w, 0.3, fill, color); T(s, t, { x, y, w, h: 0.3, fontSize: 9, color: tc, align: "center", valign: "middle", bold: fill !== BG }); };
  nb("design", 1.7, 2.03, 0.66); nb("order", 2.87, 2.62, 0.6); nb("wait 2 weeks", 2.78, 3.38, 1.15, COPPER, COPPER, ONYEL);
  nb("solder by hand", 1.35, 4.48, 1.35); nb("test", 0.61, 3.92, 0.52); nb("bug found", 0.4, 2.87, 0.95, BLUE, BG, BLUE);
  T(s, "AND AGAIN", { x: 1.2, y: 3.02, w: 1.4, h: 0.2, fontSize: 9, color: MUTED, align: "center", charSpacing: 2 });
  T(s, "×3, ×4, ×5", { x: 1.12, y: 3.27, w: 1.55, h: 0.3, fontSize: 14, bold: true, color: TEXT, align: "center" });
  [["2", "weeks waiting for a board to come back from a fab"], ["5", "instruments to buy before you can measure it"], ["5", "vendor apps and driver stacks to keep alive"]].forEach((x, i) => {
    const y = 1.95 + i * 0.9;
    H(s, x[0], { x: 4.05, y, w: 1, h: 0.75, fontSize: 44, color: COPPER });
    T(s, x[1], { x: 5.4, y: y + 0.12, w: 4.15, h: 0.5, fontSize: 10.5, color: TEXT });
    if (i < 2) line(s, 4.05, y + 0.84, 5.5, 0);
  });
  H(s, [{ text: "Nobody is short of ideas. " }, { text: "They are short of tries.", options: { color: YELLOW } }], { x: 0.45, y: 4.95, w: 9.1, h: 0.35, fontSize: 14 });
}

// ============================================================ 3 WHY NOW
{
  const s = slide("Why now", "AI already builds software.\nIn hardware, it stops at the file.");
  const cols = [
    ["SOFTWARE", "$100M ARR", "Lovable, 8 months after launch, selling to people who can't code.", YELLOW],
    ["HARDWARE FILES", "~$100M", "raised by AI that draws boards: Flux, Quilter, Diode. Claude now drives Fusion and Blender.", COPPER],
    ["THE BENCH", "0", "AI tools that can make the board, power it and see if it works.", BLUE],
  ];
  cols.forEach((c, i) => {
    const x = 0.45 + i * 3.1;
    bar(s, x, 1.95, 2.9, c[3]);
    T(s, c[0], { x, y: 2.07, w: 2.9, h: 0.2, fontSize: 8, color: c[3], charSpacing: 2 });
    H(s, c[1], { x, y: 2.32, w: 2.9, h: 0.6, fontSize: 30 });
    T(s, c[2], { x, y: 2.98, w: 2.85, h: 0.75, fontSize: 9 });
  });
  const st = [["idea", TEXT], ["files", TEXT], ["board", COPPER], ["test", BLUE], ["verdict", YELLOW]];
  st.forEach((x, i) => {
    const xx = 0.45 + i * 1.3;
    rect(s, xx, 4.05, 1.1, 0.36, BG, x[1]);
    T(s, x[0], { x: xx, y: 4.05, w: 1.1, h: 0.36, fontSize: 9.5, color: x[1], align: "center", valign: "middle" });
    if (i < 4) line(s, xx + 1.1, 4.23, 0.2, 0, DIM, 0.75, null, true);
  });
  line(s, 2.95, 3.9, 0, 0.75, COPPER, 1.25, "dash");
  T(s, "AI today", { x: 0.45, y: 4.52, w: 2.4, h: 0.2, fontSize: 7.5, color: MUTED, align: "center" });
  T(s, "protopus: the AI's hands and eyes", { x: 3.05, y: 4.52, w: 3.5, h: 0.2, fontSize: 7.5, color: YELLOW, align: "center" });
  rect(s, 7.05, 3.98, 2.5, 0.8, YELLOW);
  T(s, "Smart machines give the AI access to the real world.", { x: 7.17, y: 3.98, w: 2.3, h: 0.8, fontSize: 9.5, bold: true, color: ONYEL, valign: "middle" });
  src(s, "TechCrunch 23 Jul 2025 · SiliconANGLE 27 Feb 2026 · BusinessWire 7 Oct 2025 · Fenwick · claude.com/connectors · digitalproduction.com 30 Apr 2026");
}

// ============================================================ 4 SOLUTION
{
  const s = slide("Solution", "One AI engineer, and the two smart machines it runs");
  const cols = [
    ["proto", YELLOW, A + "mascot.png", 410 / 250, "Plans the build, runs the machines, explains the results."],
    ["baker", COPPER, A + "r0.png", 1272 / 898, "Makes the board: mill, mask, stencil, paste, reflow."],
    ["mixer", BLUE, A + "r1.png", 1103 / 820, "Tests it: eight instruments on one cable."],
  ];
  cols.forEach((c, i) => {
    const x = 0.45 + i * 3.12, w = 2.9, ih = 1.4;
    const iw = Math.min(w, ih * c[3]);
    s.addImage({ path: c[2], x: x + (w - iw) / 2, y: 1.4, w: iw, h: iw / c[3] });
    bar(s, x, 2.88, w, c[1]);
    H(s, c[0], { x, y: 3.02, w, h: 0.45, fontSize: 24, color: c[1] });
    T(s, c[4], { x, y: 3.5, w, h: 0.5, fontSize: 9.5, color: TEXT });
  });
  line(s, 0.45, 4.3, 9.1, 0);
  T(s, [{ text: "FOR PROTOTYPES · ", options: { color: COPPER } }, { text: "the first 1–10 boards of a design. Volume goes to a fab.", options: { color: TEXT } }], { x: 0.45, y: 4.5, w: 3.4, h: 0.7, fontSize: 8.5 });
  [["DEMO 1", "Website · protopus-kappa.vercel.app"], ["DEMO 2", "Video · Baker prototype running"]].forEach((d, i) => {
    const x = 4.0 + i * 2.8;
    rect(s, x, 4.46, 2.62, 0.66, PANEL, RULE);
    pill(s, d[0], x + 0.12, 4.66, 0.68);
    T(s, d[1], { x: x + 0.9, y: 4.5, w: 1.66, h: 0.58, fontSize: 8, bold: true, color: TEXT, valign: "middle" });
  });
}

// ============================================================ 5 PROTO
{
  const s = slide("Proto · what makes it ours", "An AI engineer that understands your board", { kc: YELLOW });
  rect(s, 0.45, 1.5, 4.0, 2.41, BG, YELLOW, 1.25);
  s.addImage({ path: A + "studio.png", x: 0.47, y: 1.52, w: 3.96, h: 2.37 });
  T(s, "Baker Studio today: Proto found the thin trace, fixed it and planned the mill. You press Accept.", { x: 0.45, y: 4.0, w: 4.0, h: 0.42, fontSize: 8 });
  [["01", "READS", "schematics and layouts, via the Flux.ai API", COPPER], ["02", "MAKES", "the Baker job: mill, drill, mask, stencil, jig", COPPER], ["03", "DIAGNOSES", "through Mixer, in plain words", BLUE], ["04", "HAS A CHARACTER", "a platypus engineer, built on Gemini", YELLOW]].forEach((r, i) => {
    const y = 1.5 + i * 0.62;
    line(s, 4.75, y - 0.05, 4.8, 0);
    H(s, r[0], { x: 4.75, y, w: 0.5, h: 0.4, fontSize: 16, color: r[3] });
    T(s, r[1], { x: 5.3, y: y + 0.02, w: 4.2, h: 0.18, fontSize: 8, color: r[3], charSpacing: 1.5 });
    T(s, r[2], { x: 5.3, y: y + 0.24, w: 4.2, h: 0.25, fontSize: 9, color: TEXT });
  });
  rect(s, 4.75, 4.0, 4.8, 0.55, PANEL);
  pill(s, "NEXT", 4.88, 4.14, 0.62);
  T(s, "Probe matrix: probes under the board reach every net.", { x: 5.62, y: 4.0, w: 3.85, h: 0.55, fontSize: 8, color: TEXT, valign: "middle" });
  H(s, [{ text: "Simple enough that a " }, { text: "high-school student", options: { color: YELLOW } }, { text: " can print a board." }], { x: 0.45, y: 4.85, w: 9.1, h: 0.35, fontSize: 14 });
}

// ============================================================ 6 HOW PROTO WORKS
{
  const s = slide("Proto · how the AI works", "A loop, not a chatbot", { kc: YELLOW });
  const top = [["UNDERSTAND", "design → board model", YELLOW], ["PLAN", "LLM breaks the goal into steps", YELLOW], ["CHECK", "DRC + Baker rules", STEEL], ["MAKE", "toolpaths, mask, stencil, jig", COPPER]];
  const bot = [["YOU GET", "a tested board + a sentence", YELLOW, true], ["EXPLAIN", "measured vs expected → fix", YELLOW], ["MEASURE", "Mixer runs the test plan", BLUE], ["APPROVE", "you press Accept", TEXT]];
  const X = (i) => 0.45 + i * 2.3, W = 2.1;
  top.forEach((c, i) => {
    rect(s, X(i), 1.6, W, 0.95, BG, c[2]);
    T(s, c[0], { x: X(i) + 0.12, y: 1.68, w: W - 0.2, h: 0.2, fontSize: 8, bold: true, color: c[2], charSpacing: 1 });
    T(s, c[1], { x: X(i) + 0.12, y: 1.95, w: W - 0.2, h: 0.55, fontSize: 9, color: TEXT });
    if (i < 3) line(s, X(i) + W, 2.07, 0.2, 0, DIM, 0.75, null, true);
  });
  line(s, X(3) + W / 2, 2.55, 0, 0.35, DIM, 0.75, null, true);
  bot.forEach((c, i) => {
    const fill = c[3] ? YELLOW : BG;
    rect(s, X(i), 2.9, W, 0.95, fill, c[2]);
    T(s, c[0], { x: X(i) + 0.12, y: 2.98, w: W - 0.2, h: 0.2, fontSize: 8, bold: true, color: c[3] ? ONYEL : c[2], charSpacing: 1 });
    T(s, c[1], { x: X(i) + 0.12, y: 3.25, w: W - 0.2, h: 0.55, fontSize: 9, color: c[3] ? ONYEL : TEXT });
    if (i > 0) line(s, X(i), 3.37, -0.2, 0, DIM, 0.75, null, true);
  });
  line(s, X(1) + W / 2, 2.9, 0, -0.35, YELLOW, 0.9, null, true);
  T(s, "next attempt", { x: X(1) + W / 2 + 0.08, y: 2.62, w: 1.2, h: 0.2, fontSize: 7, color: YELLOW });
  rect(s, 0.45, 4.1, 9.1, 0.5, PANEL, RULE);
  T(s, [{ text: "MEMORY  ", options: { bold: true, color: YELLOW } }, { text: "every run logs design → settings → measurements → outcome. No files-only AI has this data: it's the moat.", options: { color: TEXT } }], { x: 0.6, y: 4.1, w: 8.9, h: 0.5, fontSize: 8.5, valign: "middle" });
  T(s, "The model proposes · tested engines compute · you approve · the machine executes.", { x: 0.45, y: 4.8, w: 9.1, h: 0.3, fontSize: 10, bold: true, color: YELLOW });
}

// ============================================================ 7 ONE RUN
{
  const s = slide("Proto · one run", "From “import” to “PASS” in one sitting", { kc: YELLOW });
  rect(s, 0.45, 1.5, 9.1, 3.5, PANEL, RULE);
  T(s, "baker studio — sensor-hat-rev-c.brd", { x: 0.62, y: 1.58, w: 6, h: 0.18, fontSize: 7.5, color: MUTED });
  line(s, 0.45, 1.83, 9.1, 0);
  const W = { you: TEXT, proto: YELLOW, baker: COPPER, mixer: BLUE };
  [["10:02", "you", "import sensor-hat-rev-c from Flux"],
   ["10:03", "proto", "one trace under the MCU necks to 5.8 mil. Widened to 7 mil.  [Accept]"],
   ["10:04", "baker", "mill · drill 42 holes · mask · stencil · jig prints in parallel"],
   ["11:40", "you", "drop parts into the jig"],
   ["11:52", "baker", "low-temperature reflow"],
   ["12:05", "mixer", "power up ✓   3V3 rail ✓   I²C sensor: no reply ✗"],
   ["12:08", "proto", "“SDA has no pull-up: R4 is lifted on one pad. Reheat R4.”"],
   ["12:15", "mixer", "retest: sensor replies  ✓  PASS"]].forEach((l, i) => {
    const y = 1.98 + i * 0.36;
    T(s, l[0], { x: 0.62, y, w: 0.6, h: 0.3, fontSize: 8.5, color: MUTED, valign: "middle" });
    T(s, l[1], { x: 1.3, y, w: 0.7, h: 0.3, fontSize: 8.5, color: W[l[1]], bold: true, valign: "middle" });
    T(s, l[2], { x: 2.05, y, w: 7.3, h: 0.3, fontSize: 8.5, color: l[1] === "proto" ? TEXT : BODY, valign: "middle" });
  });
  src(s, "Illustrative run on the Baker Studio board. Times are engineering targets; the proof of concept measures them.", 5.12);
}

// ============================================================ 8 BAKER
{
  const s = slide("Baker · under the hood", "Fifteen steps on one shuttle, in one box");
  rect(s, 0.45, 1.55, 6.2, 2.75, BG, DIM, 0.9);
  rect(s, 1.1, 1.72, 2.35, 1.5, BG, COPPER, 1);
  T(s, [{ text: "ZONE A", options: { bold: true, color: COPPER, breakLine: true } }, { text: "500 W spindle · touch probe\nmill · drill\n10 W laser cuts the stencil" }], { x: 1.22, y: 1.8, w: 2.15, h: 1.35, fontSize: 8, color: TEXT });
  rect(s, 3.65, 1.72, 2.35, 1.5, BG, STEEL, 1);
  T(s, [{ text: "ZONE B", options: { bold: true, color: STEEL, breakLine: true } }, { text: "liquid mask\n10.1\" LCD, 405 nm UV\nwipe · dry · cure · paste" }], { x: 3.77, y: 1.8, w: 2.15, h: 1.35, fontSize: 8, color: TEXT });
  rect(s, 0.58, 1.72, 0.4, 1.5, BG, DIM);
  T(s, "FR4", { x: 0.58, y: 1.72, w: 0.4, h: 1.5, fontSize: 7, color: MUTED, align: "center", valign: "middle" });
  rect(s, 0.58, 3.45, 5.95, 0.34, COPPER);
  T(s, "⟷  SHUTTLE · one fixture, one coordinate frame, steps 01–12", { x: 0.58, y: 3.45, w: 5.95, h: 0.34, fontSize: 8, bold: true, color: ONYEL, align: "center", valign: "middle" });
  T(s, "stencil cut from the same Gerber, in the same frame: no alignment step", { x: 0.58, y: 3.9, w: 5.95, h: 0.2, fontSize: 7.5, color: MUTED, align: "center" });
  rect(s, 6.9, 1.55, 2.65, 1.2, BG, MUTED);
  T(s, [{ text: "YOU · STEPS 13–14", options: { bold: true, color: TEXT, breakLine: true } }, { text: "drop parts into a printed jig\nhotplate reflow, 138 °C" }], { x: 7.02, y: 1.63, w: 2.45, h: 1.05, fontSize: 8, color: BODY });
  rect(s, 6.9, 2.95, 2.65, 1.35, BG, BLUE);
  T(s, [{ text: "MIXER · STEP 15", options: { bold: true, color: BLUE, breakLine: true } }, { text: "one cable\neight instruments\nProto reads the result" }], { x: 7.02, y: 3.03, w: 2.45, h: 1.2, fontSize: 8, color: BODY });
  line(s, 6.65, 2.15, 0.25, 0, DIM, 0.75, null, true);
  line(s, 8.22, 2.75, 0, 0.2, DIM, 0.75, null, true);
  [["≈2 h", "per board", COPPER], ["15–20 min", "of it hands-on", YELLOW], ["3–5", "boards per shift", TEXT], ["₹1.45L", "production cost", TEXT]].forEach((x, i) => {
    const xx = 0.45 + i * 2.28;
    bar(s, xx, 4.52, 2.1, i === 0 ? COPPER : i === 1 ? YELLOW : DIM, 0.03);
    H(s, x[0], { x: xx, y: 4.6, w: 2.1, h: 0.4, fontSize: 19, color: x[2] });
    T(s, x[1], { x: xx, y: 5.0, w: 2.1, h: 0.2, fontSize: 7.5 });
  });
  src(s, "Times are engineering targets. Prototype ₹3,73,418 → production ₹1,44,842 (China parts, Delhi build, 100 units).", 5.25);
}

// ============================================================ 9 MIXER
{
  const s = slide("Mixer · under the hood", "Eight instruments, one cable, one brain", { kc: BLUE });
  const ins = ["scope · 2 ch · 12-bit", "wavegen · 2 ch · 14-bit", "logic · 16 ch", "pattern generator", "protocol decoder", "2 programmable supplies", "24-bit multimeter"];
  ins.forEach((t, i) => { rect(s, 0.45, 1.55 + i * 0.36, 2.2, 0.3, BG, DIM); T(s, t, { x: 0.55, y: 1.55 + i * 0.36, w: 2.05, h: 0.3, fontSize: 7.5, color: TEXT, valign: "middle" }); line(s, 2.65, 1.7 + i * 0.36, 0.3, 0, DIM, 0.75, null, true); });
  rect(s, 2.95, 1.55, 1.8, 2.46, BLUE);
  T(s, [{ text: "FPGA", options: { bold: true, breakLine: true } }, { text: "capture, trigger,\nwaveforms, logic" }], { x: 3.05, y: 1.55, w: 1.6, h: 2.46, fontSize: 8.5, color: ONYEL, valign: "middle" });
  line(s, 4.75, 2.78, 0.3, 0, DIM, 0.75, null, true);
  rect(s, 5.05, 2.3, 1.6, 0.95, BG, YELLOW);
  T(s, [{ text: "PROTO", options: { bold: true, color: YELLOW, breakLine: true } }, { text: "expected vs measured → verdict" }], { x: 5.15, y: 2.3, w: 1.42, h: 0.95, fontSize: 8, color: TEXT, valign: "middle" });
  T(s, "HOW A TEST RUNS", { x: 7.0, y: 1.55, w: 2.5, h: 0.2, fontSize: 8, color: BLUE, charSpacing: 1.5 });
  [["T1", "connect"], ["T2", "power up, current watched"], ["T3", "check the rails"], ["T4", "drive the inputs"], ["T5", "capture outputs"], ["T6", "decode the buses"], ["T7", "verdict in plain words"], ["T8", "fix → next board same evening"]].forEach((r, i) => {
    const y = 1.83 + i * 0.28;
    T(s, r[0], { x: 7.0, y, w: 0.4, h: 0.25, fontSize: 8, bold: true, color: i === 6 ? YELLOW : BLUE, valign: "middle" });
    T(s, r[1], { x: 7.42, y, w: 2.15, h: 0.25, fontSize: 8, color: TEXT, valign: "middle" });
  });
  [["₹13,740", "production cost", BLUE], ["8 in 1", "scope to 24-bit meter, AD3 class", TEXT], ["Our tester", "on the China line too", YELLOW]].forEach((x, i) => {
    const xx = 0.45 + i * 3.08;
    bar(s, xx, 4.4, 2.9, i === 0 ? BLUE : i === 2 ? YELLOW : DIM, 0.03);
    H(s, x[0], { x: xx, y: 4.48, w: 2.9, h: 0.4, fontSize: 18, color: x[2] });
    T(s, x[1], { x: xx, y: 4.88, w: 2.9, h: 0.2, fontSize: 7.5 });
  });
  src(s, "Prototype ₹74,847 keeps 12/14-bit converters; production drops to 8-bit, one USB cable, no screen. Status: designed, first build in the proof of concept.", 5.2);
}

// ============================================================ 10 COMPETITION
{
  const s = slide("Competition", "Others solve one step.\nNobody closes the whole loop.");
  const cols = [["PRODUCT", 0.45, 3.1], ["PRICE · ₹", 3.55, 2.1], ["MAKE", 5.75, 0.9], ["ASSEMBLE", 6.7, 0.95], ["TEST", 7.7, 0.9], ["GUIDE", 8.6, 0.95]];
  cols.forEach((c) => T(s, c[0], { x: c[1], y: 1.9, w: c[2], h: 0.2, fontSize: 7.5, color: MUTED, align: c[1] > 5 ? "center" : "left", charSpacing: 1 }));
  line(s, 0.45, 2.14, 9.1, 0, TEXT, 0.75);
  const rows = [["Voltera V-One", "~3.1 lakh", [1, 1, 0, 0]], ["LPKF ProtoMat", "8.6–24.5 lakh", [1, 0, 0, 0]], ["Makera Carvera", "~5.1 lakh", [1, 0, 0, 0]], ["Bantam Tools · discontinued", "~3.1 lakh", [1, 0, 0, 0]], ["Digilent Analog Discovery 3", "~33,000", [0, 0, 1, 0]], ["JLCPCB, PCBWay", "per order, weeks", [1, 1, 0, 0]], ["Flux (AI design)", "1.3–4.3k / month", [0, 0, 0, 1]]];
  rows.forEach((r, i) => {
    const y = 2.2 + i * 0.34;
    H(s, r[0], { x: 0.45, y, w: 3.1, h: 0.3, fontSize: 9.5, valign: "middle" });
    T(s, r[1], { x: 3.55, y, w: 2.1, h: 0.3, fontSize: 9, valign: "middle" });
    r[2].forEach((f, k) => dot(s, cols[k + 2][1] + cols[k + 2][2] / 2 - 0.055, y + 0.1, !!f));
    line(s, 0.45, y + 0.33, 9.1, 0);
  });
  const y = 2.2 + rows.length * 0.34 + 0.06;
  rect(s, 0.45, y, 9.1, 0.4, YELLOW);
  H(s, "protopus", { x: 0.57, y, w: 3.0, h: 0.4, fontSize: 10, color: ONYEL, valign: "middle" });
  H(s, "3.34 lakh", { x: 3.55, y, w: 2.1, h: 0.4, fontSize: 10, color: ONYEL, valign: "middle" });
  [0, 1, 2, 3].forEach((k) => dot(s, cols[k + 2][1] + cols[k + 2][2] / 2 - 0.055, y + 0.145, true, ONYEL, ONYEL));
  src(s, "List prices at ₹88 per US$, before import duty · voltera.io · Design World · Makera · ToolGuyd · Digilent · flux.ai", 5.12);
}

// ============================================================ 11 ECONOMICS
{
  const s = slide("Economics · projected", "We earn on every machine.\nThe customer earns it back in months.");
  T(s, "PER UNIT · ₹", { x: 0.45, y: 1.92, w: 1.9, h: 0.18, fontSize: 7.5, color: MUTED, charSpacing: 1 });
  T(s, "BAKER", { x: 2.4, y: 1.92, w: 1.1, h: 0.18, fontSize: 7.5, color: COPPER, align: "right", charSpacing: 1 });
  T(s, "MIXER", { x: 3.55, y: 1.92, w: 0.9, h: 0.18, fontSize: 7.5, color: BLUE, align: "right", charSpacing: 1 });
  line(s, 0.45, 2.14, 4.0, 0, TEXT);
  [["Total cost (all-in)", "2,00,000", "22,500"], ["Selling price", "2,99,000", "34,999"], ["Margin", "~33%", "~36%"]].forEach((r, i) => {
    const y = 2.22 + i * 0.42, hi = i === 1;
    if (hi) rect(s, 0.45, y - 0.03, 4.0, 0.4, TEXT);
    H(s, r[0], { x: 0.55, y, w: 1.9, h: 0.34, fontSize: 10, color: hi ? BG : TEXT, valign: "middle" });
    H(s, r[1], { x: 2.4, y, w: 1.1, h: 0.34, fontSize: 10, color: hi ? BG : i === 2 ? COPPER : TEXT, align: "right", valign: "middle" });
    H(s, r[2], { x: 3.55, y, w: 0.85, h: 0.34, fontSize: 10, color: hi ? BG : i === 2 ? BLUE : TEXT, align: "right", valign: "middle" });
  });
  rect(s, 0.45, 3.6, 4.0, 0.75, YELLOW);
  T(s, [{ text: "₹9,999", options: { fontFace: HEAD, bold: true, fontSize: 20 } }, { text: " / year · one Proto plan per workspace", options: { fontSize: 8.5, bold: true } }], { x: 0.58, y: 3.6, w: 3.8, h: 0.75, color: ONYEL, valign: "middle" });
  T(s, "+ consumables, reordered as labs build", { x: 0.45, y: 4.45, w: 4, h: 0.2, fontSize: 7.5 });
  line(s, 4.8, 1.92, 0, 2.9);
  T(s, "FOR THE CUSTOMER", { x: 5.1, y: 1.92, w: 4.4, h: 0.18, fontSize: 7.5, color: YELLOW, charSpacing: 1 });
  [["₹334", "per board on Baker", TEXT], ["₹6,721", "same board from JLCPCB, landed", TEXT]].forEach((x, i) => {
    const xx = 5.1 + i * 2.25;
    H(s, x[0], { x: xx, y: 2.2, w: 2.1, h: 0.5, fontSize: 24, color: x[2] });
    T(s, x[1], { x: xx, y: 2.72, w: 2.1, h: 0.35, fontSize: 7.5 });
  });
  bar(s, 5.1, 3.2, 4.45, YELLOW, 0.03);
  H(s, "53 boards", { x: 5.1, y: 3.3, w: 4.4, h: 0.5, fontSize: 26, color: YELLOW });
  T(s, "to pay back Baker + Mixer: about 6.6 months for a startup iterating twice a week", { x: 5.1, y: 3.85, w: 4.4, h: 0.4, fontSize: 8, color: TEXT });
  src(s, "Projections at 100-unit batches; costed model Baker ₹1,44,842, Mixer ₹13,740. JLCPCB: PCB + PCBA + DHL + 10% BCD + 18% IGST. Waiting time not counted.", 5.12);
}

// ============================================================ 12 MARKET
{
  const s = slide("Market plan / growth strategy", "Start in the maker studios, then\nfollow the people who watch them");
  const st = [["₹6.4L cr", "global PCB market", TEXT], ["₹3.1L cr", "global test and measurement", TEXT], ["₹55K cr", "India PCB, ~15% a year", COPPER], ["₹8.3K cr", "India test and measurement", COPPER], ["33M+", "active Arduino users", BLUE], ["2.3M+", "Hackster hardware community", BLUE], ["10,000", "Atal Tinkering Labs, +50,000 planned", YELLOW], ["~2,500", "Fab Labs in 125 countries", YELLOW]];
  line(s, 0.45, 1.9, 9.1, 0);
  st.forEach((x, i) => {
    const col = i % 4, row = Math.floor(i / 4), xx = 0.45 + col * 2.28, y = 2.0 + row * 0.8;
    if (col) line(s, xx - 0.1, y - 0.1, 0, 0.8);
    H(s, x[0], { x: xx, y, w: 2.15, h: 0.38, fontSize: 18, color: x[2] });
    T(s, x[1], { x: xx, y: y + 0.4, w: 2.1, h: 0.32, fontSize: 7.5 });
  });
  line(s, 0.45, 2.7, 9.1, 0); line(s, 0.45, 3.5, 9.1, 0);
  [["NOW", "Maker studios", "Free units for featured videos. The Bambu Lab playbook.", YELLOW], ["NEXT", "Hobbyists and startups", "Everyone who watches and loses weeks per board.", BLUE], ["ALONGSIDE", "Prototyping labs", "Tinkering, Fab and college labs that already buy tools.", COPPER]].forEach((c, i) => {
    const x = 0.45 + i * 3.08;
    bar(s, x, 3.68, 2.9, c[3]);
    T(s, c[0], { x, y: 3.8, w: 2.9, h: 0.18, fontSize: 7.5, color: c[3], charSpacing: 2 });
    H(s, c[1], { x, y: 4.02, w: 2.9, h: 0.25, fontSize: 10.5 });
    T(s, c[2], { x, y: 4.3, w: 2.85, h: 0.5, fontSize: 8 });
  });
  src(s, "IMARC · Grand View · Arduino · Hackster · Atal Innovation Mission · Forbes · at ₹88 per US$", 5.12);
}

// ============================================================ 13 PROGRESS + MILESTONES
{
  const s = slide("Where we are, and what the money proves", "Told honestly, one milestone at a time");
  [["Baker", "prototype running on the bench", COPPER, TEXT], ["Software", "Baker Studio + Proto; website live", YELLOW, TEXT], ["Mixer", "designed, not yet built", DIM, BODY]].forEach((c, i) => {
    const x = 0.45 + i * 3.1;
    bar(s, x, 1.55, 2.9, c[2]);
    H(s, c[0], { x, y: 1.66, w: 2.9, h: 0.38, fontSize: 17, color: c[3] });
    T(s, c[1], { x, y: 2.05, w: 2.85, h: 0.25, fontSize: 8.5 });
  });
  line(s, 0.45, 2.78, 9.1, 0, TEXT);
  [["M2", "Baker runs all 15 steps", COPPER], ["M3", "process tests pass", COPPER], ["M4", "Mixer measures", BLUE], ["M5", "Rev B + 5 Mixers", BLUE], ["M6", "proof of concept: 20 boards", YELLOW], ["M7–9", "seed round", GREEN]].forEach((r, i) => {
    const x = 0.45 + i * 1.53;
    dot(s, x, 2.73, true, r[2], r[2], 0.1);
    T(s, r[0], { x, y: 2.95, w: 1.45, h: 0.2, fontSize: 8, color: r[2], charSpacing: 1 });
    H(s, r[1], { x, y: 3.18, w: 1.42, h: 0.5, fontSize: 9.5 });
  });
  rect(s, 0.45, 4.0, 9.1, 0.66, PANEL, RULE);
  pill(s, "SIGNAL", 0.62, 4.2, 0.78);
  T(s, [{ text: "Samuel Beek", options: { bold: true, color: TEXT } }, { text: ", Founder & CEO of Schematik, is interested in funding us at proof of concept." }], { x: 1.58, y: 4.0, w: 7.85, h: 0.66, fontSize: 9.5, color: BODY, valign: "middle" });
  T(s, "Built in the university lab, tested with students and makers. A demo video every month.", { x: 0.45, y: 4.88, w: 9.1, h: 0.25, fontSize: 8.5, color: MUTED });
}

// ============================================================ 14 FUNDING
{
  const s = pres.addSlide(); s.background = { color: CREAM };
  T(s, (String(++n).padStart(2, "0") + " · grant / funding required").toUpperCase(), { x: 0.45, y: 0.47, w: 9, h: 0.2, fontSize: 8.5, color: BROWN, charSpacing: 2.5 });
  T(s, "₹16,00,000", { x: 0.4, y: 0.95, w: 9, h: 1.05, fontFace: MONO, bold: true, fontSize: 66, color: BROWN });
  H(s, "nine months to a proof of concept, and time to raise.", { x: 0.45, y: 2.1, w: 9, h: 0.3, fontFace: MONO, fontSize: 12, color: CBLACK });
  [["₹4.48L", "Baker + Mixer builds", BROWN], ["₹2.20L", "Rev B + 5 Mixers", CBLUE], ["₹4.50L", "one engineer, 9 months", CBLACK], ["₹1.35L", "Proto software + compute", MUSTARD], ["₹1.50L", "testing, tooling, safety", TAUPE], ["₹1.97L", "IP, outreach, reserve", GREEN]].forEach((c, i) => {
    const x = 0.45 + i * 1.545;
    rect(s, x, 2.75, 1.38, 0.05, c[2]);
    T(s, c[0], { x, y: 2.92, w: 1.4, h: 0.42, fontFace: MONO, bold: true, fontSize: 19, color: CBLACK });
    T(s, c[1], { x, y: 3.38, w: 1.38, h: 0.5, fontSize: 8, color: CBLACK });
  });
  line(s, 0.45, 4.45, 9.1, 0, CBLACK, 1);
  T(s, "Enough to survive one failed iteration and raise from strength. Builds line by line from the cost report.", { x: 0.45, y: 4.6, w: 9.1, h: 0.4, fontSize: 9.5, bold: true, color: CBLACK });
}

// ============================================================ 15 WHAT'S NEXT
{
  const s = slide("What's next", "After proof of concept: raise,\nbuild in China, run lean from Delhi");
  [["THE ROUND", "~₹1.5 Cr seed", "China pilots ₹70L · set-up + IP ₹25L · team of 5 ₹25L · Delhi centre ₹20L · buffer ₹10L", COPPER], ["THE CHINA PLAN", "Design in Delhi, build in Shenzhen", "Mixer: turnkey from batch one. Baker: modules first; turnkey once ≤ $1,305 ex-works", YELLOW], ["OPERATIONS", "Delhi finalises, doesn't build", "Scan, test, activate Proto, ship. Mixer is our production tester: our rig, our data", BLUE]].forEach((c, i) => {
    const x = 0.45 + i * 3.1;
    bar(s, x, 1.92, 2.9, c[3]);
    T(s, c[0], { x, y: 2.02, w: 2.9, h: 0.18, fontSize: 7.5, color: MUTED, charSpacing: 1.5 });
    H(s, c[1], { x, y: 2.25, w: 2.9, h: 0.5, fontSize: 12 });
    T(s, c[2], { x, y: 2.8, w: 2.85, h: 0.9, fontSize: 8 });
  });
  line(s, 0.45, 3.95, 9.1, 0, TEXT);
  [["MONTH 0–2", "design freeze, 12 RFQs", COPPER], ["MONTH 3–5", "EVT + DVT pilots", COPPER], ["MONTH 6–9", "PVT: 100 Mixers, 20 Bakers", BLUE], ["MONTH 10–12", "first container", BLUE]].forEach((r, i) => {
    const x = 0.45 + i * 2.28;
    if (i) line(s, x - 0.12, 3.95, 0, 0.9);
    T(s, r[0], { x, y: 4.08, w: 2.1, h: 0.2, fontSize: 8, color: r[2], charSpacing: 1 });
    H(s, r[1], { x, y: 4.32, w: 2.1, h: 0.45, fontSize: 10 });
  });
  src(s, "From the China assembly line master plan. Pilot batches are sellable (≈₹95L at list). Months counted from the round.", 5.12);
}

// ============================================================ 16 THANK YOU
{
  const s = pres.addSlide(); s.background = { color: BG };
  s.addImage({ path: A + "logo.png", x: 0.45, y: 0.52, w: 2.15, h: 0.374 });
  H(s, "Thank you.", { x: 0.45, y: 3.05, w: 5, h: 0.85, fontSize: 46 });
  T(s, "Come and try the loop.", { x: 0.45, y: 3.9, w: 5, h: 0.32, fontSize: 14 });
  T(s, "protopus-kappa.vercel.app", { x: 0.45, y: 4.45, w: 5, h: 0.2, fontSize: 9.5, color: COPPER });
  T(s, "soham9763015@ece.du.ac.in", { x: 0.45, y: 4.72, w: 5, h: 0.2, fontSize: 9.5, color: BLUE });
  line(s, 5.5, 0.45, 0, 4.9);
  T(s, "MANAGEMENT TEAM & CORE SKILLS", { x: 5.95, y: 0.47, w: 3.7, h: 0.2, fontSize: 8.5, color: COPPER, charSpacing: 2 });
  H(s, "Who is building this", { x: 5.95, y: 0.75, w: 3.7, h: 0.32, fontSize: 14 });
  H(s, "Soham", { x: 5.95, y: 1.3, w: 3.7, h: 0.6, fontSize: 30 });
  T(s, "Founder", { x: 5.95, y: 1.92, w: 3.7, h: 0.2, fontSize: 10, color: COPPER });
  T(s, "Third year ECE, Faculty of Technology, University of Delhi", { x: 5.95, y: 2.2, w: 3.6, h: 0.4, fontSize: 8.5 });
  [["Industrial design", COPPER], ["Mechanical architecture", COPPER], ["Embedded electronics", BLUE], ["Machine software", COPPER]].forEach((k, i) => {
    const x = 5.95 + (i % 2) * 1.86, y = 2.8 + Math.floor(i / 2) * 0.55;
    line(s, x, y, 1.72, 0, k[1], 0.9);
    T(s, k[0], { x, y: y + 0.07, w: 1.75, h: 0.4, fontSize: 8.5, color: TEXT });
  });
  T(s, [{ text: "HIRING NEXT · ", options: { color: MUTED } }, { text: "a software engineer who also writes firmware.", options: { color: TEXT } }], { x: 5.95, y: 4.55, w: 2.0, h: 0.6, fontSize: 7.5 });
  s.addImage({ path: A + "mascot2.png", x: 7.95, y: 4.2, w: 1.6, h: 1.6 * 210 / 345 });
}

pres.writeFile({ fileName: OUT }).then(() => console.log("wrote", OUT, "slides:", pres.slides.length));

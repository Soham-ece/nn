from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.platypus import (BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, Table, TableStyle,
                                PageBreak, KeepTogether, NextPageTemplate)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

OUT = "/home/user/nn/protopulse_murder_board/Protopulse_Murder_Board_Report.pdf"
D = "/usr/share/fonts/truetype/dejavu/"
pdfmetrics.registerFont(TTFont("DV", D + "DejaVuSans.ttf"))
pdfmetrics.registerFont(TTFont("DV-B", D + "DejaVuSans-Bold.ttf"))
pdfmetrics.registerFont(TTFont("DV-I", "/usr/share/fonts/truetype/freefont/FreeSansOblique.ttf"))
pdfmetrics.registerFont(TTFont("DV-BI", "/usr/share/fonts/truetype/freefont/FreeSansBoldOblique.ttf"))
from reportlab.pdfbase.pdfmetrics import registerFontFamily
registerFontFamily("DV", normal="DV", bold="DV-B", italic="DV-I", boldItalic="DV-BI")

DARK = colors.HexColor("#0F2A22"); GREEN = colors.HexColor("#1B4D3E"); MINT = colors.HexColor("#E8F1EC")
COPPER = colors.HexColor("#C8793A"); COPPER_L = colors.HexColor("#F6E7D8"); INK = colors.HexColor("#1D2522")
MUTED = colors.HexColor("#5E6B66"); LINE = colors.HexColor("#C9D6CF")

body = ParagraphStyle("body", fontName="DV", fontSize=9.2, leading=13.2, textColor=INK, spaceAfter=5)
small = ParagraphStyle("small", parent=body, fontSize=7.8, leading=10.5, textColor=MUTED, spaceAfter=3)
cell = ParagraphStyle("cell", parent=body, fontSize=7.9, leading=10.2, spaceAfter=0)
cellb = ParagraphStyle("cellb", parent=cell, fontName="DV-B")
cellh = ParagraphStyle("cellh", parent=cell, fontName="DV-B", textColor=colors.white)
h1 = ParagraphStyle("h1", fontName="DV-B", fontSize=16, leading=20, textColor=DARK, spaceBefore=4, spaceAfter=8)
h2 = ParagraphStyle("h2", fontName="DV-B", fontSize=11.5, leading=15, textColor=GREEN, spaceBefore=9, spaceAfter=4)
kick = ParagraphStyle("kick", fontName="DV-B", fontSize=7.5, leading=10, textColor=COPPER, spaceAfter=2)
bul = ParagraphStyle("bul", parent=body, leftIndent=11, bulletIndent=2, spaceAfter=2.5)
quote = ParagraphStyle("quote", parent=body, fontName="DV-I", textColor=GREEN, leftIndent=8, backColor=MINT,
                       borderPadding=(5, 6, 5, 6), spaceBefore=4, spaceAfter=8)
answer = ParagraphStyle("answer", parent=body, fontName="DV-B", textColor=DARK, backColor=COPPER_L,
                        borderPadding=(5, 6, 5, 6), spaceBefore=4, spaceAfter=8)

for _st in (h1, h2, kick, quote): _st.keepWithNext = 1
S = []
P = lambda t, st=body: S.append(Paragraph(t, st))
def B(items):
    for t in items:
        S.append(Paragraph(t, bul, bulletText="•"))
def H1(t, k=None):
    if k: S.append(Paragraph(k.upper(), kick))
    S.append(Paragraph(t, h1))
def H2(t): S.append(Paragraph(t, h2))
def SP(h=4): S.append(Spacer(1, h))

def T(rows, widths, hl_last=False, first_bold=True):
    data = []
    for i, r in enumerate(rows):
        row = []
        for j, c in enumerate(r):
            st = cellh if i == 0 else (cellb if (j == 0 and first_bold) else cell)
            row.append(Paragraph(str(c), st))
        data.append(row)
    W = 174 * mm
    t = Table(data, colWidths=[W * w for w in widths], repeatRows=1)
    ts = [("BACKGROUND", (0, 0), (-1, 0), GREEN), ("GRID", (0, 0), (-1, -1), 0.4, LINE),
          ("VALIGN", (0, 0), (-1, -1), "TOP"), ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
          ("LEFTPADDING", (0, 0), (-1, -1), 4), ("RIGHTPADDING", (0, 0), (-1, -1), 4)]
    for i in range(1, len(rows)):
        if i % 2 == 1: ts.append(("BACKGROUND", (0, i), (-1, i), MINT))
    if hl_last: ts.append(("BACKGROUND", (0, len(rows) - 1), (-1, len(rows) - 1), COPPER_L))
    t.setStyle(TableStyle(ts))
    S.append(t); SP(8)

def Q(n, text, ans):
    S.append(Paragraph(f"Question {n}", kick))
    S.append(Paragraph(f"“{text}”", quote))
    S.append(Paragraph(ans, answer))

# ============================================================ COVER
S.append(Spacer(1, 40 * mm))
S.append(Paragraph("PROTOPULSE", ParagraphStyle("c0", fontName="DV-B", fontSize=12, textColor=COPPER, leading=16)))
S.append(Spacer(1, 6))
S.append(Paragraph("Murder board, round 1: answers, competition and market study",
                   ParagraphStyle("c1", fontName="DV-B", fontSize=25, leading=31, textColor=colors.white)))
S.append(Spacer(1, 10))
S.append(Paragraph("Responses to Prateek's feedback on the Baker and Mixer pitch, with sourced competitor prices, a bottom-up market estimate, machine economics and the revised positioning: Proto first, Baker first.",
                   ParagraphStyle("c2", fontName="DV", fontSize=11, leading=16, textColor=colors.HexColor("#D3E5DB"))))
S.append(Spacer(1, 60 * mm))
S.append(Paragraph("Delhi · 30 September 2026 · Companion files: Protopulse_Pitch_v2.pptx, Protopulse_Economics_Model.xlsx",
                   ParagraphStyle("c3", fontName="DV", fontSize=8.5, textColor=colors.HexColor("#D3E5DB"))))
S.append(NextPageTemplate("body")); S.append(PageBreak())

# ============================================================ SUMMARY
H1("Summary", "One page")
P("Prateek's feedback was right on almost every point, and the pitch now reflects it. The short version:")
T([
    ["Feedback", "Our answer", "Evidence"],
    ["Pitch Proto, not two robots", "Agreed. Protopulse is an AI prototyping company. Baker and Mixer are the first machines Proto drives.", "§2.1, deck slides 6–8"],
    ["Don't look like a desktop PCB mill", "Baker is a prototyping cell: mill, mask, stencil, paste, reflow and test in one frame. We explain why mills struggled.", "§2.2, §3.3"],
    ["Avoid strong claims", "Every claim rewritten against evidence. 'Replaces a fabrication order' is gone: we complement fabs.", "§2.3"],
    ["Two products on ₹10 lakh is aggressive", "Phase 1 funds Proto + Baker. Mixer is built only as Baker's test head (₹74,847, 17% of the hardware budget).", "§2.4"],
    ["Competition and market study", "14 alternatives priced with sources; bottom-up India pool of ₹303.6 Cr hardware + ₹48.7 Cr/yr software.", "§3, §4"],
    ["'Design at night, board in the morning'", "Replaced with a measured target: 81–141 min per board, about 15–20 min of it hands-on.", "§2.6"],
    ["Machine cost and payback", "Build ₹1,44,842; proposed price ₹3,49,000 (58.5% margin); pays back after 59 boards against JLCPCB.", "§2.7"],
    ["1,000 / 10,000 / 1 lakh boards?", "Baker isn't for production. 1,000 boards a year = 2 Bakers; 10,000+ belongs at a fab, fed with files Proto has already checked.", "§2.8"],
], [0.25, 0.53, 0.22])
H2("Numbers to remember")
T([
    ["Metric", "Value", "Basis"],
    ["Baker prototype build", "₹3,73,418", "Cost report, 29 Sep 2026 (35% duty/courier + 15% contingency)"],
    ["Mixer prototype build", "₹74,847", "Cost report"],
    ["Baker production unit (100-unit batch)", "₹1,44,842", "China parts, Delhi assembly + QC"],
    ["Mixer production unit", "₹13,740", "8-bit converters, no screen"],
    ["Proposed price, Baker + Mixer (ex-GST)", "₹3,49,000 + ₹24,999 = ₹3,73,999", "Proposal, to be tested in pilots"],
    ["Consumables per board (Baker)", "₹334", "Economics model, Board Cost sheet"],
    ["Same assembled board from JLCPCB, landed in India", "₹6,721 and 7–20 days", "JLCPCB pricing + DHL + 10% BCD / 18% IGST"],
    ["Break-even", "59 boards (JLCPCB) · 73 boards (Indian 24-h fab, bare)", "Direct cash only"],
    ["Cycle time target", "81–141 min per board; ≈15–20 min hands-on", "Engineering target, to be measured"],
    ["Capacity", "750–1,250 boards per machine per year, one shift", "3–5 boards per 8-h shift"],
    ["Phase 1 ask", "₹10,00,000 over ~9 months", "Use of funds §2.4"],
], [0.38, 0.30, 0.32])
S.append(PageBreak())

# ============================================================ THESIS
H1("1. The revised thesis: frictionless prototyping, with AI that can touch the real world", "Positioning")
H2("1.1 Software became frictionless; hardware didn't")
P("Reasoning models are now good at chaining tools together. For software, the loop is closed: a model writes code, runs it, reads the error and fixes it. That's why someone with a commerce degree can build a working app. Lovable, the clearest example, reached <b>$100M ARR eight months after launch</b> (TechCrunch, 23 Jul 2025) and about <b>$400M ARR by February 2026</b>, with 2.3 million active users and 180,000 paying subscribers. Most of those users aren't programmers.")
P("Hardware has no closed loop. A model can already produce a schematic or a Gerber file. It can't make the board, can't power it up, and can't see whether it works. In India, one assembled prototype board from JLCPCB takes <b>7–20 days door to door</b> and costs about <b>₹6,721 per iteration</b> before components (see §2.7). Every design change restarts that clock.")
H2("1.2 The AI half is already proven, at the file layer")
T([
    ["Company / tool", "What it does", "Proof point", "Where it stops"],
    ["Flux", "AI hardware design (browser EDA + copilot)", "$49M raised in total, incl. $27M Series B (Feb 2026); 1M+ users; plans $15–49 per editor/month", "Design files"],
    ["Quilter", "Physics-driven AI PCB layout", "$25M Series B led by Index (Oct 2025); $40M raised in total", "Layout files"],
    ["Diode Computers", "AI PCB design, code-described boards", "$11.4M Series A led by a16z", "Design files, sent to a fab"],
    ["Claude ↔ Autodesk Fusion", "Official MCP connector; drives a live Fusion session", "Released May 2026", "CAD geometry"],
    ["Claude ↔ Blender", "Official Blender MCP server (bpy tools)", "Released 27 Apr 2026", "3D scenes"],
], [0.2, 0.28, 0.34, 0.18])
P("Roughly $100M of venture money has gone into AI that produces hardware <i>files</i>. None of these companies owns a machine that turns the file into a board, or an instrument that reports back whether the board works. That missing piece is the Protopulse opportunity.")
H2("1.3 What Protopulse is")
S.append(Paragraph("Protopulse builds smart prototyping machines and accessories that an AI can operate, so that going from an idea to a working, tested prototype feels effortless. Proto is the AI. Baker and Mixer are its first two machines. We will run software and hardware teams that keep improving both, outsource manufacturing to a China turnkey partner, and do only testing and minimal assembly in India before shipping: India first, then global.", answer))
P("Proto takes a single input (an idea, a sketch, a photo, or existing KiCad, Flux or Fusion files) and plans the whole prototype: the specification, parts that are actually in stock, schematic and layout through EDA connectors, a fabrication plan for Baker, and a test plan for Mixer. Over time it takes over the machines, including a 3D printer for enclosures and jigs. It sets out the hardware and the firmware, tests the board with real signals, flags what's wrong and guides the user to the fix. Once a design is frozen, Proto sends files that have already worked on a real board to a fab for volume.")
H2("1.4 How people learn hardware, and why ease is the market")
P("People learn practical skills by doing: they try, see what happens, think about it and adjust (Kolb's experiential learning cycle). How fast that loop turns decides how fast they learn. Hardware makes a beginner climb a ladder where every rung needs new knowledge before they can go on, and each rung loses people:")
T([
    ["Rung", "What you have to know first", "Typical bottleneck", "What Protopulse takes over"],
    ["1 Idea → spec", "How to state requirements", "Vague goals, scope creep", "Proto interviews the user and writes the spec"],
    ["2 Parts", "Datasheets, footprints, availability", "Hours of searching; parts go out of stock", "Proto picks in-stock parts through parts APIs"],
    ["3 Schematic", "Circuit theory, reference designs", "Subtle errors that only show up on the bench", "Proto starts from reference designs and runs ERC"],
    ["4 Layout", "An EDA tool, DRC, manufacturability", "Weeks of learning a tool", "Proto drives EDA tools; Baker-specific DRC"],
    ["5 Fabrication", "Gerbers, vendors, customs", "7–20 days to India per attempt", "Baker makes the board the same day"],
    ["6 Assembly", "SMD soldering, stencils, reflow", "Skill and equipment", "Baker stencils, pastes and reflows; the jig guides placement"],
    ["7 Bring-up", "Scope, logic analyser, firmware", "You can't tell what's wrong", "Mixer measures; Proto explains in plain words"],
    ["8 Iterate / volume", "Root-cause debugging, DFM", "Slow loops mean fewer attempts", "Proto proposes the fix; hands off to a fab when ready"],
], [0.15, 0.25, 0.27, 0.33])
P("Every rung that gets easier brings in a new group of builders: product designers, domain experts, students, first-time founders. Lovable showed what happens to a market when the coding rung goes away. Our bet is the same thing for hardware, and it can't happen in software alone because rungs 5–7 are physical.")
S.append(PageBreak())

# ============================================================ ANSWERS
H1("2. Answers to each question, in detail", "Murder board")
Q(1, "I think the strongest moat is hidden in the idea. If I were the founder, I would pitch Proto instead of two hardware robots (Baker and Mixer).",
  "Agreed. The company is Proto. Baker and Mixer are how Proto acts in the physical world and how it collects data nobody else has.")
P("The defensible asset is the <b>closed-loop dataset</b>. Every run links a design to the process settings Baker used and the measurements Mixer took. File-only AI tools (Flux, Quilter, Diode) can't collect this, because the board is made somewhere they can't see. Over time this data lets Proto predict whether a design will work on the bench before it's made: which trace widths fail, which footprints bridge, which power designs brown out. It gets better with every installed machine.")
B(["<b>Agent-native machines.</b> Baker (Klipper + Moonraker) and Mixer (FPGA over USB) are designed to expose their state, calibration and actions to an agent through MCP-style tools, the same mechanism Anthropic and Autodesk use for the Fusion connector. Existing machines were built for a person at a keyboard.",
   "<b>Process IP.</b> Milling, masking and stencil cutting all happen in one coordinate frame from the same Gerber, so there's no separate stencil-alignment step. A stand-alone mill doesn't have this.",
   "<b>Cost base.</b> ₹1,44,842 production Baker; China turnkey build, India test.",
   "<b>Recurring revenue.</b> Proto subscription + consumable kits ≈ ₹1,64,838 per machine per year (§5)."])
P("The deck now opens with the software/hardware gap and Proto (slides 3–8). Baker and Mixer come after, as the first two machines.")

Q(2, "We should not project this as a desktop PCB mill, which has a rough history.",
  "Agreed, and we now address that history directly. Baker isn't a mill. It's a cell that goes from bare FR4 to a pasted, reflowed and tested board. The companies that struggled automated one step and sold it to experts.")
T([
    ["Company", "What happened", "Why, in our reading", "What we do differently"],
    ["Othermill → Bantam Tools", "Kickstarter 2013 (>$300k). Bought by Bre Pettis in May 2017 and renamed. Later dropped its PCB and CNC milling machines; now sells art machines (pen plotters).", "A mill does one step. Users still needed mask, stencil and assembly elsewhere, and debugged by hand.", "Mill + mask + stencil + paste + reflow + test in one frame"],
    ["Voltera V-One", "Ink-based PCB printer (≈€3,850 ex-VAT at EU resellers; out of stock at Elektor). The company moved upmarket to NOVA ($45,974) for flexible hybrid electronics.", "Conductive ink isn't copper FR4, so hobbyist demand was limited.", "Real copper FR4 that solders like a fab board"],
    ["BotFactory", "Squink sold at $3,199–4,499; SV2 is now price-on-request, a research niche.", "Same ink limits, small expert market.", "Sell an outcome to non-experts"],
    ["Nano Dimension DragonFly", "Additive-electronics unit sold to Inspira Technologies in April 2026: $2M cash plus up to $10.5M earn-out.", "High-end, expensive, and no clear link to a mass user base.", "India price point; Proto as the product"],
], [0.17, 0.33, 0.25, 0.25])
P("Three more lessons shape the pitch: (1) don't compete with $2 fab boards on cost per board, compete on hours per loop; (2) don't sell a tool that needs an expert, sell a tested prototype to someone who isn't one yet; (3) a machine without software can be copied, so the software and data have to be the moat.")
P("<b>Language change:</b> 'desktop PCB mill' is gone from the deck. We say 'AI prototyping cell' (Baker) and 'agent-driven test head' (Mixer).")

Q(3, "Avoid strong claims like 'replaces a fabrication order'. How would an investor who has backed hardware manufacturing companies take it? Softer claims are better: lower cost, faster lead time, etc.",
  "Agreed. We checked every claim against evidence and rewrote it. We position Baker as complementing fabs: it handles iterations 1 to 10, and a fab handles volume.")
T([
    ["Old claim", "New claim", "Evidence / caveat"],
    ["Replaces a fabrication order", "Same-day prototype iterations; frozen designs go to a fab with files that have already worked on a real board", "Fab wins above ~10 identical boards (§2.8)"],
    ["Send the design at night, pick it up in the morning", "Target: 81–141 min per board, ≈15–20 min of it hands-on", "Engineering target; Phase 1 measures it"],
    ["Fully automated", "Steps 01–12 and reflow are automated; parts are placed by hand into a printed jig", "Manual placement by design: cheaper, and a person stays in the loop"],
    ["Desktop PCB mill", "AI-driven prototyping cell", "Mask, stencil, paste, reflow and test are in scope"],
    ["Better than lab instruments", "An agent-driven test head in the Analog Discovery class; production Mixer has 8-bit converters (AD3: 14-bit)", "Competes on price and integration, not resolution"],
    ["Cheaper boards", "≈₹334 of consumables per board vs ≈₹6,721 landed from JLCPCB; pays back after ~59 boards", "Direct cash only; components excluded on both sides"],
], [0.28, 0.42, 0.30])
P("The first two rows came from Prateek. We tightened the rest ourselves, on the same principle.")

Q(4, "Two products for a first raise of ₹10 lakh is, in my opinion, a bit aggressive. We should go step by step. Maybe start with Baker first?",
  "Agreed. Phase 1 funds Proto + Baker. Mixer isn't launched as a second product. It's built as Baker's test head, because a board isn't done until it's tested. It's 17% of the hardware budget and also becomes the China factory's test fixture.")
T([
    ["Line", "₹", "Share", "Basis"],
    ["Baker prototype (full BOM, 35% duty/courier on imports, 15% contingency)", "3,73,418", "37.3%", "Cost report 29 Sep 2026"],
    ["Mixer prototype, built as Baker's test head", "74,847", "7.5%", "Cost report 29 Sep 2026"],
    ["Process validation: consumables + rev-B parts for the open points", "1,20,000", "12.0%", "Plan"],
    ["Proto software: LLM API, cloud, dev tools (12 months)", "1,00,000", "10.0%", "Plan"],
    ["Safety review (Class 4 laser, electrical) + provisional patent", "90,000", "9.0%", "Plan"],
    ["Reserve", "86,735", "8.7%", "Plan"],
    ["Workshop tools and bench equipment", "80,000", "8.0%", "Plan"],
    ["Pilot programme: 3 sites (install, travel, shipping)", "75,000", "7.5%", "Plan"],
    ["Total", "10,00,000", "100%", "Founder salaries not included (to confirm)"],
], [0.52, 0.14, 0.1, 0.24], hl_last=True)
H2("Milestones and exit test")
T([
    ["Month", "Milestone", "How we'll show it"],
    ["M3", "Baker assembled; Zone A mills and drills", "Video + first isolation-milled boards"],
    ["M5", "First board through all 15 steps", "Board, process log, cycle-time sheet"],
    ["M6", "4 open process points closed with data", "Coupon measurements vs targets (0.5 mm pitch, ±50 µm)"],
    ["M7", "Proto takes a prompt to a tested board on 3 reference designs", "Recorded end-to-end runs"],
    ["M9", "3 pilot sites, 50 boards, measured cycle time, letters of intent", "Pilot report; LOIs"],
], [0.1, 0.45, 0.45])
P("<b>Phase 2 (seed, months 9–18):</b> 5–30 EVT/DVT units through a China partner, first paid customers (colleges and startups), Mixer launched commercially, Proto subscriptions start. <b>Phase 3 (18–36 months):</b> PVT and a 100-unit batch, 3D-printer integration, fab hand-off partnerships, first markets outside India. Each phase has an exit test before we raise the next.")

Q(5, "I think a thorough competition analysis and market study is needed. I also strongly recommend looking at the competition and their pricing.",
  "Done: §3 prices 14 alternatives across five categories with a source for each, and says where each loses to us and where it beats us. §4 builds the market bottom-up from Indian institutional and startup counts.")

Q(6, "'Send the design at night, pick it up in the morning' is a bit too aggressive a claim. We have to load boards, place components, etc. So it's not fully automated.",
  "Agreed; the claim is gone. The honest target is 81–141 minutes per board (100 × 160 mm, about 40 parts), with roughly 15–20 minutes of it hands-on. Placement is manual by design.")
T([
    ["Step", "Target (min)", "Hands-on?", "Note"],
    ["01 Load + 02 probe height map", "5", "Load only", "Magazine feed; two registration pins"],
    ["03 Isolation mill", "25–45", "No", "Depends on copper area and trace count"],
    ["03 Drill", "5–10", "No", "~50 holes, 0.3–1.2 mm carbide"],
    ["04 Vacuum clean", "2", "No", ""],
    ["06–09 Mask coat, UV image, develop, flood cure", "14–25", "No", "10.1 in 12K LCD, 405 nm; Na₂CO₃ wipe"],
    ["10 Laser-cut stencil", "5–10", "No", "10 W 445 nm diode on polyimide film"],
    ["11–12 Clamp, paste, release", "3", "No", "Electromagnet clamp; film cut-off"],
    ["Placement jig print", "0 (parallel)", "No", "30–45 min incl. wash/cure, during steps 01–12"],
    ["13 Manual placement", "7–14", "Yes", "~40 parts at 10–20 s each into jig pockets"],
    ["14 Reflow + cool", "10–12", "No", "Sn42Bi58, melts at 138 °C"],
    ["15 Test on Mixer", "5–15", "Hook-up", "Proto runs the generated test plan"],
    ["Total", "81–141", "≈15–20", "3–5 boards per 8-hour shift"],
], [0.36, 0.14, 0.14, 0.36], hl_last=True)
P("These are engineering targets from our process design. They aren't measurements yet. Phase 1 milestone M5 produces the measured numbers, and we'll replace this table with them.", small)

Q(7, "How much is this machine going to cost? Say X lakh. We also need to see how many boards get made, and whether that cancels my cost.",
  "Build cost is ₹1,44,842 at a 100-unit batch (the prototype is ₹3,73,418). The proposed price is ₹3,49,000 ex-GST (58.5% gross margin). Baker + Mixer pay back after about 59 boards against ordering from JLCPCB, which is about 7 months for a startup iterating twice a week.")
H2("7a. What it costs to build")
T([
    ["", "Baker", "Mixer", "What drives it"],
    ["Prototype build (India, retail)", "₹3,73,418", "₹74,847", "Finished linear stages, Pi 5 + Octopus + DM556 drivers, separate resin printer, 35% duty/courier on imports, 15% contingency"],
    ["Production unit (China parts, Delhi build, 100 units)", "₹1,44,842", "₹13,740", "SFU1605 + HGR15 axes (≈₹5,500 vs ₹16,500 per axis), CB1 + Manta M8P (≈₹10,800), one 24 V rail; includes ₹14,775 duty, ₹3,520 freight, ₹12,000 assembly + QC"],
    ["Proposed price (ex-GST)", "₹3,49,000", "₹24,999", "Between desktop CNC (Carvera $5,799 ≈ ₹5.1 lakh) and pro lines (LPKF, quote-only)"],
    ["Gross margin", "58.5%", "45.0%", "Bundle 57.6%"],
], [0.26, 0.12, 0.1, 0.52])
H2("7b. What one board costs: Baker vs ordering it")
T([
    ["Baker consumables per board", "₹", "Basis"],
    ["FR4 copper-clad 100 × 150 mm", "99", "Listing ₹99"],
    ["Placement-jig resin (TR300, ~15 g)", "113", "₹7,500/kg"],
    ["V-bit wear (~5 boards per bit)", "42", "$23.99 per 10 bits"],
    ["Drill wear (~50 boards per set)", "30", "₹1,500 set"],
    ["Stencil film", "25", "₹3,150 roll (estimate per board)"],
    ["Electricity (~1.5 kWh)", "12", "₹8/kWh"],
    ["Solder mask, paste, developer, IPA", "13", "Grams-per-board estimates"],
    ["Total", "≈334", "Components excluded"],
], [0.5, 0.15, 0.35], hl_last=True)
T([
    ["JLCPCB assembled prototype landed in India", "USD", "₹"],
    ["5 PCBs, 100 × 160 mm (estimate; $2 tier only covers ≤100 × 100)", "5.00", "440"],
    ["PCBA setup fee + stencil", "9.50", "836"],
    ["SMT joints (200 × $0.0017) + extended-part fees (3 × $3, assumed)", "9.34", "822"],
    ["DHL/UPS express to India (midpoint of $25–45)", "35.00", "3,080"],
    ["Customs: 10% BCD + 18% IGST (effective 29.8%)", "–", "1,543"],
    ["Total per iteration (7–20 days door to door)", "", "≈6,721"],
], [0.7, 0.12, 0.18], hl_last=True)
H2("7c. Does it cancel the cost?")
T([
    ["Baker price (ex-GST)", "Gross margin", "Break-even boards vs JLCPCB", "Startup (2/week)", "College lab (1/week)"],
    ["₹2,99,000", "51.6%", "51", "6.4 months", "12.8 months"],
    ["₹3,49,000 (proposed)", "58.5%", "59", "7.4 months", "14.8 months"],
    ["₹3,99,000", "63.7%", "67", "8.4 months", "16.8 months"],
    ["₹4,49,000", "67.7%", "75", "9.4 months", "18.8 months"],
], [0.22, 0.15, 0.25, 0.19, 0.19])
P("Break-even = (Baker + Mixer price) ÷ (₹6,721 − ₹334) saving per board, assuming 48 working weeks. Against an Indian 24-hour fab (₹3,000–8,000 for 5 bare two-layer boards; midpoint ₹5,500) it's 73 boards, and that still leaves out stencil and assembly. None of this counts engineer time or the 7–20 days of waiting, which for a funded startup is usually the bigger cost. The economics workbook lets Prateek put in any 'X lakh' and usage rate and see it recalculate.")

Q(8, "Innovation is good but may not scale in a production environment. 1,000 boards? 10,000? 1 lakh?",
  "Baker isn't a production machine and we don't pitch it as one. It covers a design's first 1–10 boards. Our scale comes from the number of labs and teams using Proto, not from boards per machine. Beyond ~10 identical boards, a fab is cheaper, and Proto sends it files that have already worked.")
T([
    ["Boards per year", "Bakers needed (1 shift, slow cycle)", "Right tool", "Why"],
    ["10", "1", "Baker", "Same-day iteration; fab minimums and shipping dominate"],
    ["100", "1", "Baker", "One machine covers a busy lab or startup"],
    ["1,000", "2", "Baker for iterations, fab for batches", "Any run of >10 identical boards goes to a fab"],
    ["10,000", "14", "Fab / EMS", "That's production. Proto exports the checked Gerber/BOM/CPL"],
    ["1,00,000", "134", "Fab / EMS", "Not what Baker is for"],
], [0.17, 0.2, 0.25, 0.38])
P("Capacity per machine: 3–5 boards per 8-hour shift, so 750–1,250 boards a year on one shift. Scaling Protopulse itself (making many Bakers) is covered by the China turnkey plan in §6: RFQs at 5 to 5,000 units, with NPI gates from EVT to mass production.")
S.append(PageBreak())

# ============================================================ COMPETITION
H1("3. Competition study", "Market map and pricing")
P("Prices are list prices from the source shown, converted at ₹88/$ to match the 29 Sep cost report. They exclude Indian import duty and GST, so landed prices in India are higher. Where a vendor only quotes, we say so rather than guess.")
H2("3.1 Price table")
T([
    ["Product", "Category", "List price", "≈₹ (₹88/$)", "Source"],
    ["LPKF ProtoMat (E44/S64/S104)", "Pro in-house PCB", "Quote-only. A full S104 line bought new in 2019 cost ≈$96,000", "≈₹84 lakh (full line)", "lpkf.com; exapro.com used listing"],
    ["Voltera NOVA", "Printed electronics", "$45,974", "≈₹40.5 lakh", "store.voltera.io"],
    ["Voltera V-One", "Ink PCB printer", "€3,850 ex-VAT (EU reseller); out of stock at Elektor", "–", "eleshop.eu; elektor.com"],
    ["Makera Carvera", "Desktop CNC", "$5,799 MSRP", "≈₹5.1 lakh", "Makera PR, Jun 2026"],
    ["Makera Carvera Air", "Desktop CNC", "$2,699 regular", "≈₹2.4 lakh", "Makera PR, Jun 2026"],
    ["BotFactory Squink / SV2", "Ink PCB + pick-and-place", "$3,199–4,499 / on request", "≈₹2.8–4.0 lakh", "TechCrunch; BotFactory"],
    ["Bantam Tools PCB mill", "Desktop PCB mill", "Discontinued", "–", "ToolGuyd"],
    ["Neoden YY1", "Pick-and-place only", "Under $3,000", "<₹2.6 lakh", "EEVblog"],
    ["JLCPCB → India", "Fab + assembly service", "$2 for 5 PCBs; PCBA $8 setup + $1.50 stencil", "≈₹6,721 per assembled iteration", "jlcpcb.com; zbotic.in"],
    ["PCB Power / Lion Circuits", "Indian fab", "₹2,000–8,000 for 5 boards (24–48 h); Lion standard 5–7 days", "same", "zbotic.in"],
    ["Digilent Analog Discovery 3", "USB instrument", "$375–379", "≈₹33,000", "Jameco; DigiKey"],
    ["ADALM2000", "USB instrument", "$237–262", "≈₹21,000–23,000", "Mouser; Richardson RFPD"],
    ["Moku:Go M0 / M1 / M2", "USB instrument", "$599 / $699 / $799", "≈₹53,000–70,000", "TEquipment"],
    ["Red Pitaya STEMlab 125-14", "FPGA instrument", "$490 (Low Noise kit $716)", "≈₹43,000", "redpitaya.com"],
    ["Saleae Logic 8 / Pro 16", "Logic analyser", "$499 / $1,499", "≈₹44,000 / 1.3 lakh", "saleae.com"],
    ["Rigol DHO804", "Bench scope", "$492–579", "≈₹43,000–51,000", "electro-meters.com"],
    ["Flux", "AI PCB design SaaS", "$15 / $39 / $49 per editor per month", "≈₹1,300–4,300/month", "flux.ai"],
    ["Protopulse Baker + Mixer", "AI prototyping cell", "₹3,49,000 + ₹24,999 (proposed, ex-GST)", "₹3.74 lakh", "This report"],
], [0.22, 0.16, 0.28, 0.15, 0.19], hl_last=True)
H2("3.2 Where each alternative loses to us, and where it wins")
T([
    ["Alternative", "We win on", "They win on (we say so)"],
    ["Fab services (JLCPCB, PCBWay, Indian fabs)", "Hours instead of weeks; no customs; stencil, assembly and test included; a much faster learning loop", "Cost at quantity, multilayer, finish quality. We send volume to them"],
    ["Pro in-house lines (LPKF)", "About 1/20th the price of a full line; one box; run by an agent; no specialist operator", "RF and multilayer capability, through-hole plating, decades of process"],
    ["Desktop CNC (Carvera)", "Mask, stencil, paste, reflow, test; board-specific AI", "General-purpose machining of metal, wood and plastic"],
    ["Ink printers (Voltera, BotFactory)", "Real copper FR4 that solders and behaves like a fab board", "Flexible and stretchable substrates"],
    ["USB instruments (AD3, M2K, Moku, Red Pitaya)", "Test plan generated from the netlist; agent-driven; integrated programmable supplies + 24-bit meter", "Resolution and bandwidth (AD3 14-bit; Moku, Red Pitaya higher bandwidth)"],
    ["AI design tools (Flux, Quilter, Diode)", "A closed loop to a real, measured board; physical run data", "Layout depth. We integrate with them: Proto can take their output and make it real"],
], [0.25, 0.42, 0.33])
H2("3.3 Why they haven't done this already")
B(["<b>Fabs</b> make money on volume. A same-day one-off in the customer's lab cannibalises nothing of theirs, but it isn't their business either. That's why we can partner rather than compete.",
   "<b>Machine makers</b> (LPKF, Makera) sell tools to experts. They'd have to build the agent layer and the test loop from scratch.",
   "<b>AI design companies</b> are software businesses. Building and supporting machines is a different company, and that's our wedge.",
   "<b>Instrument makers</b> sell resolution and bandwidth to engineers. An agent-first, low-cost test head doesn't fit their price ladder."])
S.append(PageBreak())

# ============================================================ MARKET
H1("4. Market study", "Bottom-up, India first")
H2("4.1 Who buys, and with what budget")
T([
    ["Segment", "Size", "Budget signal", "Fit"],
    ["Engineering colleges", "5,868 AICTE-approved colleges; 23.2 lakh B.Tech students (AISHE)", "AICTE IDEA Labs: ≈₹1.1 Cr envisaged per lab (₹55 lakh from AICTE)", "Baker + Mixer + Proto Lab licence; labs and capstone projects"],
    ["School tinkering labs", "10,000 ATLs across 722 districts, 1.1 crore students; 50,000 more announced for the next 5 years", "₹20 lakh per ATL: ₹10 lakh setup + ₹10 lakh O&M over 5 years", "Mixer + Proto first (safety); Baker for senior or hub labs"],
    ["Startups", "2.25 lakh DPIIT-recognised startups (early 2026)", "Hardware startups spend on iteration speed", "Fastest decisions; highest usage"],
    ["Semiconductor / design programmes", "C2S: 305 academic institutions + 95 DLI startups", "Government-funded design programmes", "Board-level bring-up for chip designs"],
    ["Global makerspaces", "2,300+ Fab Labs in 120+ countries", "Institutional equipment budgets", "Phase 3 export"],
], [0.18, 0.3, 0.27, 0.25])
H2("4.2 Sizing")
T([
    ["Line", "Buyers", "Value"],
    ["Colleges: 5,868 × ₹3,73,999 (one Baker + Mixer each)", "5,868", "₹219.5 Cr"],
    ["Startups: 1% of 2.25 lakh as hardware-relevant buyers × ₹3,73,999", "2,250", "₹84.1 Cr"],
    ["India one-time hardware pool (upper bound)", "8,118", "₹303.6 Cr"],
    ["Proto Lab subscriptions on that base (₹4,999 × 12)", "8,118", "₹48.7 Cr per year"],
    ["3-year target: 100 installed Bakers (≈1.2% of the pool)", "100", "₹3.74 Cr hardware + ≈₹1.65 Cr/yr recurring"],
], [0.62, 0.13, 0.25])
P("The 1% startup share is our assumption; everything else comes from the sources listed. This is an upper bound for the beachhead, not a forecast.")
H2("4.3 Global context")
B(["Oscilloscope market ≈$2.6–2.9B in 2025, growing 7–8% a year (Fortune Business Insights and others); Asia-Pacific is 41.2% of it.",
   "Smart desktop CNC milling machines: $1,015M in 2024, forecast $1,418M by 2031 (3.9% CAGR).",
   "India electronics production: ₹11.3 lakh crore in FY2024-25, up from ₹1.9 lakh crore in FY2014-15 (MeitY). More design work in India means more prototypes."])
S.append(PageBreak())

# ============================================================ BUSINESS MODEL
H1("5. Business model and unit economics", "How Protopulse makes money")
T([
    ["Stream", "Price (proposed)", "Unit cost", "Margin", "Note"],
    ["Baker", "₹3,49,000 ex-GST", "₹1,44,842", "58.5%", "One-time"],
    ["Mixer", "₹24,999 ex-GST", "₹13,740", "45.0%", "Sold with Baker in Phase 2; standalone later"],
    ["Proto Lab subscription", "₹4,999/month after year 1", "Cloud/LLM cost to measure", "Software margin", "Year 1 included with Baker"],
    ["Consumable kits", "₹699 per board", "₹334", "52%", "FR4, mask, paste, film, jig resin"],
    ["Fab hand-off (later)", "Referral", "–", "–", "Checked files to partner fabs for 100+ units"],
], [0.2, 0.22, 0.19, 0.14, 0.25])
P("<b>Recurring revenue per installed Baker</b> (after year 1, at 150 boards a year): Proto ₹59,988 + consumables ₹1,04,850 = <b>₹1,64,838 revenue</b>, and ₹1,14,810 gross profit before cloud cost. That's roughly half the machine price again every year, which is why the machine opens the account and Proto keeps it.")
P("All prices are proposals. The Phase 1 pilots test willingness to pay at ₹2.99–3.99 lakh, and measure cloud cost per lab before we fix the subscription price.", small)

# ============================================================ TECH
S.append(PageBreak())
H1("6. Technology and manufacturing, in brief", "Detail is in deck slides 8–15 and 24")
H2("6.1 Proto")
B(["<b>Interface:</b> chat, sketch/photo upload, project timeline, Baker touch screen.",
   "<b>Reasoning:</b> a frontier LLM accessed through an API (swappable), plus a planner that breaks a goal into spec → parts → schematic → layout → fab plan → test plan.",
   "<b>Tools via MCP:</b> KiCad scripting, Flux/KiCad import, Fusion and Blender connectors for enclosures, parts APIs for stock and price, ngspice, PlatformIO/arduino-cli.",
   "<b>Machine drivers:</b> Baker through Klipper + Moonraker (motion, spindle, laser, UV, pumps, hotplate); Mixer's FPGA over USB; resin/FDM printer driver.",
   "<b>Verification:</b> ERC/DRC plus Baker-specific DRC (V-bit trace/space, laser stencil apertures); test plan generated from the netlist.",
   "<b>Safety:</b> human approval before anything is cut, lasered or powered; firmware interlocks; current limits; machine control works offline."])
H2("6.2 Baker")
P("One shuttle carries a 100 × 160 mm FR4 board through 15 steps. <b>Zone A</b>: touch-probe height map, 500 W ER11 spindle with 0.1 mm 20° V-bits and 0.3–1.2 mm drills, vacuum extraction, and a 10 W (9.5 W optical) 445 nm diode laser at a fixed offset for cutting stencils. <b>Zone B</b>: syringe-dispensed alkali-developing solder mask, imaged by a 10.1 in 12K mono LCD over a 405 nm parallel UV source, wipe-developed with dilute sodium carbonate, dried by an air knife and flood-cured. <b>Stencil</b>: polyimide film clamped by four 12 V electromagnets on a 430 steel frame, cut from the same Gerber in the same frame. <b>Placement</b>: foot-pedal vacuum pen into a TR300 (160 °C HDT) resin jig printed in parallel. <b>Reflow</b>: 300 W silicone hotplate, SSR, MAX31855 thermocouple, Sn42Bi58 paste (138 °C). <b>Control</b>: Pi 5 + Octopus Pro in the prototype; CB1 + Manta M8P V2 (8× TMC2209) in production. <b>Safety</b>: two door interlocks, E-stop, 450 nm-blocking window, with a Class 1 enclosure as the goal.")
H2("6.3 Mixer")
P("Eight instruments over one cable: 2-channel scope, 2-channel waveform generator, 16-channel logic analyser, pattern generator, protocol decoder, two programmable supplies and a 24-bit multimeter. The prototype uses a Tang Primer 20K FPGA, 2× AD9226 (12-bit, 65 MS/s), an AN9767 dual 14-bit DAC, AD8066 buffers, a REF5025 reference and an ADS1256. Production moves to a Tang Nano 9K with an AD9288 (8-bit, 80 MS/s), 2× DAC908, FT232HL USB 2.0 HS and no screen, which is how it gets to ≈₹13,740. The same design is Baker's production test fixture in the factory.")
H2("6.4 Manufacturing")
P("China turnkey: parts, PCBA, frame, assembly, firmware flashing, Mixer-based functional test and packing. India: incoming QC, the few minimal assembly steps, final test and serial number, then shipping: India first, then global. NPI gates: DFM/RFQ → EVT-1 (5–20) → EVT-2 (10–30) → DVT (20–100) → PVT (100–500) → mass production. RFQ shortlist to qualify: PCBWay, Seeed Fusion, Peakingtech, Shenzhen MHC (primary); Kaifa (scale); Grandtop, PCBONLINE, Shenze (secondary). We keep the test system, firmware releases, ECN/AVL approval and final acceptance; contracts cover NNN, tooling ownership, no overruns and no unapproved substitutions. This only starts after Phase 1.")
S.append(PageBreak())

# ============================================================ RISKS + CALL
H1("7. Risks, stated openly", "Diligence")
T([
    ["Risk", "How we test or reduce it", "Fallback"],
    ["Mask cleanliness on 0.5 mm-pitch pads", "Wipe-develop coupons under a microscope (Phase 1)", "Skim the pads with the spindle"],
    ["Film registration within ±50 µm after clamping", "Fiducial measurement on every coupon", "Optical fiducial correction"],
    ["Jig pocket accuracy after resin shrinkage", "Measure pocket-to-pin on printed jigs", "Scale compensation"],
    ["Laser offset drift with temperature", "Check against a fiducial every job", "Automatic re-offset routine"],
    ["Double-sided boards", "Flip on the same pins; measure layer-to-layer error", "Single-sided + jumpers for v1"],
    ["Laser and chemical safety in labs", "Interlocked enclosure; E-stop; only a few mL of dilute Na₂CO₃; safety review budgeted", "Mixer + Proto only for school labs"],
    ["Slow institutional buying", "Price fits grant budgets; startups as the faster second segment", "Pilot-to-purchase programme"],
    ["LLM / cloud cost", "Model-agnostic; measure per-lab cost in pilots", "Tiered plans"],
    ["Copycat hardware", "Value sits in Proto + run data; hardware is cheap to us by design", "Keep improving the software"],
    ["China supplier / IP", "Two suppliers, NNN, tooling ownership, we own the test system", "Switch suppliers with the test fixture"],
], [0.3, 0.44, 0.26])
H2("Questions to settle on the call with Prateek")
B(["Is ₹3.49 lakh the right anchor for colleges, or should the Phase 2 pilot price be ₹2.99 lakh to speed up the first sales?",
   "Would he rather see the first pilot sites as colleges (grant budgets) or hardware startups (faster decisions, more usage)?",
   "Do the Phase 1 exit tests (prompt → tested board on 3 designs; 3 pilots; 50 boards) give him enough to lead or introduce a seed round?",
   "Any founder-salary or team line he expects inside the ₹10 lakh? (Excluded today.)"])

# ============================================================ SOURCES
S.append(PageBreak())
H1("Appendix: sources", "References")
src = [
    "Protopus Cost Report, BOM (Baker + Mixer) and Baker Workflow Story, 29 Sep 2026; Protopulse Baker China manufacturing package, 29 Sep 2026.",
    "Lovable: techcrunch.com/2025/07/23/eight-months-in-swedish-unicorn-lovable-crosses-the-100m-arr-milestone; founded.com/lovable-ai-startup-milestone-400-arr.",
    "Flux: siliconangle.com/2026/02/27/flux-nabs-37m-automate-printed-circuit-board-development-ai; flux.ai pricing page.",
    "Quilter: businesswire.com/news/home/20251007165399 (Series B, 7 Oct 2025). Diode: fenwick.com (Diode $11.4M Series A).",
    "Claude + Fusion: claude.com/connectors/autodesk-fusion. Claude + Blender: digitalproduction.com/2026/04/30/anthropic-funds-blender-ships-claude-connector.",
    "JLCPCB: jlcpcb.com PCB and PCBA pricing pages. India shipping, duty and timing: zbotic.in/how-to-order-pcb-from-jlcpcb-and-pcbway-india-cost-guide. Indian rush fabs: zbotic.in/rush-pcb-prototyping-24-48-hour-options-in-india.",
    "Voltera NOVA: store.voltera.io/products/voltera-nova. V-One: eleshop.eu/voltera-v-one-pcb-printer.html; elektor.com; aniwaa.com.",
    "Makera Carvera: PR Newswire via utusan.com.my (Jun 2026 Maker Prime Sale).",
    "Bantam Tools / Othermill: makezine.com (rebrand and acquisition); hackaday.com; toolguyd.com/bantam-tools-no-longer-sells-cnc-milling-pcb-machines.",
    "BotFactory: techcrunch.com (BotFactory raises $1.3M); technical.ly (Squink). Nano Dimension: evertiq.com/news/2026-04-08-nano-dimension-sells-ame-and-fabrica-product-lines-to-inspira.",
    "LPKF: lpkf.com product pages (quote-only); exapro.com/lpkf-protomat-s104-complete-prototyping-line-p260528195.",
    "Neoden YY1: eevblog.com forum. Analog Discovery 3: jameco.com; digikey.com (410-415). ADALM2000: shop.richardsonrfpd.com; Mouser.",
    "Moku:Go: tequipment.net/Liquid-Instruments-pricelist. Red Pitaya: redpitaya.com. Saleae: saleae.com. Rigol DHO804: electro-meters.com.",
    "India: aim.gov.in/atl.php and PIB (10,000 ATLs, 722 districts, 1.1 crore students); newsonair.gov.in (50,000 ATLs, Budget 2025-26); aim.gov.in Grant-in-Aid guideline (₹20 lakh); educationforallinindia.com (5,868 AICTE colleges); AISHE (23.2 lakh B.Tech); indore.tie.org (2.25 lakh DPIIT startups); PIB/MeitY (C2S: 305 + 95); aicte.gov.in IDEA Lab EOI (≈₹1.1 Cr).",
    "Global: fabfoundation.org (2,300+ Fab Labs); Fortune Business Insights via gii.tw (oscilloscopes); electronicsforu.com (smart desktop CNC mills); MeitY via PIB (₹11.3 lakh crore electronics production FY25).",
]
for x in src: S.append(Paragraph(x, bul, bulletText="•"))


def cover(c, d):
    c.saveState(); c.setFillColor(DARK); c.rect(0, 0, A4[0], A4[1], fill=1, stroke=0); c.restoreState()

def page(c, d):
    c.saveState()
    c.setFont("DV", 7.5); c.setFillColor(MUTED)
    c.drawString(18 * mm, 10 * mm, "Protopulse · Murder board round 1 · 30 Sep 2026")
    c.drawRightString(A4[0] - 18 * mm, 10 * mm, str(d.page))
    c.restoreState()

doc = BaseDocTemplate(OUT, pagesize=A4, leftMargin=18 * mm, rightMargin=18 * mm, topMargin=16 * mm, bottomMargin=18 * mm,
                      title="Protopulse: murder board round 1", author="Protopulse")
fr = Frame(doc.leftMargin, doc.bottomMargin, doc.width, doc.height, id="f")
doc.addPageTemplates([PageTemplate(id="cover", frames=[fr], onPage=cover), PageTemplate(id="body", frames=[fr], onPage=page)])
doc.build(S)
print("ok", OUT)

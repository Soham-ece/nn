from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.comments import Comment
from openpyxl.utils import get_column_letter

OUT = "/home/user/nn/protopulse_murder_board/Protopulse_Economics_Model.xlsx"
INR = '[>=10000000]"₹"##\\,##\\,##\\,##0;[>=100000]"₹"##\\,##\\,##0;"₹"#,##0'
USD = '"$"#,##0.00'
PCT = '0.0%'
NUM = '#,##0'
NUM1 = '#,##0.0'

F = "Arial"
BLUE = Font(name=F, color="0000FF")
BLACK = Font(name=F, color="000000")
GREEN = Font(name=F, color="008000")
BOLD = Font(name=F, bold=True)
H1 = Font(name=F, bold=True, size=14, color="1B3A2F")
HDR = Font(name=F, bold=True, color="FFFFFF")
HDRFILL = PatternFill("solid", fgColor="1B3A2F")
KEY = PatternFill("solid", fgColor="FFFF00")
NOTE = Font(name=F, italic=True, size=9, color="555555")
thin = Side(style="thin", color="C8C8C8")
BOX = Border(top=thin, bottom=thin, left=thin, right=thin)

wb = Workbook()


def sheet(title, widths):
    ws = wb.create_sheet(title)
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.sheet_view.showGridLines = False
    return ws


def header(ws, row, labels):
    for i, l in enumerate(labels, 1):
        c = ws.cell(row=row, column=i, value=l)
        c.font = HDR
        c.fill = HDRFILL
        c.alignment = Alignment(wrap_text=True, vertical="center")
        c.border = BOX


def put(ws, ref, value, font=BLACK, fmt=None, fill=None, bold=False):
    c = ws[ref]
    c.value = value
    c.font = Font(name=F, color=font.color, bold=bold or font.bold, italic=font.italic, size=font.size)
    if fmt:
        c.number_format = fmt
    if fill:
        c.fill = fill
    c.border = BOX
    return c


# ---------------------------------------------------------------- Read Me
ws = wb.active
ws.title = "Read Me"
ws.column_dimensions["A"].width = 110
ws.sheet_view.showGridLines = False
lines = [
    ("Protopulse — economics model behind the murder-board answers (30 Sep 2026)", H1),
    ("", BLACK),
    ("How to use", BOLD),
    ("• Blue numbers are inputs. Change them and every black formula recalculates. Yellow cells are the key levers.", BLACK),
    ("• Green numbers pull from the Assumptions sheet.", BLACK),
    ("• 'Payback' answers Prateek's question: if Baker costs ₹X lakh, how many boards before it pays for itself? Edit Assumptions!C6.", BLACK),
    ("• USD converted at ₹88, the rate used in the 29 Sep cost report, so every figure here matches that report.", BLACK),
    ("", BLACK),
    ("Where the numbers come from", BOLD),
    ("• Build costs: Protopus Cost Report (29 Sep 2026). Baker prototype ₹3,73,418; Mixer prototype ₹74,847; Baker production ₹1,44,842; Mixer production ₹13,740.", BLACK),
    ("• Consumable prices: prototype BOM listings (FR4 ₹99, LPSM ₹1,100/kg, Sn42Bi58 ₹1,500/500 g, TR300 ₹7,500/kg, V-bits $23.99/10). Usage per board is our engineering estimate.", BLACK),
    ("• JLCPCB prices: jlcpcb.com ($2 for 5 PCBs; PCBA $8 setup, $1.50 stencil, $0.0017/joint). Shipping and duty to India: zbotic.in guide (DHL $25–45, 10% BCD + 18% IGST, 7–20 days door to door).", BLACK),
    ("• Indian rush fab: zbotic.in (₹3,000–8,000 for 5 two-layer boards in 24 h).", BLACK),
    ("• Competitor prices: see the Competitors sheet, one source per row.", BLACK),
    ("• Selling prices, subscription prices and usage rates are Protopulse proposals. Pilots have not validated them yet.", BLACK),
    ("", BLACK),
    ("What this model does not claim", BOLD),
    ("• Cycle times are engineering targets for the first prototype. Phase 1 exists to measure them.", BLACK),
    ("• Baker is for prototypes, 1–10 boards per design. Beyond that, a fab is cheaper, and the model says so (Throughput & Scale).", BLACK),
    ("• Duty, freight and China turnkey prices still need a customs broker and supplier quotes.", BLACK),
]
for i, (t, f) in enumerate(lines, 1):
    c = ws.cell(row=i, column=1, value=t)
    c.font = f
    c.alignment = Alignment(wrap_text=True)

# ---------------------------------------------------------------- Assumptions
A = sheet("Assumptions", [46, 16, 16, 60])
put(A, "A1", "Assumptions (inputs in blue)", H1)
A["A1"].border = Border()
header(A, 3, ["Item", "Unit", "Value", "Source / note"])
rows = [
    # row, label, unit, value, fmt, note, key
    (4, "USD → INR", "₹/$", 88, NUM, "Rate used in the 29 Sep 2026 cost report", False),
    (5, "Baker production cost (China parts, Delhi build, 100-unit batch)", "₹", 144842, INR, "Cost Report 29 Sep 2026, p.3", False),
    (6, "Baker selling price (ex-GST)", "₹", 349000, INR, "PROPOSED. Edit this cell to test ₹X lakh", True),
    (7, "Mixer production cost", "₹", 13740, INR, "Cost Report 29 Sep 2026, p.4", False),
    (8, "Mixer selling price (ex-GST)", "₹", 24999, INR, "PROPOSED", True),
    (9, "Baker prototype build cost", "₹", 373418, INR, "Cost Report 29 Sep 2026, p.1 (incl. 35% duty/courier on imports + 15% contingency)", False),
    (10, "Mixer prototype build cost", "₹", 74847, INR, "Cost Report 29 Sep 2026, p.2", False),
    (11, "Proto Lab subscription", "₹/month", 4999, INR, "PROPOSED; first year included with Baker", False),
    (12, "Consumable kit price per board", "₹", 699, INR, "PROPOSED (FR4, mask, paste, film, jig resin)", False),
    (13, "Board iterations per week, startup customer", "#/wk", 2, NUM, "ASSUMPTION for payback illustration", True),
    (14, "Board iterations per week, college lab", "#/wk", 1, NUM, "ASSUMPTION for payback illustration", True),
    (15, "Working weeks per year", "#", 48, NUM, "ASSUMPTION", False),
    (16, "Baker boards per year per installed machine (for recurring revenue)", "#", 150, NUM, "ASSUMPTION: ~3 boards/week", False),
    (17, "Indian rush fab, 5 bare 2-layer boards (low)", "₹", 3000, INR, "zbotic.in rush-prototyping guide (₹3,000–8,000)", False),
    (18, "Indian rush fab, 5 bare 2-layer boards (high)", "₹", 8000, INR, "zbotic.in rush-prototyping guide", False),
]
for r, lab, unit, val, fmt, note, key in rows:
    put(A, f"A{r}", lab)
    put(A, f"B{r}", unit)
    put(A, f"C{r}", val, BLUE, fmt, KEY if key else None)
    put(A, f"D{r}", note, NOTE)

# ---------------------------------------------------------------- Unit economics
U = sheet("Unit Economics", [44, 18, 18, 18, 40])
put(U, "A1", "Unit economics per machine", H1); U["A1"].border = Border()
header(U, 3, ["Line", "Baker", "Mixer", "Bundle", "Note"])
put(U, "A4", "Selling price (ex-GST)")
put(U, "B4", "=Assumptions!C6", GREEN, INR); put(U, "C4", "=Assumptions!C8", GREEN, INR); put(U, "D4", "=B4+C4", BLACK, INR)
put(U, "A5", "Production cost (landed, built in Delhi)")
put(U, "B5", "=Assumptions!C5", GREEN, INR); put(U, "C5", "=Assumptions!C7", GREEN, INR); put(U, "D5", "=B5+C5", BLACK, INR)
put(U, "A6", "Gross profit per unit")
for col in "BCD":
    put(U, f"{col}6", f"={col}4-{col}5", BLACK, INR)
put(U, "A7", "Gross margin")
for col in "BCD":
    put(U, f"{col}7", f"=IF({col}4=0,0,{col}6/{col}4)", BLACK, PCT)
put(U, "A8", "Price ÷ cost")
for col in "BCD":
    put(U, f"{col}8", f"=IF({col}5=0,0,{col}4/{col}5)", BLACK, '0.00"x"')
put(U, "E5", "China turnkey quotes pending (RFQ at 5–5,000 units)", NOTE)

put(U, "A11", "Baker price sensitivity", BOLD); U["A11"].border = Border()
header(U, 12, ["Baker price (ex-GST)", "Gross margin", "Bundle price", "Break-even iterations vs JLCPCB", "Note"])
for i, p in enumerate([299000, 349000, 399000, 449000]):
    r = 13 + i
    put(U, f"A{r}", p, BLUE, INR)
    put(U, f"B{r}", f"=(A{r}-Assumptions!$C$5)/A{r}", BLACK, PCT)
    put(U, f"C{r}", f"=A{r}+Assumptions!$C$8", BLACK, INR)
    put(U, f"D{r}", f"=ROUNDUP(C{r}/'Board Cost'!$C$27,0)", BLACK, NUM)
put(U, "E14", "Proposed price", NOTE)

put(U, "A19", "Recurring revenue per installed Baker (after year 1)", BOLD); U["A19"].border = Border()
header(U, 20, ["Line", "Revenue ₹/yr", "Cost ₹/yr", "Gross profit ₹/yr", "Note"])
put(U, "A21", "Proto Lab subscription")
put(U, "B21", "=Assumptions!C11*12", BLACK, INR); put(U, "C21", 0, BLUE, INR); put(U, "D21", "=B21-C21", BLACK, INR)
put(U, "E21", "Cloud/LLM cost per lab not yet measured; set C21 once known", NOTE)
put(U, "A22", "Consumable kits")
put(U, "B22", "=Assumptions!C12*Assumptions!C16", BLACK, INR)
put(U, "C22", "='Board Cost'!C16*Assumptions!C16", BLACK, INR)
put(U, "D22", "=B22-C22", BLACK, INR)
put(U, "A23", "Total", BOLD)
put(U, "B23", "=B21+B22", BLACK, INR, bold=True); put(U, "C23", "=C21+C22", BLACK, INR, bold=True); put(U, "D23", "=D21+D22", BLACK, INR, bold=True)

# ---------------------------------------------------------------- Board cost
B = sheet("Board Cost", [52, 16, 16, 52])
put(B, "A1", "What one prototype board costs: Baker vs ordering it", H1); B["A1"].border = Border()
put(B, "A3", "A. Baker consumables per 100 × 160 mm board (components excluded)", BOLD); B["A3"].border = Border()
header(B, 4, ["Item", "Pack price ₹", "Per board ₹", "Basis"])
cons = [
    ("FR4 copper-clad 100×150 mm", 99, "=B5", "Listing ₹99 each (1 per board)"),
    ("Alkali-developing LPSM solder mask", 1100, "=B6/1000*3", "₹1,100/kg; ~3 g per board incl. waste (est.)"),
    ("Sodium carbonate developer", 200, 1, "Few mL of dilute solution (est.)"),
    ("Sn42Bi58 low-temp paste", 1500, "=B8/500*1.5", "₹1,500/500 g; ~1.5 g per board (est.)"),
    ("Polyimide stencil film", 3150, 25, "Roll ₹3,150; ~₹25 of film per board (est.)"),
    ("TR300 high-temp resin (placement jig)", 7500, "=B10/1000*15", "₹7,500/kg; ~15 g jig (est.)"),
    ("IPA for jig wash", 200, "=B11/1000*20", "₹200/L; ~20 mL (est.)"),
    ("V-bit wear", "=23.99*Assumptions!C4/10", "=B12/5", "$23.99 per 10 bits; ~5 boards per bit (est.)"),
    ("Drill wear", 1500, "=B13/50", "₹1,500 set; ~50 boards per set (est.)"),
    ("Electricity", 8, "=B14*1.5", "₹8/kWh; ~1.5 kWh per board (est.)"),
]
for i, (lab, pack, per, note) in enumerate(cons):
    r = 5 + i
    put(B, f"A{r}", lab)
    put(B, f"B{r}", pack, BLUE if not str(pack).startswith("=") else BLACK, INR)
    put(B, f"C{r}", per, BLUE if not str(per).startswith("=") else BLACK, '"₹"#,##0.0')
    put(B, f"D{r}", note, NOTE)
put(B, "A16", "Baker consumables per board", BOLD)
put(B, "C16", "=SUM(C5:C14)", BLACK, '"₹"#,##0', KEY, bold=True)

put(B, "A18", "B. Same board ordered from JLCPCB to India (assembled, components excluded)", BOLD); B["A18"].border = Border()
header(B, 19, ["Item", "USD", "₹", "Basis"])
jl = [
    ("PCB, 5 pcs, 100×160 mm (over the $2 ≤100×100 tier)", 5, "Estimate; $2 applies only up to 100×100 mm"),
    ("PCBA setup fee", 8, "jlcpcb.com PCBA pricing"),
    ("Stencil", 1.5, "jlcpcb.com PCBA pricing"),
    ("SMT joints (200 × $0.0017)", "=200*0.0017", "jlcpcb.com PCBA pricing"),
    ("Extended-part loading fees (3 × $3)", 9, "ASSUMPTION: 3 non-basic parts"),
    ("DHL/UPS express to India", 35, "Midpoint of $25–45 (zbotic.in)"),
]
for i, (lab, usd, note) in enumerate(jl):
    r = 20 + i
    put(B, f"A{r}", lab)
    put(B, f"B{r}", usd, BLUE if not str(usd).startswith("=") else BLACK, USD)
    put(B, f"C{r}", f"=B{r}*Assumptions!$C$4", BLACK, INR)
    put(B, f"D{r}", note, NOTE)
put(B, "A26", "Customs: 10% BCD + 18% IGST on (value + BCD)")
put(B, "C26", "=SUM(C20:C25)*((1+0.1)*(1+0.18)-1)", BLACK, INR)
put(B, "D26", "Effective 29.8%. IGST can be claimed back if GST-registered; BCD cannot.", NOTE)
put(B, "A27", "Saving per iteration with Baker (JLCPCB total − Baker consumables)", BOLD)
put(B, "C27", "=SUM(C20:C26)-C16", BLACK, INR, KEY, bold=True)
put(B, "A28", "JLCPCB assembled iteration, landed in India", BOLD)
put(B, "C28", "=SUM(C20:C26)", BLACK, INR, bold=True)
put(B, "D28", "Door-to-door 7–20 days (fab + DHL + customs)", NOTE)

put(B, "A30", "C. Indian 24-hour fab (bare boards only; assembly extra)", BOLD); B["A30"].border = Border()
put(B, "A31", "Midpoint of ₹3,000–8,000 for 5 boards")
put(B, "C31", "=(Assumptions!C17+Assumptions!C18)/2", GREEN, INR)
put(B, "A32", "Saving per iteration vs Baker (bare board only; conservative)")
put(B, "C32", "=C31-C16", BLACK, INR)

# ---------------------------------------------------------------- Payback
P = sheet("Payback", [56, 20, 20, 44])
put(P, "A1", "Does Baker pay for itself? (Prateek: 'Say X lacs...')", H1); P["A1"].border = Border()
header(P, 3, ["Line", "vs JLCPCB to India", "vs Indian 24-h fab", "Note"])
put(P, "A4", "Customer spend: Baker + Mixer (ex-GST)")
put(P, "B4", "='Unit Economics'!D4", GREEN, INR); put(P, "C4", "='Unit Economics'!D4", GREEN, INR)
put(P, "A5", "Direct saving per board iteration")
put(P, "B5", "='Board Cost'!C27", GREEN, INR); put(P, "C5", "='Board Cost'!C32", GREEN, INR)
put(P, "D5", "Engineer time and waiting days not counted", NOTE)
put(P, "A6", "Break-even iterations", BOLD)
put(P, "B6", "=IF(B5<=0,0,ROUNDUP(B4/B5,0))", BLACK, NUM, KEY, bold=True)
put(P, "C6", "=IF(C5<=0,0,ROUNDUP(C4/C5,0))", BLACK, NUM, KEY, bold=True)
put(P, "A7", "Months to break even, startup (Assumptions!C13 per week)")
put(P, "B7", "=B6/(Assumptions!$C$13*Assumptions!$C$15/12)", BLACK, NUM1)
put(P, "C7", "=C6/(Assumptions!$C$13*Assumptions!$C$15/12)", BLACK, NUM1)
put(P, "A8", "Months to break even, college lab (Assumptions!C14 per week)")
put(P, "B8", "=B6/(Assumptions!$C$14*Assumptions!$C$15/12)", BLACK, NUM1)
put(P, "C8", "=C6/(Assumptions!$C$14*Assumptions!$C$15/12)", BLACK, NUM1)
put(P, "A10", "Calendar time per iteration", BOLD); P["A10"].border = Border()
header(P, 11, ["Route", "Door-to-door", "Hands-on", "Source"])
tt = [
    ("JLCPCB → India (DHL)", "7–20 days", "Order + customs paperwork", "zbotic.in"),
    ("Indian rush fab (bare boards)", "24–48 h + courier", "Stencil + hand assembly extra", "zbotic.in"),
    ("Baker (target, to be measured in Phase 1)", "≈1.5–2.5 h", "≈15–25 min", "Throughput sheet"),
]
for i, row in enumerate(tt):
    for j, v in enumerate(row):
        put(P, f"{'ABCD'[j]}{12+i}", v, NOTE if j == 3 else BLACK)

# ---------------------------------------------------------------- Throughput & scale
T = sheet("Throughput & Scale", [44, 14, 14, 16, 46])
put(T, "A1", "Cycle time per board (engineering targets, not yet measured)", H1); T["A1"].border = Border()
header(T, 3, ["Step", "Low min", "High min", "Hands-on?", "Note"])
steps = [
    ("01 Load + 02 probe height map", 5, 5, "Yes (load)", "Magazine feed; operator refills"),
    ("03 Isolation mill", 25, 45, "No", "Depends on copper area and trace count"),
    ("03 Drill", 5, 10, "No", "~50 holes"),
    ("04 Vacuum clean", 2, 2, "No", ""),
    ("06 Coat mask", 3, 5, "No", "Syringe dispense"),
    ("07 UV image (10.1 in LCD, 405 nm)", 2, 4, "No", ""),
    ("08 Wipe-develop + air knife", 4, 6, "No", ""),
    ("09 Flood cure", 5, 10, "No", ""),
    ("10 Laser-cut stencil", 5, 10, "No", ""),
    ("11–12 Clamp, paste, release", 3, 3, "No", ""),
    ("Placement jig print (parallel with 01–12)", 0, 0, "No", "30–45 min incl. wash/cure; hidden behind steps 01–12"),
    ("13 Manual placement (~40 parts, 10–20 s each)", 7, 14, "Yes", "Vacuum pen into printed jig"),
    ("14 Reflow + cool", 10, 12, "No", "Sn42Bi58, 138 °C melt"),
    ("15 Test on Mixer", 5, 15, "Yes (hook-up)", "Proto runs the test plan"),
]
for i, (s, lo, hi, h, n) in enumerate(steps):
    r = 4 + i
    put(T, f"A{r}", s); put(T, f"B{r}", lo, BLUE, NUM); put(T, f"C{r}", hi, BLUE, NUM)
    put(T, f"D{r}", h); put(T, f"E{r}", n, NOTE)
last = 3 + len(steps)
put(T, f"A{last+1}", "Total per board (minutes)", BOLD)
put(T, f"B{last+1}", f"=SUM(B4:B{last})", BLACK, NUM, bold=True)
put(T, f"C{last+1}", f"=SUM(C4:C{last})", BLACK, NUM, bold=True)
tot = last + 1
put(T, f"A{tot+1}", "Total per board (hours)")
put(T, f"B{tot+1}", f"=B{tot}/60", BLACK, '0.0'); put(T, f"C{tot+1}", f"=C{tot}/60", BLACK, '0.0')
put(T, f"A{tot+3}", "Shift length (h)"); put(T, f"B{tot+3}", 8, BLUE, NUM)
put(T, f"A{tot+4}", "Working days per year"); put(T, f"B{tot+4}", 250, BLUE, NUM)
put(T, f"A{tot+5}", "Boards per shift (at slow and fast cycle)")
put(T, f"B{tot+5}", f"=ROUNDDOWN(B{tot+3}*60/C{tot},0)", BLACK, NUM)
put(T, f"C{tot+5}", f"=ROUNDDOWN(B{tot+3}*60/B{tot},0)", BLACK, NUM)
put(T, f"A{tot+6}", "Boards per year, one machine, one shift", BOLD)
put(T, f"B{tot+6}", f"=B{tot+5}*B{tot+4}", BLACK, NUM, KEY, bold=True)
put(T, f"C{tot+6}", f"=C{tot+5}*B{tot+4}", BLACK, NUM, KEY, bold=True)
yr = tot + 6

s0 = yr + 3
put(T, f"A{s0}", "Prateek: '1,000 boards? 10,000? 1 lakh?'", BOLD); T[f"A{s0}"].border = Border()
header(T, s0 + 1, ["Boards per year", "Bakers needed (1 shift, slow cycle)", "Right tool", "", "Why"])
for i, (q, tool, why) in enumerate([
    (10, "Baker", "Same-day iteration; fab minimums and shipping dominate"),
    (100, "Baker", "One machine covers a busy lab or startup"),
    (1000, "Baker for iterations; fab for identical batches", "1–2 machines; any batch of >10 identical boards goes to a fab"),
    (10000, "Fab / EMS", "Production. Proto exports the validated Gerber/BOM/CPL"),
    (100000, "Fab / EMS", "Production. Baker is not built for this and we do not claim it"),
]):
    r = s0 + 2 + i
    put(T, f"A{r}", q, BLUE, NUM)
    put(T, f"B{r}", f"=ROUNDUP(A{r}/$B${yr},0)", BLACK, NUM)
    put(T, f"C{r}", tool)
    put(T, f"E{r}", why, NOTE)

# ---------------------------------------------------------------- Use of funds
UF = sheet("Use of Funds", [60, 18, 12, 50])
put(UF, "A1", "₹10 lakh, Phase 1: Proto + Baker, with Mixer as Baker's test head", H1); UF["A1"].border = Border()
header(UF, 3, ["Line", "₹", "Share", "Basis"])
uf = [
    ("Baker prototype (full BOM, duty, 15% contingency)", 373418, "Cost Report 29 Sep 2026"),
    ("Mixer prototype, built as Baker's test head", 74847, "Cost Report 29 Sep 2026"),
    ("Process validation: consumables + rev-B parts for the 4 open points", 120000, "Plan"),
    ("Proto software: LLM API, cloud, dev tooling (12 months)", 100000, "Plan"),
    ("Pilot programme: 3 sites (install, travel, shipping)", 75000, "Plan"),
    ("Safety review (Class 4 laser, electrical) + provisional patent", 90000, "Plan"),
    ("Workshop tools and bench equipment", 80000, "Plan"),
    ("Reserve", 86735, "Plan"),
]
for i, (lab, v, n) in enumerate(uf):
    r = 4 + i
    put(UF, f"A{r}", lab); put(UF, f"B{r}", v, BLUE, INR)
    put(UF, f"C{r}", f"=B{r}/$B${4+len(uf)}", BLACK, PCT); put(UF, f"D{r}", n, NOTE)
tr = 4 + len(uf)
put(UF, f"A{tr}", "Total", BOLD); put(UF, f"B{tr}", f"=SUM(B4:B{tr-1})", BLACK, INR, bold=True)
put(UF, f"C{tr}", f"=SUM(C4:C{tr-1})", BLACK, PCT, bold=True)
put(UF, f"A{tr+1}", "Founder salaries are not included. Confirm before sharing.", NOTE); UF[f"A{tr+1}"].border = Border()

# ---------------------------------------------------------------- Competitors
C = sheet("Competitors", [30, 24, 16, 16, 16, 44, 46])
put(C, "A1", "Competitor pricing (list prices, before Indian duty and GST)", H1); C["A1"].border = Border()
header(C, 3, ["Product", "Category", "Low (USD)", "High (USD)", "Low (₹ at ₹88)", "What it does not do", "Source"])
comp = [
    ("LPKF ProtoMat S104 line", "In-house PCB (pro)", 96000, 96000, "Quote-only. $96k was a full S104 line bought new in 2019; separate machines for mask, plating, assembly", "exapro.com used listing"),
    ("Voltera NOVA", "Printed electronics", 45974, 45974, "Ink on flexible substrates; not copper FR4 + test", "store.voltera.io"),
    ("Makera Carvera", "Desktop CNC", 5799, 5799, "Mills only; no mask, stencil, assembly or test", "Makera MSRP (press, Jun 2026)"),
    ("Makera Carvera Air", "Desktop CNC", 2699, 2699, "Mills only", "Makera regular price"),
    ("BotFactory Squink", "Printed PCB + P&P", 3199, 4499, "Conductive ink; SV2 price on request", "techcrunch / BotFactory"),
    ("Bantam Tools PCB mill", "Desktop PCB mill", None, None, "Product line discontinued; company now sells art machines", "toolguyd.com"),
    ("Neoden YY1", "Pick-and-place only", 3000, 3000, "Places parts only; no board, no test", "EEVblog ('under $3K')"),
    ("Digilent Analog Discovery 3", "USB instrument", 375, 379, "Human reads the screen; not tied to design files", "Jameco / DigiKey"),
    ("ADALM2000", "USB instrument", 237, 262, "Same", "Mouser / Richardson RFPD"),
    ("Moku:Go M0–M2", "USB instrument", 599, 799, "Same", "Liquid Instruments / TEquipment"),
    ("Red Pitaya STEMlab 125-14", "FPGA instrument", 490, 716, "Same", "redpitaya.com"),
    ("Saleae Logic 8 / Pro 16", "Logic analyser", 499, 1499, "Logic only", "saleae.com"),
    ("Rigol DHO804", "Bench scope", 492, 579, "Scope only", "electro-meters.com"),
    ("Flux", "AI PCB design (SaaS)", 15, 49, "Per editor per month. Output stops at files", "flux.ai pricing"),
]
for i, (p, cat, lo, hi, gap, src) in enumerate(comp):
    r = 4 + i
    put(C, f"A{r}", p); put(C, f"B{r}", cat)
    put(C, f"C{r}", lo if lo is not None else "n/a", BLUE, '"$"#,##0')
    put(C, f"D{r}", hi if hi is not None else "n/a", BLUE, '"$"#,##0')
    put(C, f"E{r}", f"=IF(ISNUMBER(C{r}),C{r}*Assumptions!$C$4,\"n/a\")", BLACK, INR)
    put(C, f"F{r}", gap, NOTE); put(C, f"G{r}", src, NOTE)
r = 5 + len(comp)
put(C, f"A{r}", "Protopulse Baker + Mixer (proposed)", BOLD)
put(C, f"B{r}", "Prototyping cell + AI")
put(C, f"E{r}", "='Unit Economics'!D4", GREEN, INR, KEY, bold=True)
put(C, f"F{r}", "Board, mask, stencil, paste, reflow, test, driven by Proto", NOTE)

# ---------------------------------------------------------------- Market
M = sheet("Market", [58, 18, 18, 48])
put(M, "A1", "India beachhead, bottom-up (upper bound, one Baker + Mixer per buyer)", H1); M["A1"].border = Border()
header(M, 3, ["Segment", "Buyers", "Hardware ₹", "Source / assumption"])
put(M, "A4", "AICTE-approved engineering colleges"); put(M, "B4", 5868, BLUE, NUM)
put(M, "C4", "=B4*'Unit Economics'!$D$4", BLACK, INR); put(M, "D4", "educationforallinindia.com (AICTE count)", NOTE)
put(M, "A5", "Hardware-relevant startups (1% of 2.25 lakh DPIIT startups)"); put(M, "B5", "=ROUND(225000*B8,0)", BLACK, NUM)
put(M, "C5", "=B5*'Unit Economics'!$D$4", BLACK, INR); put(M, "D5", "2.25 lakh: TiE / DPIIT early 2026. 1% share is an ASSUMPTION", NOTE)
put(M, "A6", "Total one-time hardware pool", BOLD)
put(M, "B6", "=B4+B5", BLACK, NUM, bold=True); put(M, "C6", "=C4+C5", BLACK, INR, KEY, bold=True)
put(M, "A8", "Hardware-relevant share of DPIIT startups"); put(M, "B8", 0.01, BLUE, PCT, KEY)
put(M, "A9", "Recurring Proto pool per year (all buyers above)")
put(M, "C9", "=B6*Assumptions!C11*12", BLACK, INR)
put(M, "A11", "Context numbers (not in the sum)", BOLD); M["A11"].border = Border()
ctx = [
    ("Atal Tinkering Labs set up (schools)", 10000, "AIM/PIB 2025: 722 districts, 1.1 crore students"),
    ("New ATLs announced for the next 5 years", 50000, "Union Budget 2025-26"),
    ("ATL grant per school (₹)", 2000000, "AIM: ₹10 lakh setup + ₹10 lakh O&M over 5 years"),
    ("B.Tech students enrolled", 2320000, "AISHE, 23.2 lakh"),
    ("C2S academic institutions + DLI startups", 400, "MeitY/PIB: 305 + 95"),
    ("Fab Labs worldwide", 2300, "Fab Foundation: 2,300+ (other counts 2,700+)"),
]
for i, (lab, v, n) in enumerate(ctx):
    rr = 12 + i
    put(M, f"A{rr}", lab); put(M, f"B{rr}", v, BLUE, INR if "₹" in lab else NUM); put(M, f"D{rr}", n, NOTE)

wb.save(OUT)
print("saved", OUT)

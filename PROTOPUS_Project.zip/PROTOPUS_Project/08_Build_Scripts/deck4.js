// PROTOPUS pitch deck: the founder's "Updated2" deck rebuilt as an editable PPTX in its own
// design language, with the murder-board revisions and the technical chapters merged in.
const pptxgen = require("pptxgenjs");
const OUT = "/home/user/nn/protopulse_murder_board/PROTOPUS_Pitch_Deck_v3.pptx";
const A = "/home/user/lo/src/";

// ---- design tokens, sampled from the deck
const BG = "0E1216", PANEL = "121A21", RULE = "1F2A32", TEXT = "E8EEF2", BODY = "A3B3BE", MUTED = "6E7A83", DIM = "424A51";
const COPPER = "CF8F4E", BLUE = "54ACF0", YELLOW = "F2C230", GREEN = "60A05A", ONYEL = "1A1405", HICOL = "1A1D12", STEEL = "8FB3C9";
const CREAM = "F0E3D2", BROWN = "8A5F31", CBLUE = "1B64A8", CBLACK = "131210", MUSTARD = "C08A12", TAUPE = "9C8F7C";
const HEAD = "Space Grotesk", MONO = "Space Mono";

const pres = new pptxgen();
pres.layout = "LAYOUT_16x9";
pres.author = "PROTOPUS";
pres.title = "PROTOPUS pitch deck";

// ---- helpers
const T = (s, text, o) => s.addText(text, Object.assign({ fontFace: MONO, color: BODY, isTextBox: true, margin: 0, valign: "top" }, o));
const H = (s, text, o) => T(s, text, Object.assign({ fontFace: HEAD, bold: true, color: TEXT }, o));
const line = (s, x, y, w, h, color = RULE, width = 0.75, dash, arrow) => s.addShape(pres.shapes.LINE, { x, y, w, h, line: Object.assign({ color, width, dashType: dash }, arrow ? { endArrowType: "triangle" } : {}) });
const rect = (s, x, y, w, h, fill, lc, lw = 0.75) => s.addShape(pres.shapes.RECTANGLE, { x, y, w, h, fill: { color: fill }, line: lc ? { color: lc, width: lw } : { color: fill, width: 0 } });
const bar = (s, x, y, w, color, h = 0.04) => rect(s, x, y, w, h, color);
const dot = (s, x, y, filled, color = YELLOW, ring = DIM, d = 0.11) => s.addShape(pres.shapes.OVAL, { x, y, w: d, h: d, fill: { color: filled ? color : BG }, line: { color: filled ? color : ring, width: 0.75 } });
const kick = (s, text, color = COPPER, y = 0.47) => T(s, text.toUpperCase(), { x: 0.45, y, w: 9.1, h: 0.2, fontSize: 8.5, color, charSpacing: 2.5 });
const pill = (s, text, x, y, w, fill = YELLOW, color = ONYEL, fs = 7.5) => { rect(s, x, y, w, 0.24, fill); T(s, text, { x, y, w, h: 0.24, fontSize: fs, bold: true, color, align: "center", valign: "middle", charSpacing: 1 }); };
const src = (s, t, y = 5.18) => T(s, t, { x: 0.45, y, w: 9.1, h: 0.22, fontSize: 6.5, color: MUTED });
let n = 0;
const num = () => String(++n).padStart(2, "0");
function slide(kicker, title, o = {}) {
  const s = pres.addSlide();
  s.background = { color: BG };
  if (kicker) kick(s, num() + " · " + kicker, o.kc || COPPER);
  if (title) H(s, title, { x: 0.45, y: 0.72, w: o.tw || 8.8, h: o.th || 0.85, fontSize: o.ts || 23 });
  return s;
}
function tbl(s, rows, o, hi = []) {
  const out = rows.map((r, i) => r.map((c, j) => {
    const cell = typeof c === "string" ? { text: c, options: {} } : c;
    const base = { fontFace: MONO, color: BODY, valign: "middle", border: [{ type: "none" }, { type: "none" }, { pt: 0.75, color: RULE }, { type: "none" }] };
    if (j === 0 && i > 0) Object.assign(base, { color: TEXT });
    if (i === 0) Object.assign(base, { color: MUTED, charSpacing: 1, border: [{ type: "none" }, { type: "none" }, { pt: 0.9, color: TEXT }, { type: "none" }] });
    if (hi.includes(i)) Object.assign(base, { fill: { color: PANEL }, color: TEXT, bold: true });
    return { text: cell.text, options: Object.assign(base, cell.options) };
  }));
  s.addTable(out, Object.assign({ fontSize: 8, margin: [1.5, 4, 1.5, 4] }, o));
}
const tt = (t, o) => ({ text: t, options: o || {} });

// =================================================================== COVER
{
  const s = pres.addSlide(); s.background = { color: BG };
  s.addImage({ path: A + "logo.png", x: 0.45, y: 0.52, w: 2.15, h: 0.374 });
  T(s, [
    { text: "Focus on", options: { breakLine: true } },
    { text: "innovation", options: { underline: { style: "wavy", color: BLUE } } }, { text: "." },
  ], { x: 0.45, y: 1.72, w: 9.2, h: 1.45, fontFace: MONO, bold: true, fontSize: 42, color: TEXT, lineSpacingMultiple: 0.95 });
  T(s, "We take care of the rest.", { x: 0.45, y: 3.08, w: 9.4, h: 0.7, fontFace: MONO, bold: true, fontSize: 42, color: "9FB0BC" });
  T(s, [
    { text: "proto", options: { color: YELLOW } }, { text: ", our AI engineer, plans every step." , options: { breakLine: true } },
    { text: "baker", options: { color: COPPER } }, { text: " makes the board. " },
    { text: "mixer", options: { color: BLUE } }, { text: " tests it." },
  ], { x: 0.45, y: 4.1, w: 9, h: 0.5, fontSize: 11.5, color: BODY, lineSpacingMultiple: 1.2 });
  T(s, "protopus-kappa.vercel.app", { x: 0.45, y: 4.85, w: 5, h: 0.2, fontSize: 8.5, color: MUTED });
  s.addNotes("Proto now leads the line: the AI engineer is the company; Baker and Mixer are the machines it works through (Prateek, round 1).");
}

// =================================================================== 01 EXEC SUMMARY
{
  const s = slide("Executive summary", "A prototyping lab and a full test bench,\non one desk, run by an AI engineer");
  line(s, 0.45, 1.93, 9.1, 0);
  const cols = [
    ["MORNING", "You describe it", "Proto reads the design, checks it and points at what will bite later.", COPPER, TEXT],
    ["MIDDAY", "Baker builds it", "Milled, masked, stencilled and pasted. You drop parts into a printed jig; Baker reflows.", COPPER, COPPER],
    ["AFTERNOON", "Mixer tests it", "One cable, eight instruments, and a verdict Proto writes in plain words.", BLUE, BLUE],
    ["EVENING", "You try again", "The next attempt starts the same evening, not two weeks from now.", BLUE, TEXT],
  ];
  cols.forEach((c, i) => {
    const x = 0.45 + i * 2.28;
    if (i) line(s, x - 0.12, 1.93, 0, 1.95);
    T(s, c[0], { x, y: 2.15, w: 2.1, h: 0.2, fontSize: 8.5, color: c[3], charSpacing: 2 });
    H(s, c[1], { x, y: 2.45, w: 2.15, h: 0.32, fontSize: 13.5, color: c[4] });
    T(s, c[2], { x, y: 2.88, w: 2.1, h: 1.0, fontSize: 9.5 });
  });
  line(s, 0.45, 4.3, 9.1, 0);
  T(s, "WHAT MAKES\nIT OURS", { x: 0.45, y: 4.5, w: 1.6, h: 0.42, fontSize: 8.5, color: YELLOW, charSpacing: 2 });
  H(s, "Making and testing on one desk, with Proto guiding every step instead of a hundred buttons.", { x: 2.1, y: 4.45, w: 7.45, h: 0.55, fontSize: 13.5 });
  T(s, "Built for prototypes: the first 1–10 boards of a design. Volume goes to a fab, with files that already worked.", { x: 2.1, y: 5.05, w: 7.45, h: 0.2, fontSize: 7.5, color: MUTED });
  s.addNotes("Two wording changes from round 1: not 'a small electronics factory' (we are for prototypes), and placement is honest: you drop parts into a printed jig. Baker's own cycle is about two hours, so morning → evening holds.");
}

// =================================================================== 02 PROBLEM (founder's)
{
  const s = slide("Problem", "A prototype is a loop,\nand every lap costs weeks");
  s.addShape(pres.shapes.OVAL, { x: 0.8, y: 2.18, w: 2.45, h: 2.45, fill: { color: BG }, line: { color: DIM, width: 0.9, dashType: "dash" } });
  const nb = (t, x, y, w, color = TEXT, fill = BG, tc = TEXT) => { rect(s, x, y, w, 0.3, fill, color, 0.75); T(s, t, { x, y, w, h: 0.3, fontSize: 9, color: tc, align: "center", valign: "middle", bold: fill !== BG }); };
  nb("design", 1.7, 2.03, 0.66);
  nb("order", 2.87, 2.62, 0.6);
  nb("wait 2 weeks", 2.78, 3.38, 1.15, COPPER, COPPER, ONYEL);
  nb("solder by hand", 1.35, 4.48, 1.35);
  nb("test", 0.61, 3.92, 0.52);
  nb("bug found", 0.4, 2.87, 0.95, BLUE, BG, BLUE);
  T(s, "AND AGAIN", { x: 1.2, y: 3.02, w: 1.4, h: 0.2, fontSize: 9, color: MUTED, align: "center", charSpacing: 2 });
  T(s, "×3, ×4, ×5", { x: 1.12, y: 3.27, w: 1.55, h: 0.3, fontSize: 14, bold: true, color: TEXT, align: "center" });
  [["2", "weeks waiting for a board to come back from a fabrication house"], ["5", "instruments to buy before you can even measure it"], ["5", "vendor apps and driver stacks to learn and keep alive"]].forEach((x, i) => {
    const y = 1.95 + i * 0.9;
    H(s, x[0], { x: 4.05, y, w: 1, h: 0.75, fontSize: 44, color: COPPER });
    T(s, x[1], { x: 5.4, y: y + 0.12, w: 4.15, h: 0.5, fontSize: 10.5, color: TEXT });
    if (i < 2) line(s, 4.05, y + 0.84, 5.5, 0);
  });
  T(s, [{ text: "In my department a board ordered in week one gets measured in week four. " }, { text: "Nobody is short of ideas. They are short of tries.", options: { bold: true, color: TEXT } }], { x: 0.45, y: 4.9, w: 4.6, h: 0.55, fontSize: 9 });
  rect(s, 5.1, 4.82, 4.45, 0.62, YELLOW);
  T(s, [{ text: "WHY NOW · ", options: { bold: true } }, { text: "compute is cheap enough for machines to carry the fidelity. People should carry the innovation." }], { x: 5.22, y: 4.82, w: 4.25, h: 0.62, fontSize: 8.5, color: ONYEL, valign: "middle" });
}

// =================================================================== 03 WHY NOW (new)
{
  const s = slide("Why now", "AI can already build the software.\nHardware is where it gets stuck.");
  // left: software proof
  bar(s, 0.45, 1.95, 2.95, YELLOW);
  T(s, "SOFTWARE HAS A CLOSED LOOP", { x: 0.45, y: 2.07, w: 3, h: 0.2, fontSize: 7.5, color: YELLOW, charSpacing: 1.5 });
  H(s, "$100M ARR", { x: 0.45, y: 2.32, w: 3, h: 0.5, fontSize: 26 });
  T(s, "Lovable, 8 months after launch, selling to people who can't code. The model writes the code, runs it, reads the error and fixes it.", { x: 0.45, y: 2.88, w: 2.95, h: 1.0, fontSize: 8.5 });
  // middle: AI at file layer
  bar(s, 3.7, 1.95, 2.8, COPPER);
  T(s, "AI ALREADY DRAWS HARDWARE", { x: 3.7, y: 2.07, w: 2.8, h: 0.2, fontSize: 7.5, color: COPPER, charSpacing: 1.5 });
  [["Flux", "$49M raised · 1M+ users"], ["Quilter", "$40M raised · AI layout"], ["Diode", "$11.4M Series A · a16z"], ["Claude ↔ Fusion, Blender", "official connectors, 2026"]].forEach((r, i) => {
    const y = 2.35 + i * 0.37;
    H(s, r[0], { x: 3.7, y, w: 2.8, h: 0.18, fontSize: 9 });
    T(s, r[1], { x: 3.7, y: y + 0.18, w: 2.8, h: 0.16, fontSize: 7.2, color: MUTED });
  });
  // right: the gap
  bar(s, 6.8, 1.95, 2.75, BLUE);
  T(s, "…AND STOPS AT THE FILE", { x: 6.8, y: 2.07, w: 2.8, h: 0.2, fontSize: 7.5, color: BLUE, charSpacing: 1.5 });
  T(s, "No model can make the board, power it, or see whether it works. The loop breaks at the bench, and a person carries it for two weeks.", { x: 6.8, y: 2.35, w: 2.75, h: 1.2, fontSize: 8.5, color: TEXT });
  // loop strip
  const st = [["idea", TEXT], ["files", TEXT], ["board", COPPER], ["test", BLUE], ["verdict", YELLOW]];
  st.forEach((x, i) => {
    const xx = 0.45 + i * 1.3;
    rect(s, xx, 4.05, 1.1, 0.34, BG, x[1]);
    T(s, x[0], { x: xx, y: 4.05, w: 1.1, h: 0.34, fontSize: 9, color: x[1], align: "center", valign: "middle" });
    if (i < 4) line(s, xx + 1.1, 4.22, 0.2, 0, DIM, 0.75, null, true);
  });
  line(s, 2.95, 3.9, 0, 0.72, COPPER, 1.25, "dash");
  T(s, "AI works here today", { x: 0.45, y: 4.48, w: 2.4, h: 0.2, fontSize: 7, color: MUTED, align: "center" });
  T(s, "protopus gives the AI hands and eyes here", { x: 3.05, y: 4.48, w: 3.5, h: 0.2, fontSize: 7, color: YELLOW, align: "center" });
  rect(s, 7.05, 3.95, 2.5, 0.8, YELLOW);
  T(s, "Smart machines + smart accessories = the AI's access to the real world.", { x: 7.15, y: 3.95, w: 2.33, h: 0.8, fontSize: 8.5, bold: true, color: ONYEL, valign: "middle" });
  src(s, "TechCrunch 23 Jul 2025 · SiliconANGLE 27 Feb 2026 · BusinessWire 7 Oct 2025 · Fenwick · claude.com/connectors · digitalproduction.com 30 Apr 2026");
  s.addNotes("The AI part is proven: about $100M has gone into AI that produces hardware files. All of it stops at the file. Protopus builds the machines and accessories that let a model make, measure and learn.");
}

// =================================================================== 04 WHO WE UNLOCK (new)
{
  const s = slide("Who we unlock", "Every rung of hardware knowledge\nloses people. Proto removes rungs.");
  const r = [["01", "idea → spec", "What exactly should it do?", "Proto asks, then writes it"], ["02", "parts", "Datasheets, stock, footprints", "Proto picks in-stock parts"], ["03", "schematic", "Circuit theory, references", "Flux + Proto check it"], ["04", "layout", "An EDA tool, DRC", "Proto fixes it (Baker Studio)"], ["05", "fabrication", "Vendors, customs, 7–20 days", "Baker, same day"], ["06", "assembly", "SMD soldering, stencil, reflow", "Baker + printed jig"], ["07", "bring-up", "Scope, logic analyser, firmware", "Mixer measures"], ["08", "debug", "Root cause, next revision", "Proto explains the fix"]];
  T(s, "RUNG", { x: 0.45, y: 1.9, w: 2, h: 0.18, fontSize: 7, color: MUTED, charSpacing: 1 });
  T(s, "YOU USED TO NEED", { x: 2.3, y: 1.9, w: 2.3, h: 0.18, fontSize: 7, color: MUTED, charSpacing: 1 });
  T(s, "WHO CARRIES IT NOW", { x: 4.75, y: 1.9, w: 2, h: 0.18, fontSize: 7, color: MUTED, charSpacing: 1 });
  line(s, 0.45, 2.1, 6.3, 0, TEXT, 0.75);
  r.forEach((x, i) => {
    const y = 2.15 + i * 0.37, phys = i >= 4;
    T(s, x[0], { x: 0.45, y, w: 0.35, h: 0.33, fontSize: 8, color: phys ? COPPER : MUTED, valign: "middle" });
    H(s, x[1], { x: 0.82, y, w: 1.45, h: 0.33, fontSize: 9.5, valign: "middle" });
    T(s, x[2], { x: 2.3, y, w: 2.4, h: 0.33, fontSize: 7.5, valign: "middle" });
    T(s, x[3], { x: 4.75, y, w: 2.0, h: 0.33, fontSize: 7.5, color: phys ? COPPER : YELLOW, valign: "middle" });
    line(s, 0.45, y + 0.35, 6.3, 0);
  });
  rect(s, 7.05, 1.9, 2.5, 3.3, PANEL, RULE);
  bar(s, 7.05, 1.9, 2.5, YELLOW);
  T(s, "HOW PEOPLE LEARN", { x: 7.22, y: 2.05, w: 2.2, h: 0.2, fontSize: 7.5, color: YELLOW, charSpacing: 1.5 });
  T(s, "By doing: try, look, adjust (Kolb's cycle). The speed of feedback sets the speed of learning.", { x: 7.22, y: 2.3, w: 2.2, h: 0.85, fontSize: 8, color: TEXT });
  H(s, "2 weeks", { x: 7.22, y: 3.2, w: 2.2, h: 0.36, fontSize: 18, color: COPPER });
  T(s, "per try: beginners quit, experts batch changes", { x: 7.22, y: 3.55, w: 2.2, h: 0.35, fontSize: 7.2 });
  H(s, "same evening", { x: 7.22, y: 4.0, w: 2.2, h: 0.36, fontSize: 18, color: YELLOW });
  T(s, "per try: a student gets many more attempts in one semester", { x: 7.22, y: 4.35, w: 2.2, h: 0.5, fontSize: 7.2 });
  T(s, "Every rung we take away brings in a new crowd: students, designers, domain experts. Lovable showed what happens when the coding rung disappears.", { x: 0.45, y: 5.12, w: 6.3, h: 0.35, fontSize: 7.2, color: MUTED });
}

// =================================================================== 05 SOLUTION
{
  const s = slide("Solution", "One AI engineer, and the two smart machines it runs", { th: 0.45 });
  const cols = [
    ["proto", YELLOW, A + "mascot.png", 410 / 250, "A platypus AI engineer inside both machines.", "Reads the design · plans the job · flags mistakes · explains results"],
    ["baker", COPPER, A + "r0.png", 1272 / 898, "Makes the board, ready for parts.", "Mill · drill · mask · laser stencil · paste · guided placement · reflow"],
    ["mixer", BLUE, A + "r1.png", 1103 / 820, "Tests the board in real life.", "Eight instruments behind one cable"],
  ];
  cols.forEach((c, i) => {
    const x = 0.45 + i * 3.12, w = 2.9, ih = 1.32;
    const iw = Math.min(w, ih * c[3]);
    s.addImage({ path: c[2], x: x + (w - iw) / 2, y: 1.35, w: iw, h: iw / c[3] });
    bar(s, x, 2.73, w, c[1]);
    H(s, c[0], { x, y: 2.88, w, h: 0.45, fontSize: 24, color: c[1] });
    T(s, c[4], { x, y: 3.36, w, h: 0.45, fontSize: 9.5, color: TEXT });
    T(s, c[5], { x, y: 3.82, w, h: 0.42, fontSize: 7.8, color: BODY });
  });
  line(s, 0.45, 4.35, 9.1, 0);
  T(s, [{ text: "VISION · ", options: { color: COPPER } }, { text: "a bridge between idea and innovation for anyone who wants to bring theirs to the world.", options: { color: TEXT } }], { x: 0.45, y: 4.52, w: 3.4, h: 0.7, fontSize: 8.5 });
  [["DEMO 1", "Website walk-through · protopus-kappa.vercel.app"], ["DEMO 2", "Video · raw Baker prototype running"]].forEach((d, i) => {
    const x = 4.0 + i * 2.8;
    rect(s, x, 4.48, 2.62, 0.7, PANEL, RULE);
    pill(s, d[0], x + 0.12, 4.71, 0.66);
    T(s, d[1], { x: x + 0.88, y: 4.53, w: 1.68, h: 0.6, fontSize: 8, bold: true, color: TEXT, valign: "middle" });
  });
  s.addNotes("Proto first. Baker now reads 'guided placement', not 'pick and place': the operator drops parts into a printed jig, which is what the prototype does.");
}

// =================================================================== 06 PROTO (founder's)
{
  const s = slide("What makes it ours", "Proto: an AI engineer that understands your board", { kc: YELLOW, th: 0.45 });
  rect(s, 0.45, 1.4, 3.5, 2.11, BG, YELLOW, 1.25);
  s.addImage({ path: A + "studio.png", x: 0.47, y: 1.42, w: 3.46, h: 2.07 });
  T(s, [{ text: "PROTOPUS   ", options: { color: YELLOW } }, { text: "Baker Studio", options: { color: TEXT, bold: true } }], { x: 0.45, y: 3.6, w: 3.5, h: 0.2, fontSize: 8.5 });
  T(s, "Proto has already found the thin trace, fixed it and planned the mill. You press Accept.", { x: 0.45, y: 3.83, w: 3.5, h: 0.4, fontSize: 8 });
  [["01", "READS THE BOARD", "Understands schematics and layouts. Pulls designs in through the Flux.ai API.", COPPER], ["02", "MAKES IT", "Generates the Gerbers and the Baker job: mill, drill, mask, stencil, placement.", COPPER], ["03", "DIAGNOSES IT", "Tests through Mixer, understands the waveforms and says in plain words what is wrong.", BLUE], ["04", "HAS A CHARACTER", "A platypus engineer with a personality developed through Gemini.", TEXT]].forEach((r, i) => {
    const y = 1.4 + i * 0.7;
    line(s, 4.25, y - 0.04, 5.3, 0);
    H(s, r[0], { x: 4.25, y, w: 0.45, h: 0.35, fontSize: 15, color: r[3] });
    T(s, r[1], { x: 4.72, y, w: 4.8, h: 0.18, fontSize: 8, color: r[3] === TEXT ? YELLOW : r[3], charSpacing: 1.5 });
    T(s, r[2], { x: 4.72, y: y + 0.2, w: 4.8, h: 0.42, fontSize: 8.5, color: TEXT });
  });
  rect(s, 0.45, 4.35, 9.1, 0.6, PANEL);
  pill(s, "COMING NEXT", 0.6, 4.53, 1.1);
  H(s, "Probe matrix accessory", { x: 1.85, y: 4.4, w: 7.5, h: 0.2, fontSize: 10 });
  T(s, "A grid of probes under the board gives Proto full access to every net on the PCB: it can measure anything, not just what you clip.", { x: 1.85, y: 4.62, w: 7.6, h: 0.3, fontSize: 7.5 });
  H(s, [{ text: "Simple enough that a " }, { text: "high-school student", options: { color: YELLOW } }, { text: " can print a board." }], { x: 0.45, y: 5.08, w: 9.1, h: 0.33, fontSize: 14 });
}

// =================================================================== 07 HOW PROTO THINKS (new tech)
{
  const s = slide("Proto · how the AI works", "Proto is a loop, not a chatbot: understand,\nplan, check, make, measure, explain", { kc: YELLOW });
  // input column
  rect(s, 0.45, 1.95, 1.35, 2.35, PANEL, RULE);
  T(s, "YOU GIVE IT", { x: 0.55, y: 2.03, w: 1.2, h: 0.18, fontSize: 6.8, color: YELLOW, charSpacing: 1 });
  ["an idea in words", "a sketch or photo", "Flux / KiCad files", "a Gerber set", "“why is this hot?”"].forEach((t, i) => T(s, t, { x: 0.55, y: 2.3 + i * 0.38, w: 1.22, h: 0.33, fontSize: 7.5, color: TEXT }));
  line(s, 1.8, 3.12, 0.22, 0, DIM, 0.75, null, true);
  // top row stages
  const top = [["UNDERSTAND", "Parses netlist, footprints, stack-up into a board model", YELLOW], ["PLAN", "LLM planner turns the goal into steps; asks when unsure", YELLOW], ["CHECK", "DRC + Baker rules: trace, clearance, aperture, drill", STEEL], ["MAKE", "CAM engine: toolpaths, mask image, stencil, jig → Baker job", COPPER]];
  top.forEach((c, i) => {
    const x = 2.08 + i * 1.88;
    rect(s, x, 1.95, 1.72, 1.02, BG, c[2]);
    T(s, c[0], { x: x + 0.1, y: 2.02, w: 1.55, h: 0.18, fontSize: 7.5, bold: true, color: c[2], charSpacing: 1 });
    T(s, c[1], { x: x + 0.1, y: 2.25, w: 1.55, h: 0.7, fontSize: 7.2, color: TEXT });
    if (i < 3) line(s, x + 1.72, 2.46, 0.16, 0, DIM, 0.75, null, true);
  });
  // down arrow from MAKE
  line(s, 2.08 + 3 * 1.88 + 0.86, 2.97, 0, 0.3, DIM, 0.75, null, true);
  // bottom row (right to left)
  const bot = [["EXPLAIN", "Compares measured vs expected; writes the verdict and the fix", YELLOW], ["MEASURE", "Mixer runs the test plan: rails, currents, waveforms, buses", BLUE], ["APPROVE", "You press Accept. Nothing is cut, lasered or powered before", TEXT]];
  bot.forEach((c, i) => {
    const x = 2.08 + (i + 1) * 1.88;
    rect(s, x, 3.28, 1.72, 1.02, BG, c[2]);
    T(s, c[0], { x: x + 0.1, y: 3.35, w: 1.55, h: 0.18, fontSize: 7.5, bold: true, color: c[2], charSpacing: 1 });
    T(s, c[1], { x: x + 0.1, y: 3.58, w: 1.55, h: 0.7, fontSize: 7.2, color: TEXT });
  });
  // arrows bottom row leftwards: approve(x3) <- make above, measure <- approve, explain <- measure
  line(s, 2.08 + 3 * 1.88, 3.79, -0.16, 0, DIM, 0.75, null, true);
  line(s, 2.08 + 2 * 1.88, 3.79, -0.16, 0, DIM, 0.75, null, true);
  // loop back: explain -> plan (up arrow)
  line(s, 2.08 + 1.88 + 0.86, 3.28, 0, -0.3, YELLOW, 0.9, null, true);
  T(s, "next attempt", { x: 2.08 + 1.88 + 0.92, y: 3.02, w: 1, h: 0.2, fontSize: 6.5, color: YELLOW });
  // Result box left bottom
  rect(s, 2.08, 3.28, 1.72, 1.02, YELLOW);
  T(s, "YOU GET", { x: 2.18, y: 3.35, w: 1.5, h: 0.18, fontSize: 7.5, bold: true, color: ONYEL, charSpacing: 1 });
  T(s, "a tested board and a sentence: what passed, what failed, where to look", { x: 2.18, y: 3.58, w: 1.52, h: 0.7, fontSize: 7.2, color: ONYEL });
  line(s, 2.08 + 1.88, 3.79, -0.16, 0, DIM, 0.75, null, true);
  // memory bar
  rect(s, 0.45, 4.5, 9.1, 0.5, PANEL, RULE);
  T(s, "MEMORY", { x: 0.58, y: 4.5, w: 1.1, h: 0.5, fontSize: 7.5, bold: true, color: YELLOW, valign: "middle", charSpacing: 1 });
  T(s, "Every run is logged: design → process settings → measurements → outcome. The next board, and every other Baker, learns from it. No files-only AI tool can collect this data: it is the moat.", { x: 1.6, y: 4.5, w: 7.85, h: 0.5, fontSize: 7.5, color: TEXT, valign: "middle" });
  src(s, "Model-agnostic: the character runs on Gemini today; the planner calls any frontier model through an API. Machine control stays local and works offline.", 5.12);
  s.addNotes("How the AI actually works. The language model understands, plans and explains. Precise work (DRC maths, toolpaths, G-code, pass/fail limits) is done by deterministic engines Proto calls as tools. A person approves before anything physical happens. Every run feeds a memory that no files-only AI can build.");
}

// =================================================================== 08 ONE RUN (new tech)
{
  const s = slide("Proto · one run, step by step", "What happens between “import” and “PASS”", { kc: YELLOW, th: 0.45 });
  rect(s, 0.45, 1.35, 6.55, 3.72, PANEL, RULE);
  T(s, "baker studio — sensor-hat-rev-c.brd · 62.0 × 40.5 mm", { x: 0.6, y: 1.43, w: 6.3, h: 0.18, fontSize: 7, color: MUTED });
  line(s, 0.45, 1.66, 6.55, 0);
  const W = { you: TEXT, proto: YELLOW, baker: COPPER, mixer: BLUE };
  const log = [
    ["10:02", "you", "import sensor-hat-rev-c from Flux"],
    ["10:02", "proto", "DRC 0/0. Baker rules: one trace under the MCU necks to 5.8 mil."],
    ["10:03", "proto", "widened it to 7 mil and kept clearance. Board still fits.  [Accept]"],
    ["10:03", "proto", "job: isolation mill, 0.4 mm V, 2 passes · drill 42 holes · mask · stencil · jig"],
    ["10:04", "baker", "steps 01–12 running · placement jig printing in parallel"],
    ["11:40", "you", "drop parts into the jig pockets · vacuum pen"],
    ["11:52", "baker", "reflow, Sn42Bi58 low-temperature profile"],
    ["12:05", "mixer", "T2 power up: current limit set · idle current in range  ✓"],
    ["12:06", "mixer", "T3 rails: 3V3 within limit  ✓"],
    ["12:07", "mixer", "T6 I²C scan: no ACK from the sensor  ✗"],
    ["12:08", "proto", "“SDA has no pull-up. R4 is lifted on one pad. Reheat R4 and retest.”"],
    ["12:15", "mixer", "retest: sensor ACKs, reading plausible  ✓  PASS"],
  ];
  log.forEach((l, i) => {
    const y = 1.75 + i * 0.27;
    T(s, l[0], { x: 0.6, y, w: 0.5, h: 0.25, fontSize: 7, color: MUTED, valign: "middle" });
    T(s, l[1], { x: 1.12, y, w: 0.55, h: 0.25, fontSize: 7.2, color: W[l[1]], bold: true, valign: "middle" });
    T(s, l[2], { x: 1.7, y, w: 5.25, h: 0.25, fontSize: 7.2, color: l[1] === "proto" ? TEXT : BODY, valign: "middle" });
  });
  // right side: what was used
  T(s, "WHAT PROTO CALLED", { x: 7.25, y: 1.35, w: 2.3, h: 0.2, fontSize: 7.5, color: YELLOW, charSpacing: 1.5 });
  [["Flux.ai API", "design in"], ["DRC + Baker rules", "found 5.8 mil"], ["CAM engine", "toolpaths, mask, stencil, jig"], ["Klipper / Moonraker", "ran Baker"], ["Test-plan builder", "from the netlist"], ["Mixer driver", "supplies, DMM, logic"], ["Language model", "the plain-words verdict"]].forEach((r, i) => {
    const y = 1.65 + i * 0.44;
    H(s, r[0], { x: 7.25, y, w: 2.3, h: 0.2, fontSize: 8.5 });
    T(s, r[1], { x: 7.25, y: y + 0.2, w: 2.3, h: 0.18, fontSize: 7, color: MUTED });
    line(s, 7.25, y + 0.41, 2.3, 0);
  });
  src(s, "Illustrative run on the board shown in Baker Studio. Times are the engineering targets (≈2 h Baker cycle, ≈15–20 min hands-on); the proof of concept measures them.");
  s.addNotes("A concrete run, from import to PASS. Proto calls tools; it doesn't improvise G-code. The diagnosis is where the language model shines: it links a missing I²C ACK to a lifted pull-up resistor and says what to do.");
}

// =================================================================== 09 WHERE THE AI IS (new tech)
{
  const s = slide("Proto · guardrails and roadmap", "Where the AI is, and where it isn't", { kc: YELLOW, th: 0.45 });
  const cols = [
    ["THE MODEL DOES", YELLOW, ["understands what you want", "reads the design and datasheets", "plans the job and asks questions", "drafts the test plan", "explains results and proposes the fix", "has a character (Gemini)"]],
    ["THE ENGINES DO", STEEL, ["DRC maths and Baker process rules", "toolpaths, G-code, mask and stencil images", "jig geometry and placement map", "test limits and pass/fail", "current limits on every supply", "interlocks: door, E-stop, laser cut-off"]],
    ["YOU DO", TEXT, ["describe the idea", "press Accept before anything physical", "drop parts into the jig", "decide on the fix", "own the design and the IP", ""]],
  ];
  cols.forEach((c, i) => {
    const x = 0.45 + i * 3.1;
    bar(s, x, 1.38, 2.9, c[1]);
    T(s, c[0], { x, y: 1.5, w: 2.9, h: 0.2, fontSize: 8, bold: true, color: c[1], charSpacing: 1.5 });
    c[2].filter(Boolean).forEach((t, k) => { T(s, "— " + t, { x, y: 1.82 + k * 0.27, w: 2.9, h: 0.25, fontSize: 8, color: TEXT }); });
  });
  T(s, "The model never drives a motor directly. It proposes; tested engines compute; you approve; the machine executes.", { x: 0.45, y: 3.5, w: 9.1, h: 0.25, fontSize: 9, bold: true, color: YELLOW });
  line(s, 0.45, 3.9, 9.1, 0, TEXT);
  const road = [["V0 · TODAY", "Baker Studio: DRC fix + mill planning, with Proto inside", COPPER], ["V1 · PROOF OF CONCEPT", "Full Baker job + Mixer test plan + plain-words verdict", YELLOW], ["V2 · AFTER SEED", "Idea → design via Flux/KiCad; enclosures via Fusion/Blender; 3D printer", BLUE], ["V3 · FLEET", "Learns from every Baker's run data; probe matrix sees every net", GREEN]];
  road.forEach((r, i) => {
    const x = 0.45 + i * 2.28;
    dot(s, x, 3.85, true, r[2], r[2], 0.1);
    T(s, r[0], { x, y: 4.05, w: 2.15, h: 0.18, fontSize: 7.5, color: r[2], charSpacing: 1 });
    T(s, r[1], { x, y: 4.28, w: 2.15, h: 0.7, fontSize: 8, color: TEXT });
    if (i) line(s, x - 0.13, 4.05, 0, 0.9);
  });
  s.addNotes("This slide answers 'is the AI safe near a spindle and a Class 4 laser?' and 'what is real today?'. V0 is running in Baker Studio; V1 is what the ₹16 lakh proves.");
}

// =================================================================== 10 BAKER AT A GLANCE (new tech)
{
  const s = slide("Baker · at a glance", "Fifteen steps on one shuttle, in one box", { th: 0.45 });
  // enclosure
  rect(s, 0.45, 1.38, 6.2, 3.3, BG, DIM, 0.9);
  T(s, "BAKER ENCLOSURE · T-slot frame · acrylic · 450 nm laser-safe window · door interlocks · E-stop", { x: 0.55, y: 1.44, w: 6.0, h: 0.18, fontSize: 6.5, color: MUTED });
  // film roll
  rect(s, 1.6, 1.72, 3.9, 0.26, BG, STEEL, 0.75);
  T(s, "Kapton stencil film roll · 4 electromagnet clamp · solenoid cut-off", { x: 1.6, y: 1.72, w: 3.9, h: 0.26, fontSize: 6.8, color: STEEL, align: "center", valign: "middle" });
  // zone A
  rect(s, 1.1, 2.12, 2.35, 1.5, BG, COPPER, 1);
  T(s, "ZONE A · cross axis + Z", { x: 1.2, y: 2.17, w: 2.2, h: 0.18, fontSize: 7, bold: true, color: COPPER });
  T(s, "Spindle 500 W ER11\ntouch probe · V-bit · drills\n\nLaser 10 W 445 nm\nfixed offset · air assist\n\nvacuum dust extraction", { x: 1.2, y: 2.4, w: 2.2, h: 1.2, fontSize: 6.8, color: TEXT });
  // zone B
  rect(s, 3.65, 2.12, 2.35, 1.5, BG, STEEL, 1);
  T(s, "ZONE B · cross axis + Z", { x: 3.75, y: 2.17, w: 2.2, h: 0.18, fontSize: 7, bold: true, color: STEEL });
  T(s, "Mask: syringe LPSM\n\nUV: 10.1\" 12K LCD, 405 nm\n\nWipe: Na₂CO₃ + air knife\n\npaste squeegee rides here too", { x: 3.75, y: 2.4, w: 2.2, h: 1.2, fontSize: 6.8, color: TEXT });
  // magazine
  rect(s, 0.58, 2.12, 0.4, 1.5, BG, DIM);
  T(s, "FR4\nmag\nazine", { x: 0.58, y: 2.12, w: 0.4, h: 1.5, fontSize: 6.3, color: MUTED, align: "center", valign: "middle" });
  // shuttle
  rect(s, 0.58, 3.85, 5.95, 0.34, COPPER);
  T(s, "⟷  SHUTTLE = long X axis · ball screw + NEMA23 · FR4 on 2 registration pins · runs under both zones", { x: 0.58, y: 3.85, w: 5.95, h: 0.34, fontSize: 6.8, bold: true, color: ONYEL, align: "center", valign: "middle" });
  T(s, "steps 01–12 happen in one coordinate frame", { x: 0.58, y: 4.3, w: 5.95, h: 0.2, fontSize: 6.8, color: MUTED, align: "center" });
  // off-gantry
  rect(s, 6.9, 1.38, 1.25, 1.55, BG, MUTED);
  T(s, "PLACE + REFLOW", { x: 6.95, y: 1.44, w: 1.15, h: 0.18, fontSize: 6.5, bold: true, color: TEXT });
  T(s, "steps 13–14\nprinted jig on\nthe same pins\nvacuum pen\n300 W hotplate\nSn42Bi58, 138 °C", { x: 6.95, y: 1.66, w: 1.18, h: 1.25, fontSize: 6.3, color: BODY });
  rect(s, 8.3, 1.38, 1.25, 1.55, BG, BLUE);
  T(s, "MIXER", { x: 8.35, y: 1.44, w: 1.15, h: 0.18, fontSize: 6.5, bold: true, color: BLUE });
  T(s, "step 15\none cable\n8 instruments\nProto reads\nthe results", { x: 8.35, y: 1.66, w: 1.18, h: 1.25, fontSize: 6.3, color: BODY });
  line(s, 8.15, 2.15, 0.15, 0, DIM, 0.75, null, true);
  line(s, 6.65, 2.15, 0.25, 0, DIM, 0.75, null, true);
  rect(s, 6.9, 3.1, 2.65, 0.55, BG, YELLOW, 0.75);
  T(s, "resin printer, in parallel: prints the TR300 jig during steps 01–12", { x: 7.0, y: 3.1, w: 2.5, h: 0.55, fontSize: 6.8, color: YELLOW, valign: "middle" });
  // stats
  [["15", "steps, blank FR4 → tested board"], ["1", "shuttle, one coordinate frame"], ["100×160", "mm board in the workflow"], ["8", "instruments on Mixer"]].forEach((x, i) => {
    const xx = 0.45 + i * 2.28, y = 4.78;
    H(s, x[0], { x: xx, y, w: 2.1, h: 0.36, fontSize: 18, color: i === 3 ? BLUE : COPPER });
    T(s, x[1], { x: xx, y: y + 0.36, w: 2.1, h: 0.2, fontSize: 7, color: MUTED });
  });
  s.addNotes("The whole machine on one slide, from the workflow story. The shuttle never lifts or re-registers the board between cutting, masking and stencilling: that is the process IP.");
}

// =================================================================== 11 STORY OF ONE BOARD (new tech)
{
  const s = slide("Baker · the story of one board", "From a plain sheet to a board ready for Mixer", { th: 0.45 });
  const ch = [
    ["It starts as a plain sheet", "01 · 05", "FR4 drops from the magazine onto two registration pins. One coordinate frame from here to placement.", "FR4 blanks · dowel pins · ball-screw shuttle + NEMA23", MUTED],
    ["Zone A reads the board, then cuts it", "02–04", "A touch probe maps height on a grid, so the 0.1 mm V-bit cuts the same few microns everywhere. Same spindle drills; vacuum pulls the dust.", "pogo probe · 500 W ER11 · 20° V-bits · 0.3–1.2 mm drills", COPPER],
    ["Zone B finishes the copper", "06–09", "Liquid mask, a 10.1\" LCD cures all but the pads, a dilute Na₂CO₃ wipe lifts the pads clean, air knife, flood cure. No tank, no bath.", "syringe LPSM · 12K mono LCD · 405 nm UV · peristaltic pump", STEEL],
    ["The stencil fits this exact board", "10–12", "The laser cuts pad openings in film above the board, from the same Gerber in the same frame. Magnets clamp, squeegee pastes, film is cut away.", "10 W 445 nm laser · Kapton roll · 4 × 8 kg magnets · 25 N solenoid", COPPER],
    ["The jig does the aiming", "13", "While 01–12 ran, the resin printer made a jig with one pocket per part. You drop each part in with the foot-pedal vacuum pen.", "TR300 resin (160 °C) · vacuum pump + NC valve · foot pedal", MUTED],
    ["Reflow at low temperature", "14 → 15", "The jig lifts off; the hotplate runs a Sn42Bi58 profile (138 °C), below the resin's limit, with less warp. Then Mixer tests it.", "300 W silicone pad · SSR-25DA · MAX31855 + K-type", BLUE],
  ];
  ch.forEach((c, i) => {
    const col = i % 3, row = Math.floor(i / 3);
    const x = 0.45 + col * 3.1, y = 1.38 + row * 1.9;
    bar(s, x, y, 2.9, c[4]);
    T(s, "STEPS " + c[1], { x, y: y + 0.1, w: 2.9, h: 0.18, fontSize: 7, color: c[4] === MUTED ? BODY : c[4], charSpacing: 1.5 });
    H(s, c[0], { x, y: y + 0.3, w: 2.9, h: 0.24, fontSize: 10 });
    T(s, c[2], { x, y: y + 0.58, w: 2.88, h: 0.78, fontSize: 7.2, color: BODY });
    T(s, "cast · " + c[3], { x, y: y + 1.38, w: 2.88, h: 0.38, fontSize: 6.3, color: MUTED });
  });
  src(s, "Source: PROTOPUS Baker + Mixer workflow, “The story of a PCB” (29 Sep 2026).", 5.22);
}

// =================================================================== 12 BAKER PROTO → PRODUCTION (new tech)
{
  const s = slide("Baker · tech stack, prototype → production", "Same story, cheaper parts: ₹3,73,418 → ₹1,44,842", { th: 0.45 });
  tbl(s, [
    ["FUNCTION", "PROTOTYPE (INDIA, 1 UNIT)", "PRODUCTION (CHINA PARTS, 100)", "WHY"],
    ["Axes", "Finished ball-screw linear stages", "SFU1605 ball screws + HGR15 rails built in", "≈₹5,500 per axis vs ₹16,500"],
    ["Z axes", "100 mm SFU1605 stage + NEMA17 ×2", "T8 screw + linear guide", "Spindle/laser Z and dispense Z"],
    ["Control", "Raspberry Pi 5 + BTT Octopus Pro + DM556", "BTT Manta M8P V2 + CB1 (8 × TMC2209)", "One board, 8 drivers, ≈₹10,800"],
    ["Power", "24 V + 48 V + 12 V supplies", "One LRS-350-24 rail (spindle keeps its own)", "Fewer supplies, simpler wiring"],
    ["Spindle + laser", "500 W ER11 kit · 10 W 445 nm diode (retail)", "Volume-sourced; quotes at 100 units", "Where the turnkey case is won or lost"],
    ["Mask + UV", "Syringe LPSM · 10.1\" 12K LCD · ChiTu L K1 · 405 nm", "Same engine", "The LCD also prints jigs in production"],
    ["Placement jig", "Separate Saturn 3 Ultra + wash/cure", "Small resin vat + lift under Baker's own UV screen", "Removes the printer (to test)"],
    ["Frame", "T-slot extrusion + acrylic", "Sheet-metal frame + acrylic panels", "Repeatable fabrication"],
    ["Firmware", "Klipper + Moonraker + Proto job runner", "Locked factory image; activation stays with us", "IP by architecture"],
    [tt("Unit cost", { bold: true }), tt("₹3,73,418 (incl. 35% duty/courier, 15% contingency)", { color: TEXT, bold: true }), tt("₹1,44,842 (incl. duty, freight, Delhi assembly)", { color: COPPER, bold: true }), tt("Deck target ₹1,50,000", { bold: true })],
  ], { x: 0.45, y: 1.35, w: 9.1, colW: [1.3, 2.85, 2.85, 2.1], fontSize: 7, rowH: 0.33 }, [10]);
  src(s, "Sources: PROTOPUS Cost Report (29 Sep 2026, 81 of 96 lines from live listings, USD at ₹88) · workflow story, chapter 6.");
}

// =================================================================== 13 MIXER AT A GLANCE (new tech)
{
  const s = slide("Mixer · at a glance", "Eight instruments, one cable, one brain", { kc: BLUE, th: 0.45 });
  // signal path diagram
  const inputs = ["2 × scope in · BNC", "wavegen out · 2-ch", "16 logic lines", "DMM leads", "2 × supply out"];
  inputs.forEach((t, i) => { rect(s, 0.45, 1.4 + i * 0.44, 1.35, 0.34, BG, DIM); T(s, t, { x: 0.45, y: 1.4 + i * 0.44, w: 1.35, h: 0.34, fontSize: 6.5, color: BODY, align: "center", valign: "middle" }); });
  const mid = [["analog front end", "AD8066 FET buffers · relay ranges", 1.4], ["level shifters", "74LVC245 ×2", 2.28], ["24-bit multimeter", "ADS1256 + REF5025", 2.72], ["2 programmable supplies", "MCP4728 → XL6009 ×2 · INA226", 3.16]];
  mid.forEach((m) => { rect(s, 2.0, m[2], 1.7, m[0] === "analog front end" ? 0.78 : 0.34, BG, BLUE); T(s, [{ text: m[0], options: { bold: true, color: TEXT, breakLine: true } }, { text: m[1] }], { x: 2.05, y: m[2], w: 1.62, h: m[0] === "analog front end" ? 0.78 : 0.34, fontSize: 6.2, color: BODY, valign: "middle" }); });
  rect(s, 3.9, 1.4, 1.3, 0.34, BG, BLUE); T(s, [{ text: "ADC ×2", options: { bold: true, color: TEXT, breakLine: true } }, { text: "AD9226 12-bit 65 MS/s" }], { x: 3.92, y: 1.4, w: 1.26, h: 0.34, fontSize: 6, color: BODY, align: "center", valign: "middle" });
  rect(s, 3.9, 1.84, 1.3, 0.34, BG, BLUE); T(s, [{ text: "DAC 2-ch", options: { bold: true, color: TEXT, breakLine: true } }, { text: "AN9767 14-bit 125 MS/s" }], { x: 3.92, y: 1.84, w: 1.26, h: 0.34, fontSize: 6, color: BODY, align: "center", valign: "middle" });
  rect(s, 5.4, 1.4, 1.3, 1.22, BLUE);
  T(s, [{ text: "FPGA", options: { bold: true, breakLine: true } }, { text: "Tang Primer 20K\ncapture + trigger\nwaveform synthesis\npattern gen\nlogic sampling" }], { x: 5.45, y: 1.4, w: 1.22, h: 1.22, fontSize: 6.2, color: ONYEL, valign: "middle" });
  rect(s, 5.4, 2.8, 1.3, 0.72, BG, YELLOW);
  T(s, [{ text: "HOST", options: { bold: true, color: YELLOW, breakLine: true } }, { text: "Raspberry Pi 5\nruns Proto" }], { x: 5.45, y: 2.8, w: 1.22, h: 0.72, fontSize: 6.2, color: TEXT, valign: "middle" });
  [[1.8, 1.79, 0.2], [1.8, 2.45, 0.2], [1.8, 2.89, 0.2], [1.8, 3.33, 0.2], [3.7, 1.57, 0.2], [3.7, 2.01, 0.2], [5.2, 1.8, 0.2]].forEach((a) => line(s, a[0], a[1], a[2], 0, DIM, 0.75, null, true));
  line(s, 3.7, 2.89, 1.7, 0.1, DIM, 0.75, null, true);
  line(s, 6.05, 2.62, 0, 0.18, DIM, 0.75, null, true);
  rect(s, 0.45, 3.72, 6.25, 0.38, YELLOW);
  T(s, "→ Proto compares every reading with what the design expects and writes the verdict in plain words", { x: 0.55, y: 3.72, w: 6.1, h: 0.38, fontSize: 7.5, bold: true, color: ONYEL, valign: "middle" });
  // instrument table
  tbl(s, [
    ["INSTRUMENT", "PROTOTYPE SPEC"],
    ["Oscilloscope", "2 ch · 12-bit · 65 MS/s"],
    ["Waveform generator", "2 ch · 14-bit"],
    ["Logic analyser", "16 ch"],
    ["Pattern generator", "digital stimulus"],
    ["Protocol decoder", "I²C · SPI · serial"],
    ["Supply 1 + 2", "set-point + current readback"],
    ["Multimeter", "24-bit"],
  ], { x: 6.95, y: 1.4, w: 2.6, colW: [1.25, 1.35], fontSize: 7, rowH: 0.3 });
  T(s, "Analog Discovery 3 class. The prototype keeps 12/14-bit converters so the front end can be tuned first.", { x: 0.45, y: 4.3, w: 6.25, h: 0.35, fontSize: 7.5, color: MUTED });
  T(s, "Status: architecture and BOM defined (₹74,847 prototype); first build in the proof of concept.", { x: 6.95, y: 3.95, w: 2.6, h: 0.7, fontSize: 7, color: MUTED });
  src(s, "Source: workflow story, chapter 4 (signal path drawn from the Mixer BOM).", 5.1);
}

// =================================================================== 14 MIXER TEST RUN (new tech)
{
  const s = slide("Mixer · how a test runs", "T1 to T8, in the order a careful engineer would work", { kc: BLUE, th: 0.45 });
  const t = [["T1", "Connect", "One cable; probes on the test points the design calls for"], ["T2", "Power up safely", "Supplies set; INA226 watches current, so a bridge is a spike, not a burnt part"], ["T3", "Check the rails", "24-bit meter reads each rail and reference"], ["T4", "Drive the inputs", "Generator + pattern generator push known signals"], ["T5", "Watch the outputs", "Scope for analog, 16-ch logic for digital"], ["T6", "Read the buses", "Decoder turns captures into I²C/SPI/serial traffic"], ["T7", "Verdict", "Proto writes what passed, what failed, where to look"], ["T8", "Loop", "The fix goes into the design; next board the same evening"]];
  t.forEach((r, i) => {
    const col = i % 4, row = Math.floor(i / 4);
    const x = 0.45 + col * 2.28, y = 1.38 + row * 1.12;
    bar(s, x, y, 2.12, i === 6 ? YELLOW : BLUE);
    H(s, r[0], { x, y: y + 0.1, w: 0.45, h: 0.28, fontSize: 12, color: i === 6 ? YELLOW : BLUE });
    H(s, r[1], { x: x + 0.45, y: y + 0.12, w: 1.67, h: 0.25, fontSize: 9 });
    T(s, r[2], { x, y: y + 0.45, w: 2.1, h: 0.6, fontSize: 7.2 });
  });
  tbl(s, [
    ["FUNCTION", "PROTOTYPE", "PRODUCTION", "WHY"],
    ["Capture", "AD9226 12-bit 65 MS/s ×2", "AD9288 dual 8-bit 80 MS/s", "cost"],
    ["Generation", "AN9767 dual 14-bit", "DAC908 8-bit 165 MS/s ×2", "cost"],
    ["FPGA", "Tang Primer 20K Dock", "Tang Nano 9K (GW1NR-9 + 64 Mb PSRAM)", "smaller, cheaper"],
    ["Host", "Pi 5 + 7\" screen", "FT232HL USB 2.0 HS, no screen", "one USB cable"],
    [tt("Unit cost", { bold: true }), tt("₹74,847", { bold: true, color: TEXT }), tt("₹13,740", { bold: true, color: BLUE }), tt("target ₹15,000", { bold: true })],
  ], { x: 0.45, y: 3.72, w: 6.45, colW: [1.1, 1.95, 2.45, 0.95], fontSize: 6.8, rowH: 0.24 }, [5]);
  rect(s, 7.1, 3.72, 2.45, 1.44, PANEL, RULE);
  bar(s, 7.1, 3.72, 2.45, YELLOW);
  T(s, "ALSO OUR PRODUCTION TESTER", { x: 7.22, y: 3.84, w: 2.25, h: 0.18, fontSize: 6.8, color: YELLOW, charSpacing: 1 });
  T(s, "A golden Mixer + our test app tests every Mixer, and every Baker module, on the China line. The factory runs it; we own the limits, software and data.", { x: 7.22, y: 4.08, w: 2.25, h: 1.05, fontSize: 7, color: TEXT });
}

// =================================================================== 15 TIME PER LOOP (new)
{
  const s = slide("Time per loop, told honestly", "About two hours on Baker; 15–20 minutes of it yours", { th: 0.45 });
  const labels = ["Load + probe", "Mill", "Drill", "Clean", "Mask coat", "UV image", "Develop + dry", "Flood cure", "Laser stencil", "Paste + release", "Place (you)", "Reflow + cool", "Test on Mixer"];
  s.addChart(pres.charts.BAR, [
    { name: "low (min)", labels, values: [5, 25, 5, 2, 3, 2, 4, 5, 5, 3, 7, 10, 5] },
    { name: "high (min)", labels, values: [5, 45, 10, 2, 5, 4, 6, 10, 10, 3, 14, 12, 15] },
  ], {
    x: 0.3, y: 1.3, w: 4.6, h: 3.8, barDir: "bar", barGrouping: "clustered", chartColors: [DIM, COPPER],
    catAxisLabelColor: BODY, valAxisLabelColor: MUTED, catAxisLabelFontSize: 6.5, valAxisLabelFontSize: 6.5, catAxisLabelFontFace: MONO, valAxisLabelFontFace: MONO,
    valGridLine: { color: RULE, size: 0.5 }, catGridLine: { style: "none" }, catAxisOrientation: "maxMin", catAxisLineColor: RULE, valAxisLineColor: RULE,
    showLegend: true, legendPos: "b", legendFontSize: 6.5, legendFontFace: MONO, legendColor: BODY, showValue: true, dataLabelFontSize: 5.5, dataLabelColor: BODY, dataLabelFontFace: MONO,
  });
  [["81–141 min", "per board, end to end", COPPER], ["15–20 min", "hands-on: load, place, hook up", YELLOW]].forEach((x, i) => {
    const xx = 5.15 + i * 2.25;
    bar(s, xx, 1.38, 2.1, x[2]);
    H(s, x[0], { x: xx, y: 1.48, w: 2.1, h: 0.38, fontSize: 17, color: x[2] });
    T(s, x[1], { x: xx, y: 1.86, w: 2.1, h: 0.2, fontSize: 7 });
  });
  tbl(s, [
    ["", "USUAL LOOP", "BAKER + MIXER"],
    ["Fabrication", "outside fab, shipped", "steps 01–12, on the bench"],
    ["Stencil", "ordered, aligned by hand", "cut in place, same frame"],
    ["Placement", "tweezers or a service", "printed jig + vacuum pen"],
    ["Test", "scope, supply, DMM, LA", "Mixer: one cable"],
    ["Diagnosis", "engineer reads raw traces", "Proto, in plain words"],
    ["Next attempt", "about two weeks later", tt("the same evening", { color: YELLOW, bold: true })],
  ], { x: 5.15, y: 2.3, w: 4.4, colW: [1.1, 1.6, 1.7], fontSize: 7, rowH: 0.3 });
  T(s, "Engineering targets for a 100 × 160 mm board with ~40 parts; the jig prints in parallel. 3–5 boards per 8-hour shift. The proof of concept measures the real numbers.", { x: 5.15, y: 4.55, w: 4.4, h: 0.55, fontSize: 6.8, color: MUTED });
  s.addNotes("Replaces 'send the design at night, pick it up in the morning' (Prateek: too aggressive). You load boards and place parts; we say so and give the minutes.");
}

// =================================================================== 16 NEW CATEGORY (founder's, edited)
{
  const s = slide("A new category", "Between the DIY bench and\nindustrial manufacturing");
  const xs = [0.45, 2.1, 4.6, 7.05], cw = [1.6, 2.4, 2.45, 2.5];
  rect(s, xs[2], 1.9, cw[2], 3.08, HICOL, YELLOW, 1.25);
  rect(s, xs[2], 1.9, cw[2], 0.62, YELLOW);
  H(s, "DIY bench", { x: xs[1], y: 1.95, w: cw[1], h: 0.28, fontSize: 13 });
  T(s, "breadboards, hand etching, borrowed scopes", { x: xs[1], y: 2.22, w: cw[1] - 0.1, h: 0.28, fontSize: 7, color: MUTED });
  H(s, "protopus", { x: xs[2] + 0.12, y: 1.97, w: cw[2], h: 0.28, fontSize: 13, color: ONYEL });
  T(s, "proto + baker + mixer", { x: xs[2] + 0.12, y: 2.25, w: cw[2], h: 0.2, fontSize: 7, color: ONYEL });
  H(s, "industrial", { x: xs[3] + 0.1, y: 1.95, w: cw[3], h: 0.28, fontSize: 13 });
  T(s, "fab house, assembly house, bench", { x: xs[3] + 0.1, y: 2.22, w: cw[3], h: 0.28, fontSize: 7, color: MUTED });
  const rows = [["TIME PER LOOP", "1–3 days", "Same day (≈2 h on Baker)", "1–3 weeks + customs"], ["EXPERTISE", "A seasoned engineer", "Proto guides you", "Expert to design and test"], ["ASSEMBLED", "By hand, if you can", "Baker pastes + reflows; you drop parts into a jig", "Yes, at extra cost"], ["TESTED", "Only if you own a bench", "Yes, by Mixer", "Separate ₹ lakhs of instruments"], ["BEST FOR", "one-off hacks", "the first 1–10 boards of a design", "100+ identical boards"]];
  rows.forEach((r, i) => {
    const y = 2.6 + i * 0.47;
    T(s, r[0], { x: xs[0], y, w: cw[0], h: 0.42, fontSize: 7, color: MUTED, valign: "middle", charSpacing: 1 });
    T(s, r[1], { x: xs[1], y, w: cw[1] - 0.1, h: 0.42, fontSize: 8.5, valign: "middle" });
    T(s, r[2], { x: xs[2] + 0.12, y, w: cw[2] - 0.2, h: 0.42, fontSize: 8.5, color: TEXT, bold: true, valign: "middle" });
    T(s, r[3], { x: xs[3] + 0.1, y, w: cw[3] - 0.1, h: 0.42, fontSize: 8.5, valign: "middle" });
    if (i < rows.length - 1) { line(s, xs[0], y + 0.46, xs[2] - xs[0], 0); line(s, xs[3], y + 0.46, cw[3], 0); }
  });
  H(s, [{ text: "The DIY bench needs an expert. The factory needs time and money. " }, { text: "Most ideas have neither.", options: { color: YELLOW } }], { x: 0.45, y: 5.08, w: 9.1, h: 0.35, fontSize: 11.5 });
}

// =================================================================== 17 COMPETITION (founder's, updated)
{
  const s = slide("Competition", "Others solve one step.\nNobody closes the whole loop.");
  const cols = [["PRODUCT", 0.45, 3.1], ["PRICE · ₹", 3.55, 2.1], ["MAKE", 5.75, 0.9], ["ASSEMBLE", 6.7, 0.95], ["TEST", 7.7, 0.9], ["GUIDE", 8.6, 0.95]];
  cols.forEach((c) => T(s, c[0], { x: c[1], y: 1.86, w: c[2], h: 0.2, fontSize: 7.5, color: MUTED, align: c[1] > 5 ? "center" : "left", charSpacing: 1 }));
  line(s, 0.45, 2.1, 9.1, 0, TEXT, 0.75);
  const rows = [["Voltera V-One", "~3.1 lakh", [1, 1, 0, 0]], ["LPKF ProtoMat", "8.6–24.5 lakh", [1, 0, 0, 0]], ["Makera Carvera", "~5.1 lakh", [1, 0, 0, 0]], ["Bantam Tools mill · discontinued", "~3.1 lakh", [1, 0, 0, 0]], ["Neoden YY1 pick-and-place", "<2.6 lakh", [0, 1, 0, 0]], ["Digilent Analog Discovery 3", "~33,000", [0, 0, 1, 0]], ["JLCPCB, PCBWay", "per order, weeks", [1, 1, 0, 0]], ["Flux (AI design)", "1.3–4.3k / month", [0, 0, 0, 1]]];
  rows.forEach((r, i) => {
    const y = 2.15 + i * 0.32;
    H(s, r[0], { x: 0.45, y, w: 3.1, h: 0.3, fontSize: 9, valign: "middle" });
    T(s, r[1], { x: 3.55, y, w: 2.1, h: 0.3, fontSize: 8.5, valign: "middle" });
    r[2].forEach((f, k) => dot(s, cols[k + 2][1] + cols[k + 2][2] / 2 - 0.055, y + 0.1, !!f));
    line(s, 0.45, y + 0.31, 9.1, 0);
  });
  const y = 2.15 + rows.length * 0.32 + 0.05;
  rect(s, 0.45, y, 9.1, 0.38, YELLOW);
  H(s, "protopus proto + baker + mixer", { x: 0.57, y, w: 3.0, h: 0.38, fontSize: 9, color: ONYEL, valign: "middle" });
  H(s, "3.34 lakh", { x: 3.55, y, w: 2.1, h: 0.38, fontSize: 9.5, color: ONYEL, valign: "middle" });
  [0, 1, 2, 3].forEach((k) => dot(s, cols[k + 2][1] + cols[k + 2][2] / 2 - 0.055, y + 0.135, true, ONYEL, ONYEL));
  T(s, "List prices at ₹88 per US$, before import duty. ASSEMBLE = paste + reflow or placement. Bantam Tools has stopped selling its PCB mill. Flux guides design and stops at the file.", { x: 0.45, y: y + 0.45, w: 6.1, h: 0.35, fontSize: 6.5, color: MUTED });
  T(s, "voltera.io · Design World · Makera · ToolGuyd · EEVblog · Digilent · flux.ai", { x: 6.6, y: y + 0.45, w: 2.95, h: 0.35, fontSize: 6.5, color: MUTED, align: "right" });
  s.addNotes("Column PLACE became ASSEMBLE: we also place parts by hand, into a jig, so the old knock on Voltera no longer holds. Added Carvera, Neoden, Flux and Bantam's exit.");
}

// =================================================================== 18 BUILT FOR PROTOTYPES (new)
{
  const s = slide("Built for prototypes", "Not a desktop mill, not a factory.\nWhere a fab wins, we say so.");
  T(s, "BOARDS A YEAR → RIGHT TOOL", { x: 0.45, y: 1.88, w: 4.5, h: 0.2, fontSize: 7.5, color: MUTED, charSpacing: 1 });
  line(s, 0.45, 2.1, 4.6, 0, TEXT);
  [["10", "baker", "same-day loops beat fab minimums", COPPER], ["100", "baker", "one machine covers a busy lab", COPPER], ["1,000", "2 bakers + a fab", "any batch of 10+ identical boards → fab", TEXT], ["10,000", "fab / EMS", "production; Proto exports checked files", BLUE], ["1,00,000", "fab / EMS", "not what Baker is for", BLUE]].forEach((r, i) => {
    const y = 2.15 + i * 0.52;
    H(s, r[0], { x: 0.45, y, w: 1.1, h: 0.45, fontSize: 14, color: TEXT, valign: "middle" });
    H(s, r[1], { x: 1.6, y: y + 0.03, w: 3.4, h: 0.2, fontSize: 9, color: r[3] });
    T(s, r[2], { x: 1.6, y: y + 0.24, w: 3.4, h: 0.2, fontSize: 7.2 });
    line(s, 0.45, y + 0.5, 4.6, 0);
  });
  T(s, "One Baker: 3–5 boards per shift, 750–1,250 a year. We scale by the number of labs, not boards per machine.", { x: 0.45, y: 4.85, w: 4.6, h: 0.4, fontSize: 7, color: MUTED });
  rect(s, 5.35, 1.88, 4.2, 3.35, PANEL, RULE);
  bar(s, 5.35, 1.88, 4.2, COPPER);
  T(s, "DESKTOP PCB MACHINES: A ROUGH HISTORY", { x: 5.5, y: 2.0, w: 4, h: 0.2, fontSize: 7.2, color: COPPER, charSpacing: 1 });
  [["Othermill → Bantam", "PCB mill dropped; now sells art machines"], ["Voltera V-One", "out of stock; moved up to NOVA ($45,974)"], ["BotFactory", "Squink $3,199–4,499; SV2 now on request"], ["Nano Dimension", "sold its electronics unit, Apr 2026, $2M cash"]].forEach((r, i) => {
    const y = 2.3 + i * 0.36;
    H(s, r[0], { x: 5.5, y, w: 1.6, h: 0.3, fontSize: 8, valign: "middle" });
    T(s, r[1], { x: 7.1, y, w: 2.35, h: 0.3, fontSize: 6.8, valign: "middle" });
  });
  line(s, 5.5, 3.78, 3.9, 0);
  T(s, "WHY, AND OUR ANSWER", { x: 5.5, y: 3.86, w: 4, h: 0.18, fontSize: 7, color: YELLOW, charSpacing: 1 });
  T(s, [
    { text: "one step automated → ", options: { color: BODY } }, { text: "the whole loop, mill to verdict", options: { color: TEXT, breakLine: true } },
    { text: "fought $2 boards on price → ", options: { color: BODY } }, { text: "we sell hours per loop", options: { color: TEXT, breakLine: true } },
    { text: "a tool for experts → ", options: { color: BODY } }, { text: "an outcome for non-experts", options: { color: TEXT, breakLine: true } },
    { text: "no software → ", options: { color: BODY } }, { text: "Proto + run data are the moat", options: { color: TEXT } },
  ], { x: 5.5, y: 4.1, w: 4, h: 1.05, fontSize: 7.2, lineSpacingMultiple: 1.25 });
  s.addNotes("Prateek: don't pitch a desktop PCB mill, and 'will it scale to 1,000 / 10,000 / 1 lakh boards?'. Answer: it's a prototyping cell for iterations 1–10; volume goes to a fab.");
}

// =================================================================== 19 BUSINESS MODEL (founder's)
{
  const s = slide("Business model · projected", "What we aim for: sell the machines, and\none Proto plan runs all of them");
  const rows = [["Hardware (target)", "1,50,000", "15,000"], ["Assembly and QC", "12,000", "2,000"], ["Packing and shipping", "8,000", "1,000"], ["Warranty reserve", "7,500", "750"], ["Software share", "10,000", "2,000"], ["Sales and support", "12,500", "1,750"]];
  T(s, "PROJECTED PER UNIT · ₹", { x: 0.45, y: 1.78, w: 2.6, h: 0.18, fontSize: 7.2, color: MUTED, charSpacing: 1 });
  T(s, "BAKER", { x: 2.95, y: 1.78, w: 1.05, h: 0.18, fontSize: 7.2, color: COPPER, align: "right", charSpacing: 1 });
  T(s, "MIXER", { x: 4.05, y: 1.78, w: 0.8, h: 0.18, fontSize: 7.2, color: BLUE, align: "right", charSpacing: 1 });
  line(s, 0.45, 1.99, 4.4, 0, TEXT);
  rows.forEach((r, i) => {
    const y = 2.02 + i * 0.21;
    T(s, r[0], { x: 0.45, y, w: 2.4, h: 0.2, fontSize: 8, valign: "middle" });
    T(s, r[1], { x: 2.95, y, w: 1.05, h: 0.2, fontSize: 8, color: TEXT, align: "right", valign: "middle" });
    T(s, r[2], { x: 4.05, y, w: 0.8, h: 0.2, fontSize: 8, color: TEXT, align: "right", valign: "middle" });
    line(s, 0.45, y + 0.205, 4.4, 0, i === rows.length - 1 ? TEXT : RULE);
  });
  let y = 3.3;
  H(s, "Projected total cost", { x: 0.45, y, w: 2.5, h: 0.22, fontSize: 8.5, valign: "middle" });
  H(s, "2,00,000", { x: 2.95, y, w: 1.05, h: 0.22, fontSize: 8.5, align: "right", valign: "middle" });
  H(s, "22,500", { x: 4.05, y, w: 0.8, h: 0.22, fontSize: 8.5, align: "right", valign: "middle" });
  y = 3.56;
  rect(s, 0.45, y, 4.4, 0.3, TEXT);
  H(s, "Target selling price", { x: 0.55, y, w: 2.3, h: 0.3, fontSize: 9, color: BG, valign: "middle" });
  H(s, "2,99,000", { x: 2.95, y, w: 1.05, h: 0.3, fontSize: 9, color: BG, align: "right", valign: "middle" });
  H(s, "34,999", { x: 4.05, y, w: 0.75, h: 0.3, fontSize: 9, color: BG, align: "right", valign: "middle" });
  H(s, "Projected margin", { x: 0.55, y: 3.9, w: 2.3, h: 0.22, fontSize: 8, valign: "middle" });
  T(s, "~33%", { x: 2.95, y: 3.9, w: 1.05, h: 0.22, fontSize: 8, color: COPPER, align: "right", valign: "middle" });
  T(s, "~36%", { x: 4.05, y: 3.9, w: 0.75, h: 0.22, fontSize: 8, color: BLUE, align: "right", valign: "middle" });
  T(s, "Costed model: Baker ₹1,44,842, Mixer ₹13,740 incl. assembly.", { x: 0.45, y: 4.16, w: 4.4, h: 0.18, fontSize: 6.5, color: MUTED });
  rect(s, 5.1, 1.78, 4.45, 1.12, YELLOW);
  T(s, "PLANNED · ONE PROTO PLAN · EVERY MACHINE", { x: 5.24, y: 1.86, w: 4.2, h: 0.18, fontSize: 7, bold: true, color: ONYEL, charSpacing: 1 });
  T(s, [{ text: "₹9,999", options: { fontFace: HEAD, bold: true, fontSize: 20 } }, { text: " / year", options: { fontSize: 9, bold: true } }], { x: 5.24, y: 2.07, w: 4.2, h: 0.4, color: ONYEL, valign: "bottom" });
  T(s, "One subscription per workspace: Baker Studio, Mixer Station, Proto and every update.", { x: 5.24, y: 2.5, w: 4.2, h: 0.35, fontSize: 7.5, color: ONYEL });
  bar(s, 5.1, 3.0, 4.45, BLUE);
  H(s, "Consumables", { x: 5.1, y: 3.08, w: 4, h: 0.22, fontSize: 9.5 });
  T(s, "Board blanks, mask, paste, film, jig resin and end mills: ≈₹334 of material per board, reordered as labs keep building.", { x: 5.1, y: 3.32, w: 4.45, h: 0.4, fontSize: 7.2 });
  bar(s, 5.1, 3.78, 4.45, COPPER);
  H(s, "Industrial variants, later", { x: 5.1, y: 3.86, w: 4, h: 0.22, fontSize: 9.5 });
  T(s, "Bigger beds, multilayer and production test come after the base machines.", { x: 5.1, y: 4.1, w: 4.45, h: 0.3, fontSize: 7.2 });
  T(s, "ROADMAP TO THESE NUMBERS", { x: 0.45, y: 4.45, w: 4, h: 0.18, fontSize: 7, color: COPPER, charSpacing: 1 });
  [["NOW", "Prototypes costed: Baker ₹3.73L, Mixer ₹74,847", COPPER], ["MONTHS 0–9 · THIS ASK", "₹16L proof of concept: Baker Rev B, 5 Mixers in studios", YELLOW], ["AFTER POC · SEED", "~₹1.5 Cr: China pilots, first 100 Mixers + 20 Bakers", BLUE], ["100-UNIT BATCHES", "The projected unit economics above", GREEN]].forEach((r, i) => {
    const x = 0.45 + i * 2.28;
    bar(s, x, 4.68, 2.15, r[2], 0.03);
    T(s, r[0], { x, y: 4.76, w: 2.15, h: 0.17, fontSize: 6.5, color: r[2], charSpacing: 1 });
    T(s, r[1], { x, y: 4.95, w: 2.15, h: 0.4, fontSize: 7, color: TEXT });
  });
}

// =================================================================== 20 PAYBACK (new)
{
  const s = slide("Does it pay for itself?", "After about 53 boards, before counting\nthe two weeks each loop saves");
  [["₹334", "Baker consumables per board", TEXT], ["₹6,721", "the same assembled board from JLCPCB, landed in India", TEXT], ["53", "boards to recover ₹3,33,999 (Baker + Mixer)", YELLOW]].forEach((x, i) => {
    const xx = 0.45 + i * 3.08;
    bar(s, xx, 1.9, 2.9, i === 2 ? YELLOW : DIM);
    H(s, x[0], { x: xx, y: 2.0, w: 2.9, h: 0.55, fontSize: 28, color: x[2] });
    T(s, x[1], { x: xx, y: 2.58, w: 2.85, h: 0.4, fontSize: 8 });
  });
  tbl(s, [
    ["COMPARED WITH", "SAVING / BOARD", "BREAK-EVEN", "STARTUP · 2 / WEEK", "LAB · 1 / WEEK"],
    ["JLCPCB → India, 7–20 days", "₹6,387", "53 boards", "6.6 months", "13.3 months"],
    ["Indian 24-hour fab, bare boards", "₹5,166", "65 boards", "8.1 months", "16.3 months"],
  ], { x: 0.45, y: 3.2, w: 9.1, colW: [2.9, 1.5, 1.3, 1.7, 1.7], fontSize: 8, rowH: 0.34 });
  T(s, "HOW ₹6,721 IS BUILT", { x: 0.45, y: 4.33, w: 4, h: 0.18, fontSize: 7, color: COPPER, charSpacing: 1 });
  T(s, "5 PCBs $5 · PCBA setup $8 · stencil $1.50 · 200 joints $0.34 · 3 extended parts $9 · DHL $35 → ₹5,178 at ₹88, + 10% BCD and 18% IGST (₹1,543).", { x: 0.45, y: 4.53, w: 4.5, h: 0.6, fontSize: 7 });
  T(s, "WHAT IT LEAVES OUT", { x: 5.2, y: 4.33, w: 4, h: 0.18, fontSize: 7, color: COPPER, charSpacing: 1 });
  T(s, "Components (you buy them either way), engineer hours and the waiting. The Proto plan, ₹9,999 a year, is worth about two boards.", { x: 5.2, y: 4.53, w: 4.35, h: 0.6, fontSize: 7 });
  src(s, "jlcpcb.com PCB/PCBA pricing · zbotic.in (DHL $25–45, 10% BCD + 18% IGST, 7–20 days door to door; Indian 24-h fab ₹3,000–8,000 for 5) · consumables from the BOM listings.");
  s.addNotes("Prateek's 'say X lakh, does it cancel my cost?'. At ₹3.34 lakh the pair pays back after ~53 boards against JLCPCB: about 6.6 months for a startup iterating twice a week.");
}

// =================================================================== 21 MARKET (founder's)
{
  const s = slide("Market plan / growth strategy", "Start in the maker studios, then\nfollow the people who watch them");
  const st = [["₹6.4L cr", "global PCB market", TEXT], ["₹3.1L cr", "global test and measurement", TEXT], ["₹55K cr", "India PCB, ~15% a year", COPPER], ["₹8.3K cr", "India test and measurement", COPPER], ["33M+", "active Arduino users worldwide", BLUE], ["2.3M+", "Hackster hardware community", BLUE], ["10,000", "Atal Tinkering Labs, 50,000 more planned", YELLOW], ["~2,500", "Fab Labs in 125 countries", YELLOW]];
  line(s, 0.45, 1.9, 9.1, 0);
  st.forEach((x, i) => {
    const col = i % 4, row = Math.floor(i / 4), xx = 0.45 + col * 2.28, y = 2.0 + row * 0.8;
    if (col) line(s, xx - 0.1, y - 0.1, 0, 0.8);
    H(s, x[0], { x: xx, y, w: 2.15, h: 0.38, fontSize: 18, color: x[2] });
    T(s, x[1], { x: xx, y: y + 0.4, w: 2.1, h: 0.32, fontSize: 7.5 });
  });
  line(s, 0.45, 2.7, 9.1, 0);
  line(s, 0.45, 3.5, 9.1, 0);
  [["NOW", "Maker studios", "Free Baker and Mixer units, with a contract for featured videos. The Bambu Lab playbook.", YELLOW], ["NEXT", "Hobbyists and startups", "The people who watch those videos and lose weeks on every board.", BLUE], ["ALONGSIDE", "Prototyping labs", "Tinkering labs, Fab Labs and college labs that already buy tools.", COPPER]].forEach((c, i) => {
    const x = 0.45 + i * 3.08;
    bar(s, x, 3.65, 2.9, c[3]);
    T(s, c[0], { x, y: 3.77, w: 2.9, h: 0.18, fontSize: 7.5, color: c[3], charSpacing: 2 });
    H(s, c[1], { x, y: 3.98, w: 2.9, h: 0.25, fontSize: 10 });
    T(s, c[2], { x, y: 4.25, w: 2.85, h: 0.6, fontSize: 7.5 });
  });
  src(s, "IMARC · Grand View · Arduino · Hackster · Atal Innovation Mission · Forbes · at ₹88 per US$. Bottom-up, India only: 5,868 AICTE colleges × ₹3.34 lakh ≈ ₹196 Cr of hardware.", 5.05);
}

// =================================================================== 22 PROGRESS (founder's)
{
  const s = slide("Current progress / achievements & timeline", "Where we are, told honestly", { th: 0.45 });
  [["Baker", "Raw prototype running on the bench. The video.", COPPER, TEXT], ["Software", "Baker Studio with Proto inside. Website live.", YELLOW, TEXT], ["Mixer", "Idea phase. Architecture and BOM defined, not built.", DIM, BODY]].forEach((c, i) => {
    const x = 0.45 + i * 3.1;
    bar(s, x, 1.4, 2.9, c[2]);
    H(s, c[0], { x, y: 1.55, w: 2.9, h: 0.4, fontSize: 20, color: c[3] });
    T(s, c[1], { x, y: 2.0, w: 2.85, h: 0.5, fontSize: 8.5 });
  });
  rect(s, 0.45, 2.75, 9.1, 0.7, PANEL, RULE);
  pill(s, "SIGNAL", 0.65, 2.98, 0.72);
  T(s, [{ text: "Met " }, { text: "Samuel Beek", options: { bold: true } }, { text: ", Founder & CEO of Schematik. Interested in funding us once the proof of concept is ready." }], { x: 1.55, y: 2.8, w: 7.85, h: 0.6, fontSize: 9.5, color: TEXT, valign: "middle" });
  line(s, 0.45, 3.68, 9.1, 0, TEXT);
  [["MONTH 0–2", "Baker runs all 15 steps on a real board", COPPER], ["MONTH 2–4", "First Mixer built and measuring", COPPER], ["MONTH 4–6", "Proof of concept, first maker-studio units", BLUE], ["AFTER POC", "Next round, first sales", BLUE]].forEach((c, i) => {
    const x = 0.45 + i * 2.28;
    if (i) line(s, x - 0.12, 3.68, 0, 1.35);
    T(s, c[0], { x, y: 3.85, w: 2.1, h: 0.2, fontSize: 8.5, color: c[2], charSpacing: 2 });
    H(s, c[1], { x, y: 4.12, w: 2.1, h: 0.8, fontSize: 10.5 });
  });
}

// =================================================================== 23 WHAT THE MONEY PROVES (founder's)
{
  const s = slide("What the money proves", "Our goal: a working proof of concept,\none milestone you can watch at a time");
  line(s, 0.45, 1.98, 9.1, 0, TEXT, 0.75);
  const m = [["MONTH 2", "Baker runs all 15 steps", "Blank FR4 to a reflowed board, on video.", COPPER], ["MONTH 3", "Process proven", "PR-001…004: mask, film, jig and laser pass written tests.", COPPER], ["MONTH 4", "Mixer measures", "All 8 instruments checked against reference gear.", BLUE], ["MONTH 5", "Rev B + Mixer boards", "Baker Rev B built; 5 production Mixers pass test.", BLUE], ["MONTH 6", "Proof of concept", "20 boards file-to-tested; Mixers in maker studios.", YELLOW], ["MONTHS 7–9", "Next round", "Seed raised on the proof; China quotes out.", GREEN]];
  m.forEach((r, i) => {
    const x = 0.45 + i * 1.53;
    dot(s, x, 1.93, true, r[3], r[3], 0.1);
    if (i) line(s, x - 0.08, 2.18, 0, 1.75);
    T(s, r[0], { x, y: 2.18, w: 1.45, h: 0.18, fontSize: 7.2, color: r[3], charSpacing: 1 });
    H(s, r[1], { x, y: 2.4, w: 1.42, h: 0.42, fontSize: 9 });
    T(s, r[2], { x, y: 2.85, w: 1.42, h: 1.0, fontSize: 7.2 });
  });
  rect(s, 0.45, 4.05, 9.1, 0.8, PANEL);
  [["₹16 lakh", "the whole ask", YELLOW], ["9 months", "6 to proof + 3 to raise", TEXT], ["1 + 1", "founder + a software engineer who writes firmware", TEXT], ["Every month", "a demo video + Mixer test logs", TEXT]].forEach((k, i) => {
    const x = 0.62 + i * 2.28;
    H(s, k[0], { x, y: 4.13, w: 2.1, h: 0.32, fontSize: 14, color: k[2] });
    T(s, k[1], { x, y: 4.45, w: 2.05, h: 0.38, fontSize: 7 });
  });
  H(s, "Built in the university lab, tested with students and makers.", { x: 0.45, y: 5.0, w: 9.1, h: 0.3, fontSize: 11 });
}

// =================================================================== 24 OPEN POINTS (new)
{
  const s = slide("What could still break", "Four open points, each written as a pass/fail test", { th: 0.45 });
  tbl(s, [
    ["ID", "OPEN POINT", "TEST ON THE PROTOTYPE", "PASS", "FALLBACK"],
    [tt("PR-001", { color: COPPER }), "Wipe-develop cleanliness, 0.5 mm-pitch pads", "0.5 mm footprint; inspect every pad after step 09", "no mask left on any pad", "skim pads with the spindle"],
    [tt("PR-002", { color: COPPER }), "Film registration after magnetic clamping", "measure film-to-copper offset at fiducials", "±50 µm at every fiducial", "clamp sequence / frame stiffness"],
    [tt("PR-003", { color: COPPER }), "Jig-to-pin accuracy after resin shrink", "post-cure jig; pockets vs pin datum", "parts land on pads", "scale compensation in the jig"],
    [tt("PR-004", { color: COPPER }), "Laser offset drift with temperature", "fiducial check, cold start and after a long job", "inside the stencil budget", "re-check every job (planned)"],
  ], { x: 0.45, y: 1.38, w: 9.1, colW: [0.75, 2.35, 2.55, 1.55, 1.9], fontSize: 7.3, rowH: 0.42 });
  T(s, "WHY THE ORDER IS THE DESIGN", { x: 0.45, y: 3.7, w: 4, h: 0.18, fontSize: 7.2, color: YELLOW, charSpacing: 1 });
  [["mill before mask", "the mask covers clean, finished copper"], ["cure before stencil", "the laser never touches uncured mask"], ["stencil from the same Gerber, same frame", "removes stencil-alignment error"], ["jig prints in parallel", "placement adds no waiting"], ["Sn42Bi58 at 138 °C; jig lifts off", "stays under TR300's 160 °C; less warp"]].forEach((r, i) => {
    const col = i < 3 ? 0 : 1, row = i < 3 ? i : i - 3;
    const x = 0.45 + col * 4.65, y = 3.95 + row * 0.38;
    H(s, r[0], { x, y, w: 4.4, h: 0.17, fontSize: 8 });
    T(s, r[1], { x, y: y + 0.17, w: 4.4, h: 0.17, fontSize: 7, color: MUTED });
  });
  T(s, "Also to close before China: one board size, 100 × 160 (workflow) or 100 × 150 mm (BOM blanks). Plus lab safety: Class 4 laser inside an interlocked enclosure.", { x: 5.1, y: 4.73, w: 4.45, h: 0.5, fontSize: 7, color: TEXT });
}

// =================================================================== 25 FUNDING (founder's, cream)
{
  const s = pres.addSlide(); s.background = { color: CREAM };
  T(s, num() + " · GRANT / FUNDING REQUIRED", { x: 0.45, y: 0.47, w: 9, h: 0.2, fontSize: 8.5, color: BROWN, charSpacing: 2.5 });
  T(s, "₹16,00,000", { x: 0.4, y: 0.9, w: 9, h: 1.05, fontFace: MONO, bold: true, fontSize: 66, color: BROWN });
  H(s, "sixteen lakh: nine months to a proof of concept, and time to raise.", { x: 0.45, y: 2.05, w: 9, h: 0.3, fontFace: MONO, fontSize: 11.5, color: CBLACK });
  [["₹4.48L", "Baker + Mixer builds, costed line by line", "₹4,48,265", BROWN], ["₹2.20L", "Baker Rev B, 5 production Mixers, consumables", "₹2,20,000", CBLUE], ["₹4.50L", "One software + firmware engineer, 9 months", "₹4,50,000", CBLACK], ["₹1.35L", "Proto software and compute", "₹1,35,000", MUSTARD], ["₹1.50L", "Testing, tooling, lab safety", "₹1,50,000", TAUPE], ["₹1.97L", "IP, outreach, 6.6% reserve", "₹1,96,735", GREEN]].forEach((c, i) => {
    const x = 0.45 + i * 1.545;
    rect(s, x, 2.62, 1.38, 0.05, c[3]);
    T(s, c[0], { x, y: 2.78, w: 1.4, h: 0.42, fontFace: MONO, bold: true, fontSize: 19, color: CBLACK });
    T(s, c[1], { x, y: 3.25, w: 1.38, h: 0.7, fontSize: 7.5, color: CBLACK });
    T(s, c[2], { x, y: 4.0, w: 1.38, h: 0.18, fontSize: 6.8, color: BROWN });
  });
  line(s, 0.45, 4.55, 9.1, 0, CBLACK, 1);
  T(s, "Enough to survive one failed iteration and raise from strength.", { x: 0.45, y: 4.68, w: 9.1, h: 0.25, fontSize: 9.5, bold: true, color: CBLACK });
  T(s, "This builds the proof. The next round, at proof of concept, builds the business.", { x: 0.45, y: 4.95, w: 9.1, h: 0.25, fontSize: 9, color: CBLACK });
}

// =================================================================== 26 COST BREAKUP (founder's)
{
  const s = slide("Cost breakup", "Where the ₹16 lakh goes, line by line", { th: 0.45 });
  const col = (x, w, head, total, color, rows, foot) => {
    bar(s, x, 1.35, w, color);
    H(s, head, { x, y: 1.43, w: w * 0.55, h: 0.25, fontSize: 10.5 });
    H(s, total, { x: x + w * 0.4, y: 1.43, w: w * 0.6, h: 0.25, fontSize: 10.5, color, align: "right" });
    rows.forEach((r, i) => {
      const y = 1.72 + i * 0.172;
      const strong = r[2];
      T(s, r[0], { x, y, w: w * 0.7, h: 0.165, fontSize: 6.8, color: strong ? TEXT : BODY, bold: !!strong, valign: "middle" });
      T(s, r[1], { x: x + w * 0.6, y, w: w * 0.4, h: 0.165, fontSize: 6.8, color: strong ? TEXT : TEXT, bold: !!strong, align: "right", valign: "middle" });
      line(s, x, y + 0.168, w, 0);
    });
  };
  col(0.45, 2.85, "Baker", "₹3,73,418", COPPER, [["Frame & enclosure", "22,795"], ["Motion", "80,382"], ["Zone A: mill, drill, laser", "38,270"], ["Zone B: mask, UV, wipe", "33,058"], ["Stencil film", "5,805"], ["Placement + reflow", "4,891"], ["Board handling", "300"], ["Electronics & control", "42,985"], ["Resin printer (jigs)", "77,698"], ["First-run consumables", "6,280"], ["Parts", "3,12,465", 1], ["Import duty + courier", "12,247"], ["Contingency (15%)", "48,707"], ["Prototype total", "₹3,73,418", 1]]);
  col(3.6, 2.6, "Mixer", "₹74,847", BLUE, [["Capture + generation", "18,198"], ["Front end + instruments", "15,752"], ["Host, screen, I/O", "26,752"], ["Enclosure", "1,510"], ["Parts", "62,212", 1], ["Import duty + courier", "2,872"], ["Contingency (15%)", "9,763"], ["Prototype total", "₹74,847", 1]]);
  T(s, "PRODUCTION UNIT (PROJECTED)", { x: 3.6, y: 3.2, w: 2.6, h: 0.17, fontSize: 6.8, color: COPPER, charSpacing: 1 });
  H(s, "Baker", { x: 3.6, y: 3.42, w: 1.2, h: 0.2, fontSize: 9 }); H(s, "₹1,44,842", { x: 4.8, y: 3.42, w: 1.4, h: 0.2, fontSize: 9, color: YELLOW, align: "right" });
  T(s, "target ₹1,50,000 · under by ₹5,158", { x: 3.6, y: 3.63, w: 2.6, h: 0.16, fontSize: 6.5, color: MUTED });
  H(s, "Mixer", { x: 3.6, y: 3.85, w: 1.2, h: 0.2, fontSize: 9 }); H(s, "₹13,740", { x: 4.8, y: 3.85, w: 1.4, h: 0.2, fontSize: 9, color: YELLOW, align: "right" });
  T(s, "target ₹15,000 · under by ₹1,260", { x: 3.6, y: 4.06, w: 2.6, h: 0.16, fontSize: 6.5, color: MUTED });
  const uf = [["Baker prototype build", "3,73,418", COPPER], ["Mixer prototype build", "74,847", COPPER], ["Baker Rev B iteration", "1,00,000", BLUE], ["Mixer production board ×5", "60,000", BLUE], ["PoC consumables", "60,000", BLUE], ["Engineer (software + firmware)", "4,50,000", TEXT], ["Proto software + compute", "1,35,000", YELLOW], ["Testing + tooling", "1,00,000", TAUPE], ["Lab set-up + safety", "50,000", TAUPE], ["IP + legal", "75,000", GREEN], ["Demos + studio outreach", "50,000", GREEN], ["Reserve (6.6%)", "71,735", GREEN]];
  bar(s, 6.5, 1.35, 3.05, YELLOW);
  H(s, "Use of funds", { x: 6.5, y: 1.43, w: 1.6, h: 0.25, fontSize: 10.5 });
  H(s, "₹16,00,000", { x: 7.9, y: 1.43, w: 1.65, h: 0.25, fontSize: 10.5, color: YELLOW, align: "right" });
  uf.forEach((r, i) => {
    const y = 1.72 + i * 0.172;
    rect(s, 6.5, y + 0.05, 0.07, 0.07, r[2]);
    T(s, r[0], { x: 6.63, y, w: 2.2, h: 0.165, fontSize: 6.8, valign: "middle" });
    T(s, r[1], { x: 8.6, y, w: 0.95, h: 0.165, fontSize: 6.8, color: TEXT, align: "right", valign: "middle" });
    line(s, 6.5, y + 0.168, 3.05, 0);
  });
  H(s, "Total", { x: 6.63, y: 3.8, w: 1.5, h: 0.2, fontSize: 8 }); H(s, "16,00,000", { x: 8.3, y: 3.8, w: 1.25, h: 0.2, fontSize: 8, color: YELLOW, align: "right" });
  // stacked share bar
  const parts = [["Hardware ₹4.48L", 4.48, COPPER, ONYEL], ["Iteration ₹2.20L", 2.2, BLUE, ONYEL], ["People ₹4.50L", 4.5, TEXT, BG], ["", 1.35, YELLOW, ONYEL], ["", 1.5, TAUPE, ONYEL], ["", 1.97, GREEN, ONYEL]];
  let x = 0.45;
  parts.forEach((p) => { const w = 9.1 * p[1] / 16; rect(s, x, 4.52, w, 0.24, p[2]); if (p[0]) T(s, p[0], { x: x + 0.06, y: 4.52, w: w - 0.06, h: 0.24, fontSize: 6.5, bold: true, color: p[3], valign: "middle" }); x += w; });
  T(s, "People 28% · Hardware 28% · Iteration 14% · IP + reserve 12% · Lab + tooling 9% · Software 8%", { x: 0.45, y: 4.84, w: 9.1, h: 0.18, fontSize: 7 });
  src(s, "Basis: PROTOPUS cost report, 29 Sep 2026: 96 BOM lines, 81 from live listings; USD at ₹88; imports carry 35% duty + courier; 15% contingency.", 5.1);
}

// =================================================================== 27 WHAT'S NEXT (founder's)
{
  const s = slide("What's next", "After proof of concept: raise, build in China,\nrun lean from Delhi");
  const cols = [
    ["THE ROUND", "~₹1.5 crore seed,\nat proof of concept", COPPER],
    ["THE CHINA PLAN", "Design in Delhi,\nbuild in Shenzhen", YELLOW],
    ["OPERATIONS", "Delhi finalises,\nit doesn't build", BLUE],
  ];
  cols.forEach((c, i) => {
    const x = 0.45 + i * 3.1;
    bar(s, x, 1.88, 2.9, c[2]);
    T(s, c[0], { x, y: 1.98, w: 2.9, h: 0.18, fontSize: 7, color: MUTED, charSpacing: 1.5 });
    H(s, c[1], { x, y: 2.18, w: 2.9, h: 0.5, fontSize: 11.5 });
  });
  [["China pilots + first batches", "₹70L"], ["China set-up, IP", "₹25L"], ["Team of 5, 12 months", "₹25L"], ["Delhi centre + capital", "₹20L"], ["Buffer", "₹10L"]].forEach((r, i) => {
    const y = 2.8 + i * 0.2;
    T(s, r[0], { x: 0.45, y, w: 2.2, h: 0.19, fontSize: 7.2, valign: "middle" });
    T(s, r[1], { x: 2.6, y, w: 0.75, h: 0.19, fontSize: 7.2, bold: true, color: TEXT, align: "right", valign: "middle" });
    line(s, 0.45, y + 0.195, 2.9, 0);
  });
  H(s, "Seed round", { x: 0.45, y: 3.82, w: 2, h: 0.2, fontSize: 8 }); H(s, "₹1.5 Cr", { x: 2.4, y: 3.82, w: 0.95, h: 0.2, fontSize: 8, color: COPPER, align: "right" });
  T(s, "Pilot batches are sellable (≈₹95L at list). Schematik interested at PoC.", { x: 0.45, y: 4.07, w: 2.9, h: 0.35, fontSize: 6.8, color: MUTED });
  const sq = (x, items, color) => items.forEach((t, i) => { rect(s, x, 2.86 + i * 0.36, 0.06, 0.06, color); T(s, t, { x: x + 0.14, y: 2.8 + i * 0.36, w: 2.75, h: 0.34, fontSize: 7.2 }); });
  sq(3.55, ["Mixer: full turnkey from batch one.", "Baker: China modules, final build in Delhi; turnkey once ≤ $1,305 ex-works.", "12 factories quoted → 2 pilots → 1 primary + backup.", "Pilots: 20/50/100 Mixers, 3/5/20 Bakers."], YELLOW);
  sq(6.65, ["Every unit: scan, test, activate Proto, ship.", "Mixer is our production tester: our rig, limits, data.", "Hire: a mechanical + a manufacturing/quality engineer.", "IEC, customs broker, China trademarks first."], BLUE);
  line(s, 0.45, 4.48, 9.1, 0, TEXT);
  [["MONTH 0–2", "Design freeze, 12 RFQs out", COPPER], ["MONTH 3–5", "Pilots in China: EVT and DVT", COPPER], ["MONTH 6–9", "PVT: first 100 Mixers, 20 Bakers", BLUE], ["MONTH 10–12", "Mass production, first container", BLUE]].forEach((r, i) => {
    const x = 0.45 + i * 2.28;
    if (i) line(s, x - 0.12, 4.48, 0, 0.72);
    T(s, r[0], { x, y: 4.58, w: 2.1, h: 0.17, fontSize: 7.2, color: r[2], charSpacing: 1 });
    H(s, r[1], { x, y: 4.78, w: 2.1, h: 0.4, fontSize: 8.5 });
  });
  src(s, "Months counted from the round. Round sizing is indicative; pilots costed from the BOM.", 5.25);
}

// =================================================================== 28 CHINA LINE (new)
{
  const s = slide("China assembly line · station by station", "Two kinds of factory, one test system we own", { th: 0.45 });
  const chips = (y, label, items, color, sub) => {
    T(s, label, { x: 0.45, y: y - 0.02, w: 9.1, h: 0.18, fontSize: 7, color, charSpacing: 1 });
    const w = (9.1 - (items.length - 1) * 0.05) / items.length;
    items.forEach((it, i) => {
      const x = 0.45 + i * (w + 0.05);
      rect(s, x, y + 0.2, w, 0.6, BG, it[2] || color);
      T(s, it[0], { x, y: y + 0.24, w, h: 0.17, fontSize: 7, bold: true, color: it[2] || color, align: "center" });
      T(s, it[1], { x: x + 0.02, y: y + 0.42, w: w - 0.04, h: 0.36, fontSize: 6.2, color: BODY, align: "center" });
    });
  };
  chips(1.33, "MIXER LINE · FULL TURNKEY EMS, FROM BATCH ONE", [["M1", "IQC"], ["M2", "SMT + AOI"], ["M3", "THT"], ["M4", "program"], ["M5", "PCBA FCT"], ["M6", "box build"], ["M7", "calibrate"], ["M8", "8-instr test"], ["M9", "serialise"], ["M10", "pack"], ["M11", "OQC"], ["M12", "ship FOB"]], BLUE);
  chips(2.2, "BAKER LINE · STAGE 1: TESTED MODULES (SKD) IN CHINA, INTEGRATION IN DELHI", [["B1", "IQC"], ["B2", "frame"], ["B3", "motion"], ["B4", "zone A head"], ["B5", "zone B head"], ["B6", "stencil module"], ["B7", "control box"], ["B8", "module test (Mixer rig)"], ["B9", "kit + crate"], ["D1", "Delhi: integrate", YELLOW], ["D2", "Delhi: calibrate", YELLOW], ["D3", "Delhi: make-a-PCB", YELLOW]], COPPER);
  chips(3.07, "INDIA FINALISATION CENTRE · NOT A SECOND FACTORY", [["I1", "receive + scan"], ["I2", "quarantine"], ["I3", "power-on FCT"], ["I4", "calibration check"], ["I5", "activate Proto licence"], ["I6", "accept → stock"]], YELLOW);
  rect(s, 0.45, 4.0, 4.45, 1.12, PANEL, RULE);
  bar(s, 0.45, 4.0, 4.45, BLUE);
  T(s, "WE OWN THE TEST SYSTEM", { x: 0.6, y: 4.1, w: 4.2, h: 0.17, fontSize: 7, color: BLUE, charSpacing: 1 });
  T(s, "Golden Mixer + our test app: scan serial → run sequence → PASS/FAIL per step → upload. Operators can't edit limits. One record per serial (PTP-MXR-2027-000173): lots, firmware hash, calibration, every value.", { x: 0.6, y: 4.32, w: 4.2, h: 0.78, fontSize: 6.8, color: TEXT });
  rect(s, 5.1, 4.0, 4.45, 1.12, PANEL, RULE);
  bar(s, 5.1, 4.0, 4.45, COPPER);
  T(s, "IP BY ARCHITECTURE", { x: 5.25, y: 4.1, w: 4.2, h: 0.17, fontSize: 7, color: COPPER, charSpacing: 1 });
  T(s, "The factory flashes a locked image; Proto activation and calibration logic stay with us. NNN in Chinese under PRC law, tooling is ours, no overruns, no substitution without a signed ECN.", { x: 5.25, y: 4.32, w: 4.2, h: 0.78, fontSize: 6.8, color: TEXT });
  src(s, "Source: PROTOPUS China assembly line master plan (29 Sep 2026), §7, §10, §14, §17.", 5.22);
}

// =================================================================== 29 LANDED COST + GATES (new)
{
  const s = slide("China · when turnkey wins", "Price the landed cost, not the factory quote", { th: 0.45 });
  const lc = (x, name, color, rows, verdict) => {
    bar(s, x, 1.38, 4.45, color);
    H(s, name, { x, y: 1.46, w: 4.4, h: 0.26, fontSize: 11, color });
    tbl(s, rows, { x, y: 1.78, w: 4.45, colW: [1.35, 1.45, 1.65], fontSize: 6.8, rowH: 0.24 }, [5]);
    rect(s, x, 3.3, 4.45, 0.42, YELLOW);
    T(s, verdict, { x: x + 0.1, y: 3.3, w: 4.25, h: 0.42, fontSize: 7, bold: true, color: ONYEL, valign: "middle" });
  };
  lc(0.45, "Baker", COPPER, [["LINE", "TODAY (REPORT)", "CHINA TURNKEY"], ["Parts", "₹1,14,547 ($1,302)", "inside the ex-works price"], ["Duty", "₹14,775 (16.5%)", "16.5% × EXW (HS to confirm)"], ["Freight", "₹3,520 LCL share", "≈₹8,000 crated machine"], ["India labour", "₹12,000", "≈₹3,000 acceptance"], ["Landed", "₹1,44,842", "EXW × 1.165 + 11,000"]], "Break-even EXW ≤ $1,305 (≤ $1,356 at the ₹1.5L target) vs $1,302 of parts → start SKD; turnkey when quotes prove it.");
  lc(5.1, "Mixer", BLUE, [["LINE", "TODAY (REPORT)", "CHINA TURNKEY"], ["Parts", "₹9,926 ($112.8)", "inside the ex-works price"], ["Duty", "₹1,638", "16.5% × EXW"], ["Freight", "₹176", "≈₹176 small carton"], ["India labour", "₹2,000", "≈₹500 acceptance"], ["Landed", "₹13,740", "EXW × 1.165 + 676"]], "Break-even EXW ≤ $127 (≤ $140 at target): $15–27 over parts. Tight at 100, comfortable at 1,000 → turnkey from day one.");
  T(s, "NPI GATES · QUANTITIES SIZED TO EACH PRODUCT'S VALUE", { x: 0.45, y: 3.88, w: 9, h: 0.18, fontSize: 7, color: MUTED, charSpacing: 1 });
  tbl(s, [
    ["GATE", "MIXER", "BAKER", "QUESTION", "EXIT (ALL MUST PASS)"],
    ["EVT", "10 × 2 suppliers", "2–3 module sets each", "Can they reproduce it?", "meets test spec; Rev B drawings"],
    ["DVT", "50", "5 machines", "Right for production?", "reliability, transport, EMC pre-scan; PR-001…004 on factory units"],
    ["PVT", "100, sellable", "10–20, sellable", "Is the process right?", "line operators; yield ≥ target (e.g. 95%); signed authorisation"],
  ], { x: 0.45, y: 4.08, w: 9.1, colW: [0.6, 1.3, 1.55, 1.75, 3.9], fontSize: 6.6, rowH: 0.24 });
  src(s, "Source: China assembly line master plan §9 and §12. Freight and India acceptance are the plan's assumptions; duty rate from the cost report. About 12 months to the first container.", 5.22);
}

// =================================================================== THANK YOU (founder's)
{
  const s = pres.addSlide(); s.background = { color: BG };
  s.addImage({ path: A + "logo.png", x: 0.45, y: 0.52, w: 2.15, h: 0.374 });
  H(s, "Thank you.", { x: 0.45, y: 3.05, w: 5, h: 0.85, fontSize: 46 });
  T(s, "Come and try the loop.", { x: 0.45, y: 3.9, w: 5, h: 0.32, fontSize: 14 });
  T(s, "protopus-kappa.vercel.app", { x: 0.45, y: 4.45, w: 5, h: 0.2, fontSize: 9.5, color: COPPER });
  T(s, "soham9763015@ece.du.ac.in", { x: 0.45, y: 4.72, w: 5, h: 0.2, fontSize: 9.5, color: BLUE });
  line(s, 5.5, 0.45, 0, 4.9);
  T(s, "MANAGEMENT TEAM & CORE SKILLS", { x: 5.95, y: 0.47, w: 3.7, h: 0.2, fontSize: 8.5, color: COPPER, charSpacing: 2 });
  H(s, "Who is building this", { x: 5.95, y: 0.75, w: 3.7, h: 0.32, fontSize: 14 });
  H(s, "Soham", { x: 5.95, y: 1.3, w: 3.7, h: 0.6, fontSize: 30 });
  T(s, "Founder", { x: 5.95, y: 1.92, w: 3.7, h: 0.2, fontSize: 10, color: COPPER });
  T(s, "Third year ECE, Faculty of Technology, University of Delhi", { x: 5.95, y: 2.2, w: 3.6, h: 0.4, fontSize: 8.5 });
  [["Industrial design", COPPER], ["Mechanical architecture", COPPER], ["Embedded electronics", BLUE], ["Machine software", COPPER]].forEach((k, i) => {
    const x = 5.95 + (i % 2) * 1.86, y = 2.8 + Math.floor(i / 2) * 0.55;
    line(s, x, y, 1.72, 0, k[1], 0.9);
    T(s, k[0], { x, y: y + 0.07, w: 1.75, h: 0.4, fontSize: 8.5, color: TEXT });
  });
  T(s, [{ text: "HIRING NEXT · ", options: { color: MUTED } }, { text: "a software engineer who also writes firmware.", options: { color: TEXT } }], { x: 5.95, y: 4.55, w: 2.0, h: 0.6, fontSize: 7.5 });
  s.addImage({ path: A + "mascot2.png", x: 7.95, y: 4.2, w: 1.6, h: 1.6 * 210 / 345 });
}

// =================================================================== APPENDIX
{
  const s = pres.addSlide(); s.background = { color: BG };
  kick(s, "Appendix · where the numbers come from", MUTED);
  const L = [
    ["Our documents", "PROTOPUS Cost Report · BOM workbook · Baker + Mixer workflow (“The story of a PCB”) · China assembly line master plan · all 29 Sep 2026"],
    ["Fab pricing", "jlcpcb.com PCB and PCBA pages · zbotic.in India shipping, duty and rush-fab guides"],
    ["Machines", "voltera.io, eleshop.eu, elektor.com · Design World (LPKF) · Makera (PR Newswire, Jun 2026) · ToolGuyd, Make, Hackaday (Bantam) · TechCrunch (BotFactory) · Evertiq, 8 Apr 2026 (Nano Dimension) · EEVblog (Neoden)"],
    ["Instruments", "Digilent AD3 (Jameco, DigiKey) · ADALM2000 (Mouser) · Moku:Go (TEquipment) · Red Pitaya · Saleae"],
    ["AI", "Flux (flux.ai; SiliconANGLE 27 Feb 2026) · Quilter (BusinessWire 7 Oct 2025) · Diode (Fenwick) · claude.com/connectors/autodesk-fusion · digitalproduction.com 30 Apr 2026 (Blender) · Lovable (TechCrunch 23 Jul 2025; founded.com)"],
    ["Market", "IMARC · Grand View · Arduino · Hackster · Atal Innovation Mission · Forbes · Fab Foundation · AICTE"],
    ["Conventions", "USD at ₹88 throughout, to match the cost report. Cycle times are engineering targets until the proof of concept measures them."],
  ];
  L.forEach((r, i) => {
    const y = 0.9 + i * 0.6;
    T(s, r[0].toUpperCase(), { x: 0.45, y, w: 1.7, h: 0.5, fontSize: 7.5, color: COPPER, charSpacing: 1 });
    T(s, r[1], { x: 2.2, y, w: 7.35, h: 0.55, fontSize: 7.8, color: TEXT });
    line(s, 0.45, y + 0.55, 9.1, 0);
  });
}

pres.writeFile({ fileName: OUT }).then(() => console.log("wrote", OUT, "slides:", pres.slides.length));

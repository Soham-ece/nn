PROTOPUS: pitch and murder-board package
Packed 2 Oct 2026

01_Final_Pitch_Deck_16_slides   The deck to present. PPTX to edit, PDF to share.
02_Full_Pitch_Deck_32_slides    The long version, with every technical slide (Proto AI, Baker, Mixer,
                                cycle time, open points, China line, landed cost). Use for diligence.
03_Murder_Board_Report          Detailed answers to Prateek's round-1 questions, competition, market.
04_Economics_Model              Excel model: machine cost, per-board cost, payback, throughput.
05_Earlier_Deck_Versions        Pitch v2 (light design), kept for reference.
06_Source_Documents             The documents you supplied (cost report, BOM, workflow stories,
                                China plan, original decks).
07_Fonts                        Space Grotesk + Space Mono (free, SIL Open Font License).
                                Install both before opening the PPTX files. The PDFs already embed them.
08_Build_Scripts                Scripts that generated the decks, report and workbook, plus the images.

Price note: the decks use the deck prices (Baker ₹2,99,000, Mixer ₹34,999, Proto ₹9,999/yr).
The report and workbook still use the earlier proposals (₹3,49,000 / ₹24,999); align before sharing them.
